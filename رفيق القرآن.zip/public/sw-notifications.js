// Custom Service Worker handlers for Rafiq Al-Quran PWA notifications
self.addEventListener('notificationclick', function (event) {
  event.notification.close();

  var action = event.action || '';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (clientList) {
      for (var i = 0; i < clientList.length; i++) {
        var client = clientList[i];
        if (action === 'stop-adhan') {
          client.postMessage({ type: 'STOP_ADHAN' });
        }
        if ('focus' in client) {
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow('/');
      }
    })
  );
});

self.addEventListener('message', function (event) {
  var data = event.data;
  if (!data || typeof data !== 'object') return;

  if (data.type === 'SHOW_NOTIFICATION' && self.registration) {
    var title = data.title || 'رفيق القرآن';
    var options = data.options || {};
    event.waitUntil(self.registration.showNotification(title, options));
  }
});
