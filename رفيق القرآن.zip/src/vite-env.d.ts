/// <reference types="vite/client" />
/// <reference types="google.maps" />
/// <reference types="vite-plugin-pwa/client" />

declare const __GOOGLE_MAPS_API_KEY__: string;

