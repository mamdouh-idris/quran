import { IstighfarReminderSlot, IstighfarScheduleConfig } from '../types';

export const ISTIGHFAR_SCHEDULE_STORAGE_KEY = 'rafiq_quran_istighfar_schedule_v1';
export const ISTIGHFAR_LAST_FIRED_STORAGE_KEY = 'rafiq_quran_istighfar_last_fired_v1';
export const ISTIGHFAR_NEXT_INTERVAL_KEY = 'rafiq_quran_istighfar_next_interval_v1';
export const ISTIGHFAR_SCHEDULE_UPDATED_EVENT = 'rafiq-istighfar-schedule-updated';
export const ISTIGHFAR_INAPP_ALERT_EVENT = 'rafiq-istighfar-inapp-alert';

export type NotificationPermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

export const DEFAULT_DHIKR_OPTIONS: string[] = [
  'أستغفر الله العظيم وأتوب إليه',
  'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
  'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
  'اللهم صلِّ وسلِّم على نبينا محمد',
  'لا حول ولا قوة إلا بالله العلي العظيم',
  'رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ',
];

export const DEFAULT_ISTIGHFAR_SCHEDULE: IstighfarScheduleConfig = {
  enabled: true,
  intervalEnabled: false,
  intervalMinutes: 15,
  intervalDhikr: 'أستغفر الله العظيم وأتوب إليه',
  scheduledSlots: [
    {
      id: 'slot-morning',
      time: '06:30',
      dhikr: 'أستغفر الله العظيم وأتوب إليه',
      enabled: true,
    },
    {
      id: 'slot-evening',
      time: '17:30',
      dhikr: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
      enabled: true,
    },
    {
      id: 'slot-night',
      time: '21:30',
      dhikr: 'اللهم صلِّ وسلِّم على نبينا محمد',
      enabled: true,
    },
  ],
};

export function loadIstighfarSchedule(): IstighfarScheduleConfig {
  try {
    const raw = localStorage.getItem(ISTIGHFAR_SCHEDULE_STORAGE_KEY);
    if (!raw) return DEFAULT_ISTIGHFAR_SCHEDULE;
    const parsed = JSON.parse(raw) as Partial<IstighfarScheduleConfig>;
    return {
      enabled: typeof parsed.enabled === 'boolean' ? parsed.enabled : true,
      intervalEnabled: typeof parsed.intervalEnabled === 'boolean' ? parsed.intervalEnabled : false,
      intervalMinutes:
        typeof parsed.intervalMinutes === 'number' && parsed.intervalMinutes > 0
          ? parsed.intervalMinutes
          : 15,
      intervalDhikr:
        typeof parsed.intervalDhikr === 'string' && parsed.intervalDhikr.trim()
          ? parsed.intervalDhikr
          : DEFAULT_ISTIGHFAR_SCHEDULE.intervalDhikr,
      scheduledSlots: Array.isArray(parsed.scheduledSlots)
        ? parsed.scheduledSlots.filter(
            (s): s is IstighfarReminderSlot =>
              Boolean(s && typeof s.id === 'string' && typeof s.time === 'string' && typeof s.dhikr === 'string')
          )
        : DEFAULT_ISTIGHFAR_SCHEDULE.scheduledSlots,
    };
  } catch {
    return DEFAULT_ISTIGHFAR_SCHEDULE;
  }
}

export function saveIstighfarSchedule(config: IstighfarScheduleConfig) {
  try {
    localStorage.setItem(ISTIGHFAR_SCHEDULE_STORAGE_KEY, JSON.stringify(config));
  } catch {
    // Ignore quota errors
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(ISTIGHFAR_SCHEDULE_UPDATED_EVENT, { detail: config }));
  }
}

export function getNextIntervalFireAt(): number | null {
  try {
    const raw = localStorage.getItem(ISTIGHFAR_NEXT_INTERVAL_KEY);
    if (!raw) return null;
    const num = Number(raw);
    return Number.isFinite(num) && num > 0 ? num : null;
  } catch {
    return null;
  }
}

export function setNextIntervalFireAt(timestampMs: number | null) {
  try {
    if (timestampMs === null) {
      localStorage.removeItem(ISTIGHFAR_NEXT_INTERVAL_KEY);
    } else {
      localStorage.setItem(ISTIGHFAR_NEXT_INTERVAL_KEY, String(timestampMs));
    }
  } catch {
    // Ignore storage errors
  }
}

export function scheduleNextInterval(intervalMinutes: number): number {
  const nextAt = Date.now() + Math.max(1, intervalMinutes) * 60 * 1000;
  setNextIntervalFireAt(nextAt);
  return nextAt;
}

export function getNotificationPermissionState(): NotificationPermissionState {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<NotificationPermissionState> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  try {
    const result = await Notification.requestPermission();
    return result;
  } catch {
    return Notification.permission || 'default';
  }
}

let sharedAudioCtx: AudioContext | null = null;

function getSharedAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return null;
  if (!sharedAudioCtx || sharedAudioCtx.state === 'closed') {
    sharedAudioCtx = new AudioCtx();
  }
  return sharedAudioCtx;
}

export function unlockReminderAudio() {
  try {
    const ctx = getSharedAudioContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
  } catch {
    // Ignore audio context errors
  }
}

export function playGentleReminderChime() {
  try {
    const ctx = getSharedAudioContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
    const now = ctx.currentTime;

    const notes = [528, 660];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.14);
      gain.gain.setValueAtTime(0.001, now + idx * 0.14);
      gain.gain.exponentialRampToValueAtTime(0.11, now + idx * 0.14 + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.14 + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.14);
      osc.stop(now + idx * 0.14 + 0.38);
    });
  } catch {
    // Ignore autoplay / audio context restrictions
  }
}

export const APP_ICON_URL = '/pwa-192x192.png';

export async function dispatchOSSystemNotification(
  title: string,
  body: string,
  tag?: string,
  extraOptions?: Record<string, unknown>
): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }
  if (Notification.permission !== 'granted') {
    return false;
  }

  const notifOptions: NotificationOptions & Record<string, unknown> = {
    body,
    icon: APP_ICON_URL,
    badge: APP_ICON_URL,
    dir: 'rtl',
    lang: 'ar',
    tag: tag || `rafiq-${Date.now()}`,
    renotify: true,
    vibrate: [200, 100, 200],
    silent: false,
    ...extraOptions,
  };

  // Prefer Service Worker registration first (required on Android Chrome & installed PWAs)
  if ('serviceWorker' in navigator) {
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg && typeof reg.showNotification === 'function') {
        await reg.showNotification(title, notifOptions);
        return true;
      }
      const readyReg = await Promise.race([
        navigator.serviceWorker.ready,
        new Promise<null>((resolve) => setTimeout(() => resolve(null), 1500)),
      ]);
      if (readyReg && typeof readyReg.showNotification === 'function') {
        await readyReg.showNotification(title, notifOptions);
        return true;
      }
    } catch {
      // Fallback below
    }
  }

  try {
    new Notification(title, notifOptions);
    return true;
  } catch {
    return false;
  }
}

export function sendIstighfarNotification(title: string, body: string, tag?: string): boolean {
  const canNotify =
    typeof window !== 'undefined' &&
    'Notification' in window &&
    Notification.permission === 'granted';

  if (canNotify) {
    dispatchOSSystemNotification(title, body, tag || `istighfar-${Date.now()}`).catch(() => {});
  }

  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate([180, 80, 180]);
    } catch {
      // ignore vibration errors
    }
  }

  playGentleReminderChime();

  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent(ISTIGHFAR_INAPP_ALERT_EVENT, {
        detail: { title, body, sentSystemNotification: canNotify, timestamp: Date.now() },
      })
    );
  }

  return canNotify;
}

export function getLastFiredMap(): Record<string, string> {
  try {
    const raw = localStorage.getItem(ISTIGHFAR_LAST_FIRED_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export function markSlotFired(slotId: string, dateMinuteKey: string) {
  try {
    const map = getLastFiredMap();
    map[slotId] = dateMinuteKey;
    localStorage.setItem(ISTIGHFAR_LAST_FIRED_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // Ignore storage errors
  }
}

export function formatCurrentHHMM(date: Date = new Date()): string {
  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

export function formatCurrentDateKey(date: Date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getNextScheduledSlot(
  config: IstighfarScheduleConfig,
  now: Date = new Date()
): { slot: IstighfarReminderSlot; minutesUntil: number } | null {
  if (!config.enabled) return null;
  const activeSlots = config.scheduledSlots.filter((s) => s.enabled && /^\d{2}:\d{2}$/.test(s.time));
  if (activeSlots.length === 0) return null;

  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  let best: { slot: IstighfarReminderSlot; minutesUntil: number } | null = null;

  for (const slot of activeSlots) {
    const [hStr, mStr] = slot.time.split(':');
    const slotMinutes = Number(hStr) * 60 + Number(mStr);
    if (Number.isNaN(slotMinutes)) continue;
    let diff = slotMinutes - nowMinutes;
    if (diff <= 0) diff += 24 * 60;
    if (!best || diff < best.minutesUntil) {
      best = { slot, minutesUntil: diff };
    }
  }

  return best;
}
