import { AppLanguage } from '../types';

export interface LanguageOption {
  id: AppLanguage;
  name: string;
  nativeName: string;
  dir: 'rtl' | 'ltr';
}

export const LANGUAGE_OPTIONS: LanguageOption[] = [
  { id: 'ar', name: 'العربية', nativeName: 'العربية', dir: 'rtl' },
  { id: 'en', name: 'English', nativeName: 'English', dir: 'ltr' },
  { id: 'fr', name: 'Français', nativeName: 'Français', dir: 'ltr' },
  { id: 'ur', name: 'اردو', nativeName: 'اردو', dir: 'rtl' },
];

export const getDirection = (lang: AppLanguage): 'rtl' | 'ltr' => {
  return lang === 'en' || lang === 'fr' ? 'ltr' : 'rtl';
};

export interface Translations {
  appName: string;
  appTagline: string;
  simulatorTab: string;
  planTab: string;
  phoneSimulatorLabel: string;
  simCall: string;
  endCall: string;
  simAlert: string;
  fullscreen: string;
  exitFullscreen: string;
  navMushaf: string;
  navTasmie: string;
  navPrayer: string;
  navAdhkar: string;
  navRadio: string;
  navSettings: string;
  settingsTitle: string;
  settingsSubtitle: string;
  languageSectionTitle: string;
  languageLabel: string;
  themesSectionTitle: string;
  chooseTheme: string;
  accentLabel: string;
  fontsSectionTitle: string;
  liveFontPreview: string;
  changeSampleAyah: string;
  fontSizeLabel: string;
  smartPauseTitle: string;
  smartPauseDesc: string;
  pageFlipTitle: string;
  pageFlipDesc: string;
  navModeTitle: string;
  navModeSwipe: string;
  navModeButtons: string;
  readingModeTitle: string;
  readingModeDesc: string;
  offlineTitle: string;
  offlineLabel: string;
  offlineBtn: string;
  storageTitle: string;
  storageSubtitle: string;
  storageOpenBtn: string;
  storageBackBtn: string;
  storageTotalUsed: string;
  storageOfflineAudioLabel: string;
  storageTextCacheLabel: string;
  storageAvailableDevice: string;
  storageDownloadedSurahsTitle: string;
  storageNoDownloadedSurahs: string;
  storageCachedTextsTitle: string;
  storageNoCachedTexts: string;
  storageDeleteSelected: string;
  storageSelectAll: string;
  storageClearSelection: string;
  storageClearAudioOnly: string;
  storageClearAllCacheBtn: string;
  storageClearConfirmTitle: string;
  storageClearConfirmDesc: string;
  storageConfirmYes: string;
  storageCancel: string;
  storageFreedBanner: string;
  storageSearchPlaceholder: string;
  storageSurahsCount: string;
  istighfarSchedTitle: string;
  istighfarSchedDesc: string;
  notifPermGranted: string;
  notifPermDenied: string;
  notifPermDefault: string;
  notifPermUnsupported: string;
  enableBrowserNotifBtn: string;
  addReminderTimeLabel: string;
  addReminderBtn: string;
  scheduledTimesTitle: string;
  noScheduledTimes: string;
  testNotifBtn: string;
  testNotifSent: string;
  nextReminderLabel: string;
  periodicReminderLabel: string;
  everyMinutesLabel: string;
  appInfoTitle: string;
  aboutBtn: string;
  preparedBy: string;
  phoneLabel: string;
  duaTitle: string;
  tasmieTitle: string;
  tasmieDesc: string;
  selectSurah: string;
  recitationScope: string;
  scopeSingle: string;
  scopeRange: string;
  scopeFullSurah: string;
  fromAyah: string;
  toAyah: string;
  ayahNumber: string;
  hideAyahText: string;
  showAyahText: string;
  ayahHiddenPlaceholder: string;
  revealFirstWord: string;
  startTasmie: string;
  stopAndEvaluate: string;
  retryTasmie: string;
  listeningPrompt: string;
  listeningActive: string;
  accuracyScore: string;
  transcriptTitle: string;
  mistakesTitle: string;
  prayerRegion: string;
  prayerTimeOffset: string;
  prayerTimesTitle: string;
  muezzinSection: string;
  chooseMuezzin: string;
  shortAdhanTitle: string;
  flipMuteTitle: string;
  testAdhanBtn: string;
  stopAdhanBtn: string;
  qiblaTitle: string;
  enableGps: string;
  prayerScheduleTab: string;
  nextPrayerLabel: string;
  remainingLabel: string;
  cityClockLabel: string;
  fixQiblaTitle: string;
  calibratePrompt: string;
  calibrateBtn: string;
  recalibrateBtn: string;
  chooseCalibrationType: string;
  algoStandard: string;
  algoGyro: string;
  algoMagnetic: string;
  facingQiblaNow: string;
  distanceToKaaba: string;
  manualRotateHint: string;
  adhkarTabHisn: string;
  adhkarTabRosary: string;
  adhkarTabTimer: string;
  radioTitle: string;
  radioSubtitle: string;
  radioStationsList: string;
  repeatAndMemorize: string;
  showTafsir: string;
  hideTafsir: string;
  listen: string;
  stop: string;
  download: string;
  downloaded: string;
  prevPage: string;
  nextPage: string;
  pageOf: string;
}

const translationsMap: Record<AppLanguage, Translations> = {
  ar: {
    appName: 'رفيق القرآن',
    appTagline: 'تطبيق المصحف، التسميع، التكرار المخصص، ومواقيت الصلاة والأذان',
    simulatorTab: 'محاكي تطبيق الموبايل',
    planTab: 'خطة التنفيذ الهندسية',
    phoneSimulatorLabel: 'محاكي هاتف ذكي (Android / iOS)',
    simCall: 'محاكاة مكالمة',
    endCall: 'إنهاء المكالمة',
    simAlert: 'محاكاة تنبيه نظام',
    fullscreen: 'ملء الشاشة',
    exitFullscreen: 'تصغير العرض',
    navMushaf: 'المصحف',
    navTasmie: 'التسميع',
    navPrayer: 'الصلاة',
    navAdhkar: 'الأذكار',
    navRadio: 'الإذاعة',
    navSettings: 'الإعدادات',
    settingsTitle: 'إعدادات تطبيق رفيق القرآن',
    settingsSubtitle: 'تخصيص اللغة، ألوان التطبيق، الخطوط، تقليب الصفحات، والتحميل أوفلاين',
    languageSectionTitle: 'لغة واجهة التطبيق (App Language)',
    languageLabel: 'اختر لغة القوائم وواجهة الاستخدام:',
    themesSectionTitle: 'ألوان ومظهر التطبيق بالكامل',
    chooseTheme: 'اختر الثيم الرئيسي للتطبيق:',
    accentLabel: 'اللون المميز للأزرار والعناوين:',
    fontsSectionTitle: 'اختبار وتبديل خطوط القرآن الكريم',
    liveFontPreview: 'معاينة واختبار الخط مباشرة:',
    changeSampleAyah: 'تغيير آية الاختبار',
    fontSizeLabel: 'حجم خط المصحف والمعاينة:',
    smartPauseTitle: 'التوقف الذكي (Smart Pause)',
    smartPauseDesc: 'إيقاف التلاوة والإذاعة والأذان تلقائياً عند تلقي مكالمة هاتفية أو تنبيه نظام، واستئناف التشغيل فور انتهائها',
    pageFlipTitle: 'تأثير تقليب الصفحات ثلاثي الأبعاد',
    pageFlipDesc: 'محاكاة حركية واقعية لتقليب صفحات كتاب المصحف الحقيقي',
    navModeTitle: 'طريقة تقليب الصفحات',
    navModeSwipe: 'سحب الشاشة باللمس (Swipe)',
    navModeButtons: 'أزرار التنقل (Buttons)',
    readingModeTitle: 'وضع القراءة المريح (للإضاءة الخافتة)',
    readingModeDesc: 'تخفيف الإضاءة وتلطيف تباين الألوان للراحة البصرية',
    offlineTitle: 'تحميل القرآن كاملاً للعمل بدون إنترنت',
    offlineLabel: 'اختر القارئ لتحميل تلاوته كاملاً:',
    offlineBtn: 'تحميل سور القرآن كاملاً (Offline)',
    storageTitle: 'إدارة التخزين',
    storageSubtitle: 'عرض السور المحملة، حذف سور محددة، ومسح الذاكرة المؤقتة',
    storageOpenBtn: 'إدارة التخزين والسور المحملة',
    storageBackBtn: 'الإعدادات',
    storageTotalUsed: 'المساحة المستخدمة بالتطبيق',
    storageOfflineAudioLabel: 'تلاوات بدون إنترنت',
    storageTextCacheLabel: 'نصوص المصحف والراديو المؤقتة',
    storageAvailableDevice: 'مساحة الجهاز المتاحة',
    storageDownloadedSurahsTitle: 'السور المحملة للاستماع بدون إنترنت',
    storageNoDownloadedSurahs: 'لا توجد سور محملة للاستماع بدون إنترنت حالياً.',
    storageCachedTextsTitle: 'ذاكرة التخزين المؤقت لنصوص السور',
    storageNoCachedTexts: 'ذاكرة التخزين المؤقت للنصوص فارغة.',
    storageDeleteSelected: 'حذف المحدد',
    storageSelectAll: 'تحديد الكل',
    storageClearSelection: 'إلغاء التحديد',
    storageClearAudioOnly: 'حذف جميع التلاوات المحملة',
    storageClearAllCacheBtn: 'مسح ذاكرة التخزين المؤقت بالكامل',
    storageClearConfirmTitle: 'مسح ذاكرة التخزين المؤقت بالكامل؟',
    storageClearConfirmDesc: 'سيتم حذف جميع التلاوات المحملة بدون إنترنت وذاكرة النصوص والراديو المؤقتة لتوفير مساحة في الهاتف. لن تتأثر إعداداتك.',
    storageConfirmYes: 'نعم، مسح الكل',
    storageCancel: 'إلغاء',
    storageFreedBanner: 'تم توفير مساحة بنجاح:',
    storageSearchPlaceholder: 'ابحث باسم السورة...',
    storageSurahsCount: 'سورة محملة',
    istighfarSchedTitle: 'جدولة تنبيهات مؤقت الاستغفار',
    istighfarSchedDesc: 'إرسال إشعارات تذكير تلقائية عبر المتصفح والنظام (Notification API) في أوقات محددة تختارها',
    notifPermGranted: 'إشعارات النظام مفعّلة ✓',
    notifPermDenied: 'الإشعارات محظورة من إعدادات المتصفح (ستظهر داخل التطبيق)',
    notifPermDefault: 'لم يتم منح إذن إشعارات النظام بعد',
    notifPermUnsupported: 'المتصفح الحالي لا يدعم إشعارات النظام (تعمل داخل التطبيق)',
    enableBrowserNotifBtn: 'تفعيل إشعارات المتصفح',
    addReminderTimeLabel: 'إضافة وقت تذكير يومي جديد:',
    addReminderBtn: 'إضافة الموعد',
    scheduledTimesTitle: 'المواعيد المجدولة للتذكير:',
    noScheduledTimes: 'لم تتم إضافة أوقات تذكير بعد.',
    testNotifBtn: 'تجربة إرسال تنبيه الآن 🔔',
    testNotifSent: 'تم إرسال إشعار تجريبي لمؤقت الاستغفار',
    nextReminderLabel: 'التذكير القادم:',
    periodicReminderLabel: 'تذكير دوري متكرر بالخلفية:',
    everyMinutesLabel: 'كل',
    appInfoTitle: 'معلومات التطبيق',
    aboutBtn: 'نبذة عن رفيق القرآن والإصدار',
    preparedBy: 'إعداد: الفقير إلى الله ممدوح إدريس صديق',
    phoneLabel: 'موبايل:',
    duaTitle: 'دعاء له ولوالديه',
    tasmieTitle: 'وضع التسميع الحي بالتعرف على الكلام',
    tasmieDesc: 'اخفِ الآيات لتختبر حفظك لآية واحدة أو عدة آيات أو السورة كاملة، وسينبهك النظام لأي خطأ فوراً.',
    selectSurah: 'اختر السورة:',
    recitationScope: 'نطاق التسميع:',
    scopeSingle: 'آية واحدة',
    scopeRange: 'عدد من الآيات',
    scopeFullSurah: 'السورة كاملة',
    fromAyah: 'من آية:',
    toAyah: 'إلى آية:',
    ayahNumber: 'رقم الآية:',
    hideAyahText: 'إخفاء النص للاختبار',
    showAyahText: 'إظهار النص',
    ayahHiddenPlaceholder: 'نص الآيات مخفي الآن لاختبار الحفظ... ابدأ التلاوة بصوت واضح',
    revealFirstWord: 'تلميح بأول كلمة',
    startTasmie: 'بدء الاستماع والتسميع',
    stopAndEvaluate: 'إيقاف وتقييم التلاوة',
    retryTasmie: 'إعادة التسميع',
    listeningPrompt: 'اضغط على زر البدء واتلُ الآيات المطلوبة بصوت واضح',
    listeningActive: 'جاري الاستماع لتلاوتك عبر الميكروفون...',
    accuracyScore: 'نسبة مطابقة التلاوة:',
    transcriptTitle: 'صوتك المحول إلى نص:',
    mistakesTitle: 'التنبيهات ومواضع الاختلاف:',
    prayerRegion: 'المنطقة والمدينة:',
    prayerTimeOffset: 'تعديل توقيت الصلاة (بالدقائق):',
    prayerTimesTitle: 'مواقيت الصلاة',
    muezzinSection: 'اختيار المؤذن وصوت الأذان',
    chooseMuezzin: 'اختر المؤذن:',
    shortAdhanTitle: 'أذان مختصر (تكبيرتين فقط)',
    flipMuteTitle: 'كتم الأذان عند قلب الهاتف (Flip Mute)',
    testAdhanBtn: 'تجربة صوت الأذان 🔊',
    stopAdhanBtn: 'إيقاف الأذان ⏹',
    qiblaTitle: 'القبلة',
    enableGps: 'تحديد الموقع GPS',
    prayerScheduleTab: 'مواقيت الصلاة',
    nextPrayerLabel: 'الصلاة القادمة',
    remainingLabel: 'متبقي على الأذان',
    cityClockLabel: 'التوقيت المحلي',
    fixQiblaTitle: 'إصلاح مشكلة القبلة',
    calibratePrompt: 'قم بتوجيه القبلة للمعايرة',
    calibrateBtn: 'إضغط للمعايرة',
    recalibrateBtn: 'إعادة المعايرة',
    chooseCalibrationType: 'إختر نوع المعايرة',
    algoStandard: 'الخوارزمية العادية',
    algoGyro: 'خوارزمية الجيروسكوب',
    algoMagnetic: 'الخوارزمية المغناطيسية',
    facingQiblaNow: 'أنت تواجه القبلة الآن',
    distanceToKaaba: 'المسافة إلى الكعبة',
    manualRotateHint: 'اسحب القرص أو حرّك المؤشر لتجربة الاتجاه',
    adhkarTabHisn: 'حصن المسلم',
    adhkarTabRosary: 'المسبحة',
    adhkarTabTimer: 'مؤقت الاستغفار',
    radioTitle: 'إذاعة القرآن الكريم البث المباشر',
    radioSubtitle: 'استمع مباشرة إلى بث إذاعات القرآن الكريم العالمية مع نظام اتصال ذكي ومستقر.',
    radioStationsList: 'قائمة المحطات الإذاعية المتاحة:',
    repeatAndMemorize: 'التكرار والحفظ',
    showTafsir: 'عرض التفسير',
    hideTafsir: 'إخفاء التفسير',
    listen: 'استماع',
    stop: 'إيقاف',
    download: 'تحميل',
    downloaded: 'محملة',
    prevPage: 'الصفحة السابقة',
    nextPage: 'الصفحة التالية',
    pageOf: 'صفحة',
  },
  en: {
    appName: 'Quran Companion',
    appTagline: 'Mushaf Reader, AI Recitation Check, Custom Repeat & Prayer Times',
    simulatorTab: 'Mobile App Simulator',
    planTab: 'Engineering Plan',
    phoneSimulatorLabel: 'Smartphone Simulator (Android / iOS)',
    simCall: 'Simulate Call',
    endCall: 'End Call',
    simAlert: 'Simulate Alert',
    fullscreen: 'Fullscreen',
    exitFullscreen: 'Exit Fullscreen',
    navMushaf: 'Mushaf',
    navTasmie: 'Recite',
    navPrayer: 'Prayer',
    navAdhkar: 'Adhkar',
    navRadio: 'Radio',
    navSettings: 'Settings',
    settingsTitle: 'Quran Companion Settings',
    settingsSubtitle: 'Customize language, app colors, Quran fonts, page flip & offline download',
    languageSectionTitle: 'App Interface Language',
    languageLabel: 'Select display language for menus & controls:',
    themesSectionTitle: 'App Colors & Themes',
    chooseTheme: 'Choose App Theme:',
    accentLabel: 'Accent Color for Buttons & Highlights:',
    fontsSectionTitle: 'Quran Fonts & Live Preview',
    liveFontPreview: 'Live Font Preview & Tester:',
    changeSampleAyah: 'Switch Sample Ayah',
    fontSizeLabel: 'Mushaf Font Size:',
    smartPauseTitle: 'Smart Pause',
    smartPauseDesc: 'Automatically pauses Quran, Radio, or Adhan during phone calls or system alerts and resumes afterward',
    pageFlipTitle: '3D Page Flip Animation',
    pageFlipDesc: 'Realistic book-style 3D flip animation when turning Mushaf pages',
    navModeTitle: 'Page Navigation Mode',
    navModeSwipe: 'Touch Swipe',
    navModeButtons: 'Navigation Buttons',
    readingModeTitle: 'Comfortable Night Reading Mode',
    readingModeDesc: 'Warm low-contrast sepia tone for effortless night reading',
    offlineTitle: 'Download Full Quran for Offline Use',
    offlineLabel: 'Select Reciter to Download:',
    offlineBtn: 'Download Full Quran (Offline)',
    storageTitle: 'Storage Management',
    storageSubtitle: 'View offline Surahs, delete specific items, or clear cache',
    storageOpenBtn: 'Manage Storage & Offline Surahs',
    storageBackBtn: 'Settings',
    storageTotalUsed: 'App Storage Used',
    storageOfflineAudioLabel: 'Offline Audio Recitations',
    storageTextCacheLabel: 'Cached Surah Text & Radio',
    storageAvailableDevice: 'Device Storage Free',
    storageDownloadedSurahsTitle: 'Downloaded Surahs (Offline)',
    storageNoDownloadedSurahs: 'No Surahs downloaded for offline listening yet.',
    storageCachedTextsTitle: 'Cached Surah Text Data',
    storageNoCachedTexts: 'Text cache is currently empty.',
    storageDeleteSelected: 'Delete Selected',
    storageSelectAll: 'Select All',
    storageClearSelection: 'Clear Selection',
    storageClearAudioOnly: 'Delete All Offline Audio',
    storageClearAllCacheBtn: 'Clear Full Cache',
    storageClearConfirmTitle: 'Clear Full App Cache?',
    storageClearConfirmDesc: 'All offline Surah audio, cached Surah texts, and cached radio data will be removed to free up space. Your settings remain safe.',
    storageConfirmYes: 'Yes, Clear All',
    storageCancel: 'Cancel',
    storageFreedBanner: 'Storage freed successfully:',
    storageSearchPlaceholder: 'Search Surah name...',
    storageSurahsCount: 'Downloaded',
    istighfarSchedTitle: 'Istighfar Notification Scheduler',
    istighfarSchedDesc: 'Send automatic Browser/OS reminders via Notification API at your chosen daily times',
    notifPermGranted: 'System Notifications Enabled ✓',
    notifPermDenied: 'Blocked in browser settings (in-app alerts still active)',
    notifPermDefault: 'Browser notification permission not granted yet',
    notifPermUnsupported: 'Notification API unsupported (in-app alerts active)',
    enableBrowserNotifBtn: 'Enable Browser Notifications',
    addReminderTimeLabel: 'Add new daily reminder time:',
    addReminderBtn: 'Add Time',
    scheduledTimesTitle: 'Scheduled Reminder Times:',
    noScheduledTimes: 'No scheduled reminder times added yet.',
    testNotifBtn: 'Send Test Notification 🔔',
    testNotifSent: 'Test Istighfar notification sent',
    nextReminderLabel: 'Next reminder:',
    periodicReminderLabel: 'Periodic background interval:',
    everyMinutesLabel: 'Every',
    appInfoTitle: 'App Info & Credits',
    aboutBtn: 'About Quran Companion',
    preparedBy: 'Prepared by: Mamdouh Edris Seddik',
    phoneLabel: 'Mobile:',
    duaTitle: 'Prayer for Him & His Parents',
    tasmieTitle: 'Live Recitation Check (Tasmie)',
    tasmieDesc: 'Hide the verse text to test your memorization for a single ayah, a range of ayahs, or the full Surah.',
    selectSurah: 'Select Surah:',
    recitationScope: 'Recitation Scope:',
    scopeSingle: 'Single Ayah',
    scopeRange: 'Ayah Range',
    scopeFullSurah: 'Full Surah',
    fromAyah: 'From Ayah:',
    toAyah: 'To Ayah:',
    ayahNumber: 'Ayah #:',
    hideAyahText: 'Hide Text (Test Mode)',
    showAyahText: 'Show Text',
    ayahHiddenPlaceholder: 'Ayah text is hidden for memorization testing... Start reciting clearly.',
    revealFirstWord: 'Hint: First Word',
    startTasmie: 'Start Recitation',
    stopAndEvaluate: 'Stop & Evaluate',
    retryTasmie: 'Recite Again',
    listeningPrompt: 'Press Start and recite the selected verse(s) clearly',
    listeningActive: 'Listening to your recitation via microphone...',
    accuracyScore: 'Recitation Accuracy:',
    transcriptTitle: 'Recognized Speech Transcript:',
    mistakesTitle: 'Corrections & Differences:',
    prayerRegion: 'City & Region:',
    prayerTimeOffset: 'Adjust Prayer Time (minutes):',
    prayerTimesTitle: 'Prayer Times',
    muezzinSection: 'Muezzin & Adhan Audio',
    chooseMuezzin: 'Select Muezzin:',
    shortAdhanTitle: 'Short Adhan (2 Takbeers)',
    flipMuteTitle: 'Flip Phone to Mute Adhan',
    testAdhanBtn: 'Test Adhan 🔊',
    stopAdhanBtn: 'Stop Adhan ⏹',
    qiblaTitle: 'Qibla',
    enableGps: 'Locate via GPS',
    prayerScheduleTab: 'Prayer Times',
    nextPrayerLabel: 'Next Prayer',
    remainingLabel: 'Time Remaining',
    cityClockLabel: 'Local Time',
    fixQiblaTitle: 'Fix Qibla Issue',
    calibratePrompt: 'Point toward Qibla to calibrate',
    calibrateBtn: 'Tap to Calibrate',
    recalibrateBtn: 'Recalibrate',
    chooseCalibrationType: 'Choose Calibration Method',
    algoStandard: 'Standard Algorithm',
    algoGyro: 'Gyroscope Algorithm',
    algoMagnetic: 'Magnetic Algorithm',
    facingQiblaNow: 'You are facing Qibla',
    distanceToKaaba: 'Distance to Kaaba',
    manualRotateHint: 'Drag dial or slide to test heading',
    adhkarTabHisn: 'Hisn Al-Muslim',
    adhkarTabRosary: 'Tasbih',
    adhkarTabTimer: 'Dhikr Timer',
    radioTitle: 'Live Quran Radio',
    radioSubtitle: 'Listen live to global Quran broadcasts with smart reconnect.',
    radioStationsList: 'Available Radio Stations:',
    repeatAndMemorize: 'Repeat & Memorize',
    showTafsir: 'Show Tafsir',
    hideTafsir: 'Hide Tafsir',
    listen: 'Listen',
    stop: 'Stop',
    download: 'Download',
    downloaded: 'Saved',
    prevPage: 'Previous Page',
    nextPage: 'Next Page',
    pageOf: 'Page',
  },
  fr: {
    appName: 'Compagnon du Coran',
    appTagline: 'Mushaf, Récitation, Répétition personnalisée et Horaires de prière',
    simulatorTab: 'Simulateur Mobile',
    planTab: 'Plan Technique',
    phoneSimulatorLabel: 'Simulateur Smartphone (Android / iOS)',
    simCall: 'Simuler Appel',
    endCall: 'Fin Appel',
    simAlert: 'Simuler Alerte',
    fullscreen: 'Plein écran',
    exitFullscreen: 'Réduire',
    navMushaf: 'Mushaf',
    navTasmie: 'Récitation',
    navPrayer: 'Prière',
    navAdhkar: 'Adhkar',
    navRadio: 'Radio',
    navSettings: 'Paramètres',
    settingsTitle: 'Paramètres de l’application',
    settingsSubtitle: 'Langue, thèmes, polices coraniques, rotation de page et hors-ligne',
    languageSectionTitle: 'Langue de l’interface',
    languageLabel: 'Choisissez la langue de l’application :',
    themesSectionTitle: 'Couleurs et Thèmes',
    chooseTheme: 'Choisir le thème principal :',
    accentLabel: 'Couleur d’accentuation :',
    fontsSectionTitle: 'Polices du Coran & Aperçu',
    liveFontPreview: 'Aperçu en direct de la police :',
    changeSampleAyah: 'Changer le verset',
    fontSizeLabel: 'Taille du texte coranique :',
    smartPauseTitle: 'Pause Intelligente (Smart Pause)',
    smartPauseDesc: 'Met en pause automatiquement le son lors d’un appel ou alerte système puis reprend ensuite',
    pageFlipTitle: 'Animation 3D de page',
    pageFlipDesc: 'Effet réaliste de livre lors du changement de page du Mushaf',
    navModeTitle: 'Mode de navigation',
    navModeSwipe: 'Glisser (Swipe)',
    navModeButtons: 'Boutons',
    readingModeTitle: 'Mode lecture nocturne confortable',
    readingModeDesc: 'Teinte sépia apaisante pour la lecture en faible luminosité',
    offlineTitle: 'Télécharger tout le Coran (Hors ligne)',
    offlineLabel: 'Choisir le récitateur :',
    offlineBtn: 'Télécharger le Coran complet',
    storageTitle: 'Gestion du stockage',
    storageSubtitle: 'Gérer les sourates hors ligne et vider le cache',
    storageOpenBtn: 'Gérer le stockage et les téléchargements',
    storageBackBtn: 'Paramètres',
    storageTotalUsed: 'Espace utilisé par l’app',
    storageOfflineAudioLabel: 'Audios hors ligne',
    storageTextCacheLabel: 'Textes & radio en cache',
    storageAvailableDevice: 'Espace libre sur l’appareil',
    storageDownloadedSurahsTitle: 'Sourates téléchargées (Hors ligne)',
    storageNoDownloadedSurahs: 'Aucune sourate téléchargée pour l’écoute hors ligne.',
    storageCachedTextsTitle: 'Cache des textes coraniques',
    storageNoCachedTexts: 'Le cache de texte est vide.',
    storageDeleteSelected: 'Supprimer la sélection',
    storageSelectAll: 'Tout sélectionner',
    storageClearSelection: 'Tout désélectionner',
    storageClearAudioOnly: 'Supprimer tous les audios',
    storageClearAllCacheBtn: 'Vider tout le cache',
    storageClearConfirmTitle: 'Vider tout le cache ?',
    storageClearConfirmDesc: 'Tous les audios hors ligne, textes et données radio en cache seront supprimés pour libérer de l’espace.',
    storageConfirmYes: 'Oui, tout vider',
    storageCancel: 'Annuler',
    storageFreedBanner: 'Espace libéré :',
    storageSearchPlaceholder: 'Rechercher une sourate...',
    storageSurahsCount: 'Téléchargées',
    istighfarSchedTitle: 'Planificateur de notifications Istighfar',
    istighfarSchedDesc: 'Envoie des rappels automatiques via Notification API aux heures choisies',
    notifPermGranted: 'Notifications système activées ✓',
    notifPermDenied: 'Bloquées dans le navigateur (alertes internes actives)',
    notifPermDefault: 'Autorisation non accordée',
    notifPermUnsupported: 'Notification API non prise en charge',
    enableBrowserNotifBtn: 'Activer les notifications',
    addReminderTimeLabel: 'Ajouter une heure de rappel :',
    addReminderBtn: 'Ajouter',
    scheduledTimesTitle: 'Heures de rappel programmées :',
    noScheduledTimes: 'Aucune heure programmée.',
    testNotifBtn: 'Tester la notification 🔔',
    testNotifSent: 'Notification de test envoyée',
    nextReminderLabel: 'Prochain rappel :',
    periodicReminderLabel: 'Rappel périodique en arrière-plan :',
    everyMinutesLabel: 'Toutes les',
    appInfoTitle: 'À propos de l’application',
    aboutBtn: 'Informations et crédits',
    preparedBy: 'Préparé par : Mamdouh Edris Seddik',
    phoneLabel: 'Téléphone :',
    duaTitle: 'Invocation pour lui et ses parents',
    tasmieTitle: 'Contrôle de Récitation en direct',
    tasmieDesc: 'Masquez le texte pour tester votre mémorisation d’un verset, d’une plage de versets ou de toute la sourate.',
    selectSurah: 'Choisir la Sourate :',
    recitationScope: 'Étendue :',
    scopeSingle: '1 Verset',
    scopeRange: 'Plage de versets',
    scopeFullSurah: 'Sourate complète',
    fromAyah: 'Du verset :',
    toAyah: 'Au verset :',
    ayahNumber: 'Verset n° :',
    hideAyahText: 'Masquer le texte',
    showAyahText: 'Afficher le texte',
    ayahHiddenPlaceholder: 'Texte masqué pour tester la mémorisation... Récitez clairement.',
    revealFirstWord: 'Indice : 1er mot',
    startTasmie: 'Démarrer la récitation',
    stopAndEvaluate: 'Arrêter et évaluer',
    retryTasmie: 'Réciter à nouveau',
    listeningPrompt: 'Appuyez sur Démarrer et récitez clairement',
    listeningActive: 'Écoute de votre récitation via le microphone...',
    accuracyScore: 'Précision :',
    transcriptTitle: 'Transcription vocale :',
    mistakesTitle: 'Corrections détectées :',
    prayerRegion: 'Ville et Région :',
    prayerTimeOffset: 'Ajuster l’horaire (min) :',
    prayerTimesTitle: 'Horaires de Prière',
    muezzinSection: 'Muezzin et Audio Adhan',
    chooseMuezzin: 'Choisir le Muezzin :',
    shortAdhanTitle: 'Adhan court (2 Takbirs)',
    flipMuteTitle: 'Retourner pour couper l’Adhan',
    testAdhanBtn: 'Tester Adhan 🔊',
    stopAdhanBtn: 'Arrêter ⏹',
    qiblaTitle: 'Qibla',
    enableGps: 'Localiser GPS',
    prayerScheduleTab: 'Horaires',
    nextPrayerLabel: 'Prochaine prière',
    remainingLabel: 'Temps restant',
    cityClockLabel: 'Heure locale',
    fixQiblaTitle: 'Réparer la Qibla',
    calibratePrompt: 'Orientez vers la Qibla pour calibrer',
    calibrateBtn: 'Appuyer pour calibrer',
    recalibrateBtn: 'Recalibrer',
    chooseCalibrationType: 'Type de calibration',
    algoStandard: 'Algorithme standard',
    algoGyro: 'Algorithme gyroscope',
    algoMagnetic: 'Algorithme magnétique',
    facingQiblaNow: 'Vous faites face à la Qibla',
    distanceToKaaba: 'Distance de la Kaaba',
    manualRotateHint: 'Glissez le cadran pour tester',
    adhkarTabHisn: 'Hisn Al-Muslim',
    adhkarTabRosary: 'Chapelet',
    adhkarTabTimer: 'Rappel Dhikr',
    radioTitle: 'Radio Coran en Direct',
    radioSubtitle: 'Écoutez les stations du Coran en direct avec reconnexion intelligente.',
    radioStationsList: 'Stations disponibles :',
    repeatAndMemorize: 'Répéter & Mémoriser',
    showTafsir: 'Voir Tafsir',
    hideTafsir: 'Masquer Tafsir',
    listen: 'Écouter',
    stop: 'Arrêter',
    download: 'Télécharger',
    downloaded: 'Enregistré',
    prevPage: 'Page précédente',
    nextPage: 'Page suivante',
    pageOf: 'Page',
  },
  ur: {
    appName: 'رفیق القرآن',
    appTagline: 'مصحف، تلاوت کی جانچ، آیات کی تکرار اور نماز کے اوقات',
    simulatorTab: 'موبائل ایپ سمیلیٹر',
    planTab: 'انجینئرنگ پلان',
    phoneSimulatorLabel: 'اسمارٹ فون سمیلیٹر (Android / iOS)',
    simCall: 'کال کا تجربہ',
    endCall: 'کال ختم کریں',
    simAlert: 'سسٹم الرٹ',
    fullscreen: 'پوری اسکرین',
    exitFullscreen: 'چھوٹی اسکرین',
    navMushaf: 'مصحف',
    navTasmie: 'تسمیع',
    navPrayer: 'نماز',
    navAdhkar: 'اذکار',
    navRadio: 'ریڈیو',
    navSettings: 'ترتیبات',
    settingsTitle: 'رفیق القرآن ترتیبات',
    settingsSubtitle: 'زبان، رنگ، قرآنی خط، صفحات پلٹنا اور آف لائن ڈاؤن لوڈ',
    languageSectionTitle: 'ایپ کی زبان (Language)',
    languageLabel: 'انٹرفیس کی زبان منتخب کریں:',
    themesSectionTitle: 'ایپ کے رنگ اور تھیمز',
    chooseTheme: 'مرکزی تھیم منتخب کریں:',
    accentLabel: 'بٹنوں اور سرخیوں کا رنگ:',
    fontsSectionTitle: 'قرآنی خطوط اور براہ راست جانچ',
    liveFontPreview: 'خط کا براہ راست نمونہ:',
    changeSampleAyah: 'آیت تبدیل کریں',
    fontSizeLabel: 'مصحف کے خط کا سائز:',
    smartPauseTitle: 'اسمارٹ پاز (Smart Pause)',
    smartPauseDesc: 'کال یا نوٹیفکیشن آنے پر تلاوت، ریڈیو اور اذان خودکار رک جائے گی اور بعد میں دوبارہ چلے گی',
    pageFlipTitle: 'تھری ڈی صفحہ پلٹنے کا اثر',
    pageFlipDesc: 'حقیقی کتاب کی طرح صفحہ پلٹنے کی حرکت',
    navModeTitle: 'صفحہ پلٹنے کا طریقہ',
    navModeSwipe: 'اسوائپ (Swipe)',
    navModeButtons: 'بٹن (Buttons)',
    readingModeTitle: 'آرام دہ رات کی قراءت',
    readingModeDesc: 'کم روشنی میں آنکھوں کے آرام کے لیے نرم رنگ',
    offlineTitle: 'بغیر انٹرنیٹ مکمل قرآن ڈاؤن لوڈ',
    offlineLabel: 'قاری منتخب کریں:',
    offlineBtn: 'مکمل قرآن ڈاؤن لوڈ کریں',
    storageTitle: 'اسٹوریج کا انتظام',
    storageSubtitle: 'ڈاؤن لوڈ سورتیں دیکھیں، حذف کریں یا کیش صاف کریں',
    storageOpenBtn: 'اسٹوریج اور ڈاؤن لوڈ سورتوں کا انتظام',
    storageBackBtn: 'ترتیبات',
    storageTotalUsed: 'ایپ کا استعمال شدہ اسٹوریج',
    storageOfflineAudioLabel: 'آف لائن تلاوتیں',
    storageTextCacheLabel: 'محفوظ قرآنی متن اور ریڈیو کیش',
    storageAvailableDevice: 'فون میں دستیاب جگہ',
    storageDownloadedSurahsTitle: 'آف لائن سننے کے لیے ڈاؤن لوڈ سورتیں',
    storageNoDownloadedSurahs: 'فی الحال کوئی سورت آف لائن سننے کے لیے ڈاؤن لوڈ نہیں ہے۔',
    storageCachedTextsTitle: 'سورتوں کے متن کا کیش',
    storageNoCachedTexts: 'متن کی کیش میموری خالی ہے۔',
    storageDeleteSelected: 'منتخب شدہ حذف کریں',
    storageSelectAll: 'سب منتخب کریں',
    storageClearSelection: 'انتخاب ختم کریں',
    storageClearAudioOnly: 'تمام آف لائن تلاوتیں حذف کریں',
    storageClearAllCacheBtn: 'مکمل کیش صاف کریں',
    storageClearConfirmTitle: 'مکمل کیش صاف کریں؟',
    storageClearConfirmDesc: 'فون میں جگہ بچانے کے لیے تمام آف لائن سورتیں، محفوظ متن اور ریڈیو کیش حذف ہو جائے گا۔ آپ کی ترتیبات محفوظ رہیں گی۔',
    storageConfirmYes: 'ہاں، سب صاف کریں',
    storageCancel: 'منسوخ کریں',
    storageFreedBanner: 'جگہ خالی کر دی گئی:',
    storageSearchPlaceholder: 'سورت کا نام تلاش کریں...',
    storageSurahsCount: 'ڈاؤن لوڈ شدہ',
    istighfarSchedTitle: 'استغفار نوٹیفکیشن شیڈولر',
    istighfarSchedDesc: 'آپ کے منتخب کردہ اوقات پر Notification API کے ذریعے خودکار یاددہانی بھیجیں',
    notifPermGranted: 'سسٹم نوٹیفکیشنز فعال ہیں ✓',
    notifPermDenied: 'براؤزر میں بلاک ہیں (ایپ الرٹس فعال رہیں گے)',
    notifPermDefault: 'نوٹیفکیشن کی اجازت ابھی نہیں دی گئی',
    notifPermUnsupported: 'براؤزر سپورٹ نہیں کرتا (ایپ الرٹس فعال ہیں)',
    enableBrowserNotifBtn: 'براؤزر نوٹیفکیشنز فعال کریں',
    addReminderTimeLabel: 'نیا روزانہ یاددہانی کا وقت شامل کریں:',
    addReminderBtn: 'وقت شامل کریں',
    scheduledTimesTitle: 'شیڈول شدہ اوقات:',
    noScheduledTimes: 'کوئی وقت شامل نہیں کیا گیا۔',
    testNotifBtn: 'ٹیسٹ نوٹیفکیشن بھیجیں 🔔',
    testNotifSent: 'استغفار کا ٹیسٹ نوٹیفکیشن بھیج دیا گیا',
    nextReminderLabel: 'اگلی یاددہانی:',
    periodicReminderLabel: 'وقفه وار پس منظر یاددہانی:',
    everyMinutesLabel: 'ہر',
    appInfoTitle: 'ایپ کی معلومات',
    aboutBtn: 'رفیق القرآن کے بارے میں',
    preparedBy: 'تیار کردہ: الفقیر الی اللہ ممدوح ادریس صدیق',
    phoneLabel: 'موبائل:',
    duaTitle: 'ان کے اور ان کے والدین کے لیے دعا',
    tasmieTitle: 'براہ راست تسمیع (حفظ کی جانچ)',
    tasmieDesc: 'ایک آیت، چند آیات یا پوری سورت کا حفظ جانچنے کے لیے آیت کو چھپائیں اور تلاوت کریں۔',
    selectSurah: 'سورت منتخب کریں:',
    recitationScope: 'تسمیع کا دائرہ:',
    scopeSingle: 'ایک آیت',
    scopeRange: 'چند آیات',
    scopeFullSurah: 'پوری سورت',
    fromAyah: 'آیت سے:',
    toAyah: 'آیت تک:',
    ayahNumber: 'آیت نمبر:',
    hideAyahText: 'حفظ جانچنے کے لیے متن چھپائیں',
    showAyahText: 'متن دکھائیں',
    ayahHiddenPlaceholder: 'حفظ کی جانچ کے لیے آیات کا متن چھپایا گیا ہے... واضح آواز میں تلاوت شروع کریں',
    revealFirstWord: 'پہلے لفظ کا اشارہ',
    startTasmie: 'تلاوت شروع کریں',
    stopAndEvaluate: 'روکیں اور جانچیں',
    retryTasmie: 'دوبارہ تلاوت کریں',
    listeningPrompt: 'شروع کا بٹن دبائیں اور آیات کی تلاوت کریں',
    listeningActive: 'مائیکروفون کے ذریعے آپ کی تلاوت سنی جا رہی ہے...',
    accuracyScore: 'تلاوت کی درستگی:',
    transcriptTitle: 'پہچانی گئی تلاوت:',
    mistakesTitle: 'درستگی اور فرق کی نشاندہی:',
    prayerRegion: 'شہر اور علاقہ:',
    prayerTimeOffset: 'وقت میں تبدیلی (منٹ):',
    prayerTimesTitle: 'اوقات نماز',
    muezzinSection: 'موذن اور اذان کی آواز',
    chooseMuezzin: 'موذن منتخب کریں:',
    shortAdhanTitle: 'مختصر اذان (دو تکبیریں)',
    flipMuteTitle: 'فون الٹنے پر اذان بند کریں',
    testAdhanBtn: 'اذان سنیں 🔊',
    stopAdhanBtn: 'اذان روکیں ⏹',
    qiblaTitle: 'قبلہ',
    enableGps: 'GPS لوکیشن',
    prayerScheduleTab: 'اوقات نماز',
    nextPrayerLabel: 'اگلی نماز',
    remainingLabel: 'باقی وقت',
    cityClockLabel: 'مقامی وقت',
    fixQiblaTitle: 'قبلہ کی درستی',
    calibratePrompt: 'درستگی کے لیے قبلہ کی طرف رخ کریں',
    calibrateBtn: 'کیلیبریٹ کریں',
    recalibrateBtn: 'دوبارہ سیٹ کریں',
    chooseCalibrationType: 'کیلیبریشن کی قسم منتخب کریں',
    algoStandard: 'عام الگورتھم',
    algoGyro: 'جائروسکوپ الگورتھم',
    algoMagnetic: 'مقناطیسی الگورتھم',
    facingQiblaNow: 'آپ قبلہ رخ ہیں',
    distanceToKaaba: 'کعبہ سے فاصلہ',
    manualRotateHint: 'سمت جانچنے کے لیے گھمائیں',
    adhkarTabHisn: 'حصن المسلم',
    adhkarTabRosary: 'تسبیح',
    adhkarTabTimer: 'استغفار ٹائمر',
    radioTitle: 'براہ راست قرآن ریڈیو',
    radioSubtitle: 'عالمی قرآن ریڈیو اسٹیشنز براہ راست سنیں۔',
    radioStationsList: 'دستیاب ریڈیو اسٹیشنز:',
    repeatAndMemorize: 'تکرار اور حفظ',
    showTafsir: 'تفسیر دیکھیں',
    hideTafsir: 'تفسیر چھپائیں',
    listen: 'سنیں',
    stop: 'روکیں',
    download: 'ڈاؤن لوڈ',
    downloaded: 'محفوظ',
    prevPage: 'پچھلا صفحہ',
    nextPage: 'اگلا صفحہ',
    pageOf: 'صفحہ',
  },
};

export const getTranslations = (lang: AppLanguage): Translations => {
  return translationsMap[lang] || translationsMap.ar;
};
