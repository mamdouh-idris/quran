export interface TasmieHistoryItem {
  id: string;
  date: string;
  surahName: string;
  accuracy: number;
  correctCount: number;
  totalCount: number;
  mistakesCount: number;
}

export interface TasmieStatsRecord {
  totalSessions: number;
  correctWordsCount: number;
  mistakesCount: number;
  totalExpectedWords: number;
  averageAccuracy: number;
  history: TasmieHistoryItem[];
}

const STATS_STORAGE_KEY = 'rafiq_tasmie_stats_v2';

const DEFAULT_STATS: TasmieStatsRecord = {
  totalSessions: 0,
  correctWordsCount: 0,
  mistakesCount: 0,
  totalExpectedWords: 0,
  averageAccuracy: 0,
  history: [],
};

export function loadTasmieStats(): TasmieStatsRecord {
  try {
    const raw = localStorage.getItem(STATS_STORAGE_KEY);
    if (!raw) return DEFAULT_STATS;
    const parsed = JSON.parse(raw) as Partial<TasmieStatsRecord>;
    return {
      totalSessions: typeof parsed.totalSessions === 'number' ? parsed.totalSessions : 0,
      correctWordsCount: typeof parsed.correctWordsCount === 'number' ? parsed.correctWordsCount : 0,
      mistakesCount: typeof parsed.mistakesCount === 'number' ? parsed.mistakesCount : 0,
      totalExpectedWords: typeof parsed.totalExpectedWords === 'number' ? parsed.totalExpectedWords : 0,
      averageAccuracy: typeof parsed.averageAccuracy === 'number' ? parsed.averageAccuracy : 0,
      history: Array.isArray(parsed.history) ? parsed.history : [],
    };
  } catch {
    return DEFAULT_STATS;
  }
}

export function recordTasmieSession(session: {
  surahName: string;
  accuracy: number;
  correctCount: number;
  totalCount: number;
  mistakesCount: number;
}): TasmieStatsRecord {
  const current = loadTasmieStats();
  const newItem: TasmieHistoryItem = {
    id: `tasmie_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    date: new Date().toLocaleDateString('ar-SA', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
    surahName: session.surahName,
    accuracy: session.accuracy,
    correctCount: session.correctCount,
    totalCount: session.totalCount,
    mistakesCount: session.mistakesCount,
  };

  const newTotalSessions = current.totalSessions + 1;
  const newCorrectWords = current.correctWordsCount + session.correctCount;
  const newMistakes = current.mistakesCount + session.mistakesCount;
  const newTotalExpected = current.totalExpectedWords + session.totalCount;

  // Running weighted average accuracy
  const newAvgAcc = Math.round(
    ((current.averageAccuracy * current.totalSessions) + session.accuracy) / newTotalSessions
  );

  const updated: TasmieStatsRecord = {
    totalSessions: newTotalSessions,
    correctWordsCount: newCorrectWords,
    mistakesCount: newMistakes,
    totalExpectedWords: newTotalExpected,
    averageAccuracy: newAvgAcc,
    history: [newItem, ...current.history].slice(0, 30), // keep last 30 records
  };

  try {
    localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // Ignore quota errors
  }

  return updated;
}
