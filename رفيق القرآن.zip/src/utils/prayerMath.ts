import { AppLanguage } from '../types';

export interface CityLocation {
  id: string;
  name: string;
  englishName: string;
  lat: number;
  lng: number;
  tzOffset: number; // hours from UTC
}

export const CITIES_LIST: CityLocation[] = [
  { id: 'cairo', name: 'القاهرة، مصر', englishName: 'Cairo, Egypt', lat: 30.0444, lng: 31.2357, tzOffset: 2 },
  { id: 'makkah', name: 'مكة المكرمة، السعودية', englishName: 'Makkah, KSA', lat: 21.4225, lng: 39.8262, tzOffset: 3 },
  { id: 'madinah', name: 'المدينة المنورة، السعودية', englishName: 'Madinah, KSA', lat: 24.4672, lng: 39.6111, tzOffset: 3 },
  { id: 'riyadh', name: 'الرياض، السعودية', englishName: 'Riyadh, KSA', lat: 24.7136, lng: 46.6753, tzOffset: 3 },
  { id: 'dubai', name: 'دبي، الإمارات', englishName: 'Dubai, UAE', lat: 25.2048, lng: 55.2708, tzOffset: 4 },
  { id: 'amman', name: 'عمان، الأردن', englishName: 'Amman, Jordan', lat: 31.9454, lng: 35.9284, tzOffset: 3 },
  { id: 'jerusalem', name: 'القدس الشريف، فلسطين', englishName: 'Jerusalem', lat: 31.7767, lng: 35.2345, tzOffset: 2 },
  { id: 'istanbul', name: 'إسطنبول، تركيا', englishName: 'Istanbul, Turkey', lat: 41.0082, lng: 28.9784, tzOffset: 3 },
  { id: 'london', name: 'لندن، بريطانيا', englishName: 'London, UK', lat: 51.5072, lng: -0.1276, tzOffset: 0 },
];

export const KAABA_LAT = 21.422487;
export const KAABA_LNG = 39.826206;

export interface QiblaInfo {
  bearing: number;
  distanceKm: number;
}

export function calculateQiblaInfo(lat: number, lng: number): QiblaInfo {
  const toRad = Math.PI / 180;
  const phi1 = lat * toRad;
  const phi2 = KAABA_LAT * toRad;
  const deltaLambda = (KAABA_LNG - lng) * toRad;

  const y = Math.sin(deltaLambda) * Math.cos(phi2);
  const x =
    Math.cos(phi1) * Math.sin(phi2) -
    Math.sin(phi1) * Math.cos(phi2) * Math.cos(deltaLambda);
  const bearing = ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;

  const earthRadiusKm = 6371;
  const dLat = (KAABA_LAT - lat) * toRad;
  const dLng = (KAABA_LNG - lng) * toRad;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distanceKm = earthRadiusKm * c;

  return {
    bearing: Math.round(bearing),
    distanceKm: Number(distanceKm.toFixed(1)),
  };
}

export interface CalculatedPrayerItem {
  key: 'Fajr' | 'Sunrise' | 'Dhuhr' | 'Asr' | 'Maghrib' | 'Isha';
  arabicName: string;
  englishName: string;
  minutesFromMidnight: number;
  formattedTime: string;
  isObligatory: boolean;
}

const toArabicDigits = (value: string): string =>
  value.replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'[Number(d)]);

export function formatMinutesToClock(totalMinutes: number, lang: AppLanguage): string {
  const normalized = ((Math.round(totalMinutes) % 1440) + 1440) % 1440;
  const h24 = Math.floor(normalized / 60);
  const mins = normalized % 60;
  const isPm = h24 >= 12;
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  const raw = `${String(h12).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
  if (lang === 'ar' || lang === 'ur') {
    return `${toArabicDigits(raw)} ${isPm ? 'م' : 'ص'}`;
  }
  return `${raw} ${isPm ? 'PM' : 'AM'}`;
}

export function getCityLocalDate(now: Date, tzOffsetHours: number): Date {
  const utcMs = now.getTime() + now.getTimezoneOffset() * 60000;
  return new Date(utcMs + tzOffsetHours * 3600000);
}

export function calculatePrayerSchedule(
  cityDate: Date,
  lat: number,
  lng: number,
  tzOffsetHours: number,
  manualOffsetMinutes: number,
  lang: AppLanguage
): CalculatedPrayerItem[] {
  const rad = Math.PI / 180;
  const deg = 180 / Math.PI;

  const year = cityDate.getFullYear();
  const month = cityDate.getMonth() + 1;
  const day = cityDate.getDate();

  let y = year;
  let m = month;
  if (m <= 2) {
    y -= 1;
    m += 12;
  }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  const jd =
    Math.floor(365.25 * (y + 4716)) +
    Math.floor(30.6001 * (m + 1)) +
    day +
    B -
    1524.5;

  const D = jd - 2451545.0;
  const g = (((357.529 + 0.98560028 * D) % 360) + 360) % 360;
  const q = (((280.459 + 0.98564736 * D) % 360) + 360) % 360;
  const L = (((q + 1.915 * Math.sin(g * rad) + 0.02 * Math.sin(2 * g * rad)) % 360) + 360) % 360;
  const e = 23.439 - 0.00000036 * D;
  const RA = (Math.atan2(Math.cos(e * rad) * Math.sin(L * rad), Math.cos(L * rad)) * deg) / 15;
  const decl = Math.asin(Math.sin(e * rad) * Math.sin(L * rad)) * deg;

  let EqT = q / 15 - ((RA + 24) % 24);
  if (EqT > 12) EqT -= 24;
  if (EqT < -12) EqT += 24;

  const dhuhrHours = 12 + tzOffsetHours - lng / 15 - EqT;

  const sunAngleHours = (angle: number) => {
    const cosH =
      (-Math.sin(angle * rad) - Math.sin(lat * rad) * Math.sin(decl * rad)) /
      (Math.cos(lat * rad) * Math.cos(decl * rad));
    if (cosH >= 1) return 0;
    if (cosH <= -1) return 12;
    return (Math.acos(cosH) * deg) / 15;
  };

  const asrAngle = -Math.atan(1 / (1 + Math.tan(Math.abs(lat - decl) * rad))) * deg;

  // Use Egyptian/Umm Al-Qura standard twilight angles
  const fajrAngle = lat > 45 ? 18 : 19.5;
  const ishaAngle = lat > 45 ? 17 : 17.5;

  const fajrHours = dhuhrHours - sunAngleHours(fajrAngle);
  const sunriseHours = dhuhrHours - sunAngleHours(0.833);
  const asrHours = dhuhrHours + sunAngleHours(asrAngle);
  const maghribHours = dhuhrHours + sunAngleHours(0.833);
  const ishaHours = dhuhrHours + sunAngleHours(ishaAngle);

  const toMins = (h: number) => (((Math.round(h * 60 + manualOffsetMinutes) % 1440) + 1440) % 1440);

  const entries: Array<{
    key: CalculatedPrayerItem['key'];
    arabicName: string;
    englishName: string;
    hours: number;
    isObligatory: boolean;
  }> = [
    { key: 'Fajr', arabicName: 'الفجر', englishName: 'Fajr', hours: fajrHours, isObligatory: true },
    { key: 'Sunrise', arabicName: 'الشروق', englishName: 'Sunrise', hours: sunriseHours, isObligatory: false },
    { key: 'Dhuhr', arabicName: 'الظهر', englishName: 'Dhuhr', hours: dhuhrHours, isObligatory: true },
    { key: 'Asr', arabicName: 'العصر', englishName: 'Asr', hours: asrHours, isObligatory: true },
    { key: 'Maghrib', arabicName: 'المغرب', englishName: 'Maghrib', hours: maghribHours, isObligatory: true },
    { key: 'Isha', arabicName: 'العشاء', englishName: 'Isha', hours: ishaHours, isObligatory: true },
  ];

  return entries.map((item) => {
    const mins = toMins(item.hours);
    return {
      key: item.key,
      arabicName: item.arabicName,
      englishName: item.englishName,
      minutesFromMidnight: mins,
      formattedTime: formatMinutesToClock(mins, lang),
      isObligatory: item.isObligatory,
    };
  });
}

export interface NextPrayerCountdown {
  nextPrayer: CalculatedPrayerItem;
  previousPrayer: CalculatedPrayerItem;
  remainingSeconds: number;
  hoursLeft: number;
  minutesLeft: number;
  secondsLeft: number;
  progressPercent: number;
  isTomorrow: boolean;
}

export function getNextPrayerCountdown(
  schedule: CalculatedPrayerItem[],
  cityDate: Date
): NextPrayerCountdown {
  const obligatory = schedule.filter((p) => p.isObligatory);
  const currentTotalSeconds =
    cityDate.getHours() * 3600 + cityDate.getMinutes() * 60 + cityDate.getSeconds();

  let nextIdx = obligatory.findIndex((p) => p.minutesFromMidnight * 60 > currentTotalSeconds);
  let isTomorrow = false;

  if (nextIdx === -1) {
    nextIdx = 0;
    isTomorrow = true;
  }

  const nextPrayer = obligatory[nextIdx];
  const prevIdx = (nextIdx - 1 + obligatory.length) % obligatory.length;
  const previousPrayer = obligatory[prevIdx];

  const nextSec = nextPrayer.minutesFromMidnight * 60 + (isTomorrow ? 86400 : 0);
  const prevSec =
    previousPrayer.minutesFromMidnight * 60 - (nextIdx === 0 && !isTomorrow ? 86400 : 0);

  const remainingSeconds = Math.max(0, nextSec - currentTotalSeconds);
  const totalInterval = Math.max(1, nextSec - prevSec);
  const elapsed = Math.max(0, currentTotalSeconds - prevSec);
  const progressPercent = Math.min(100, Math.max(0, Math.round((elapsed / totalInterval) * 100)));

  const hoursLeft = Math.floor(remainingSeconds / 3600);
  const minutesLeft = Math.floor((remainingSeconds % 3600) / 60);
  const secondsLeft = remainingSeconds % 60;

  return {
    nextPrayer,
    previousPrayer,
    remainingSeconds,
    hoursLeft,
    minutesLeft,
    secondsLeft,
    progressPercent,
    isTomorrow,
  };
}
