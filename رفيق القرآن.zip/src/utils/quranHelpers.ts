import { Ayah } from '../types';

const normalizeForBismillahMatch = (word: string): string =>
  word
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640\u200B-\u200F]/g, '')
    .replace(/ٱ/g, 'ا');

/**
 * Strips any leading Bismillah from the first ayah of Surahs 2..8 and 10..114
 * regardless of Unicode diacritic/shadda ordering, Alif Wasla, or tatweel.
 */
export const stripLeadingBismillah = (text: string): string => {
  const trimmed = text.trim();
  const parts = trimmed.split(/\s+/);
  if (parts.length <= 4) return trimmed;

  if (
    normalizeForBismillahMatch(parts[0]) === 'بسم' &&
    normalizeForBismillahMatch(parts[1]) === 'الله' &&
    normalizeForBismillahMatch(parts[2]) === 'الرحمن' &&
    normalizeForBismillahMatch(parts[3]) === 'الرحيم'
  ) {
    const rest = parts.slice(4).join(' ').trim();
    if (rest.length > 0) return rest;
  }

  return trimmed;
};

export const sanitizeSurahAyahs = (surahNum: number, ayahs: Ayah[]): Ayah[] => {
  if (surahNum === 1 || surahNum === 9 || ayahs.length === 0) {
    return ayahs;
  }
  return ayahs.map((ayah, idx) =>
    idx === 0
      ? {
          ...ayah,
          text: stripLeadingBismillah(ayah.text || ''),
        }
      : ayah
  );
};
