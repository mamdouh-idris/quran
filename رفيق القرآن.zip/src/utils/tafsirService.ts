import { Ayah } from '../types';

export type TafsirBookId =
  | 'muyassar'
  | 'mukhtasar'
  | 'saadi'
  | 'jalalayn'
  | 'ibnkathir';

export interface TafsirBookMeta {
  id: TafsirBookId;
  name: string;
  shortName: string;
  description: string;
  spa5kSlug: string;
  alQuranFallbackEdition?: string;
}

export const TAFSIR_BOOKS: TafsirBookMeta[] = [
  {
    id: 'muyassar',
    name: 'التفسير الميسر',
    shortName: 'الميسر',
    description: 'عبارات واضحة ومباشرة لبيان معاني القرآن الكريم',
    spa5kSlug: 'ar-tafsir-muyassar',
    alQuranFallbackEdition: 'ar.muyassar',
  },
  {
    id: 'mukhtasar',
    name: 'المختصر في التفسير',
    shortName: 'المختصر',
    description: 'خلاصة مركزة وميسّرة لمقاصد الآيات ومعانيها',
    spa5kSlug: 'ar-tafsir-al-mukhtasar',
  },
  {
    id: 'saadi',
    name: 'تفسير السعدي',
    shortName: 'السعدي',
    description: 'تيسير الكريم الرحمن بأسلوب إيماني وتدبري سلس',
    spa5kSlug: 'ar-tafsir-as-saadi',
  },
  {
    id: 'jalalayn',
    name: 'تفسير الجلالين',
    shortName: 'الجلالين',
    description: 'إيجاز دقيق لبيان المفردات والتراكيب القرآنية',
    spa5kSlug: 'ar-tafsir-al-jalalayn',
    alQuranFallbackEdition: 'ar.jalalayn',
  },
  {
    id: 'ibnkathir',
    name: 'تفسير ابن كثير',
    shortName: 'ابن كثير',
    description: 'تفسير القرآن بالقرآن والسنة وأقوال السلف الصالح',
    spa5kSlug: 'ar-tafsir-ibn-kathir',
  },
];

const TAFSIR_CACHE_NAME = 'tafsir-data-cache';
const STORAGE_PREFIX = 'rafiq_tafsir_v1';

function buildCacheKey(bookId: TafsirBookId, surahNumber: number): string {
  return `${STORAGE_PREFIX}_${bookId}_${surahNumber}`;
}

export function cleanTafsirText(raw: string): string {
  return (raw || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

export function getCachedSurahTafsirSync(
  bookId: TafsirBookId,
  surahNumber: number
): Record<number, string> | null {
  try {
    const raw = localStorage.getItem(buildCacheKey(bookId, surahNumber));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Record<string, string>;
    if (!parsed || typeof parsed !== 'object') return null;
    const map: Record<number, string> = {};
    for (const [k, v] of Object.entries(parsed)) {
      const num = Number(k);
      if (num > 0 && typeof v === 'string' && v.trim()) {
        map[num] = v;
      }
    }
    return Object.keys(map).length > 0 ? map : null;
  } catch {
    return null;
  }
}

function saveSurahTafsirSync(
  bookId: TafsirBookId,
  surahNumber: number,
  map: Record<number, string>
) {
  try {
    localStorage.setItem(buildCacheKey(bookId, surahNumber), JSON.stringify(map));
  } catch {
    // Ignore storage quota errors
  }
}

export async function fetchSurahTafsir(
  bookId: TafsirBookId,
  surahNumber: number,
  fallbackAyahs?: Ayah[]
): Promise<{ data: Record<number, string>; fromCache: boolean }> {
  const local = getCachedSurahTafsirSync(bookId, surahNumber);
  if (local) {
    return { data: local, fromCache: true };
  }

  const book = TAFSIR_BOOKS.find((b) => b.id === bookId) || TAFSIR_BOOKS[0];
  const primaryUrl = `https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/${book.spa5kSlug}/${surahNumber}.json`;

  const tryReadFromCacheStorage = async (url: string): Promise<Response | null> => {
    if (typeof window === 'undefined' || !('caches' in window)) return null;
    try {
      const cache = await caches.open(TAFSIR_CACHE_NAME);
      const match = await cache.match(url);
      return match || null;
    } catch {
      return null;
    }
  };

  const writeToCacheStorage = async (url: string, res: Response) => {
    if (typeof window === 'undefined' || !('caches' in window)) return;
    try {
      const cache = await caches.open(TAFSIR_CACHE_NAME);
      await cache.put(url, res);
    } catch {
      // Ignore cache write failures
    }
  };

  // 1. Primary spa5k CDN API
  try {
    let res = await tryReadFromCacheStorage(primaryUrl);
    const cachedHit = Boolean(res);
    if (!res) {
      const netRes = await fetch(primaryUrl);
      if (netRes.ok) {
        await writeToCacheStorage(primaryUrl, netRes.clone());
        res = netRes;
      }
    }

    if (res && res.ok) {
      const items = (await res.json()) as Array<{ ayah?: number; text?: string }>;
      if (Array.isArray(items) && items.length > 0) {
        const resultMap: Record<number, string> = {};
        items.forEach((item, idx) => {
          const ayahNum = Number(item.ayah) || idx + 1;
          const txt = cleanTafsirText(item.text || '');
          if (txt) resultMap[ayahNum] = txt;
        });
        if (Object.keys(resultMap).length > 0) {
          saveSurahTafsirSync(bookId, surahNumber, resultMap);
          return { data: resultMap, fromCache: cachedHit };
        }
      }
    }
  } catch {
    // Fall through to secondary endpoint
  }

  // 2. Secondary AlQuran Cloud API (when supported for this edition)
  if (book.alQuranFallbackEdition) {
    const fallbackUrl = `https://api.alquran.cloud/v1/surah/${surahNumber}/${book.alQuranFallbackEdition}`;
    try {
      let res = await tryReadFromCacheStorage(fallbackUrl);
      const cachedHit = Boolean(res);
      if (!res) {
        const netRes = await fetch(fallbackUrl);
        if (netRes.ok) {
          await writeToCacheStorage(fallbackUrl, netRes.clone());
          res = netRes;
        }
      }
      if (res && res.ok) {
        const payload = await res.json();
        const ayahs = payload?.data?.ayahs;
        if (Array.isArray(ayahs) && ayahs.length > 0) {
          const resultMap: Record<number, string> = {};
          ayahs.forEach((item: { numberInSurah?: number; text?: string }, idx: number) => {
            const ayahNum = Number(item.numberInSurah) || idx + 1;
            const txt = cleanTafsirText(item.text || '');
            if (txt) resultMap[ayahNum] = txt;
          });
          if (Object.keys(resultMap).length > 0) {
            saveSurahTafsirSync(bookId, surahNumber, resultMap);
            return { data: resultMap, fromCache: cachedHit };
          }
        }
      }
    } catch {
      // Fall through to bundled ayahs
    }
  }

  // 3. Offline local fallback from bundled ayah object if available
  const bundled: Record<number, string> = {};
  if (fallbackAyahs) {
    fallbackAyahs.forEach((a) => {
      const candidate =
        bookId === 'saadi'
          ? a.tafsir?.saadi
          : bookId === 'ibnkathir'
          ? a.tafsir?.ibnkathir
          : a.tafsir?.jalalayn || a.tafsir?.saadi;
      if (candidate) bundled[a.number] = candidate;
    });
  }

  return { data: bundled, fromCache: false };
}

/**
 * Splits long Arabic Tafsir text into natural sentence chunks under ~200 chars
 * so browser SpeechSynthesis speaks entire paragraphs smoothly without Android/Chrome timeouts.
 */
export function splitTafsirForSpeech(text: string): string[] {
  const normalized = cleanTafsirText(text)
    .replace(/\{(\d+)\}/g, '')
    .trim();
  if (!normalized) return [];

  const rawSentences = normalized
    .split(/(?<=[.،؛:!؟\n])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const chunks: string[] = [];
  let current = '';

  for (const sentence of rawSentences) {
    if ((current + ' ' + sentence).trim().length <= 190) {
      current = current ? `${current} ${sentence}` : sentence;
    } else {
      if (current) chunks.push(current);
      if (sentence.length <= 190) {
        current = sentence;
      } else {
        // Hard-wrap ultra-long unpunctuated sentences by words
        const words = sentence.split(/\s+/);
        let part = '';
        for (const w of words) {
          if ((part + ' ' + w).trim().length <= 180) {
            part = part ? `${part} ${w}` : w;
          } else {
            if (part) chunks.push(part);
            part = w;
          }
        }
        current = part;
      }
    }
  }
  if (current) chunks.push(current);
  return chunks;
}
