import { AppAccentColor, AppTheme, QuranFontFamily } from '../types';

export interface FontOption {
  id: QuranFontFamily;
  name: string;
  description: string;
  className: string;
}

export const FONT_OPTIONS: FontOption[] = [
  { id: 'Amiri Quran', name: 'أميري القرآن', description: 'خط مصحفي عثماني فصيح ومضبوط', className: 'font-amiri-quran' },
  { id: 'Amiri', name: 'أميري الأصيل', description: 'خط نسخ تقليدي فصيح', className: 'font-amiri' },
  { id: 'Scheherazade New', name: 'شهرزاد العثماني', description: 'خط مصحفي واضح ومشكّل', className: 'font-scheherazade' },
  { id: 'Noto Naskh Arabic', name: 'نوتو نسخ', description: 'خط نسخ رقمي متوازن', className: 'font-noto-naskh' },
  { id: 'Markazi Text', name: 'مركزي الأصيل', description: 'خط نسخ كلاسيكي مريح للعين', className: 'font-markazi' },
  { id: 'Lateef', name: 'خط لطيف', description: 'خط نستعليق/نسخ ناعم', className: 'font-lateef' },
  { id: 'Aref Ruqaa', name: 'عارف رقعة', description: 'خط الرقعة العربي الأصيل', className: 'font-aref-ruqaa' },
  { id: 'Reem Kufi', name: 'ريم كوفي', description: 'خط كوفي هندسي مميز', className: 'font-reem-kufi' },
  { id: 'Cairo', name: 'كايرو الحديث', description: 'خط عصري واضح القراءة', className: 'font-cairo' },
  { id: 'Tajawal', name: 'تجوال العصري', description: 'خط حديث خفيف ومريح', className: 'font-tajawal' },
  { id: 'IBM Plex Sans Arabic', name: 'بلكس العربي', description: 'خط هندسي متناسق وعالي الدقة', className: 'font-ibm-plex' },
  { id: 'Readex Pro', name: 'ريدكس للقراءة', description: 'خط قراءة رقمي حديث وواضح', className: 'font-readex-pro' },
  { id: 'Almarai', name: 'المراعي الأنيق', description: 'خط عربي ناعم وسهل التصفح', className: 'font-almarai' },
];

export const THEME_OPTIONS: {
  id: AppTheme;
  name: string;
  previewClass: string;
}[] = [
  { id: 'dark', name: 'ليلي داكن', previewClass: 'bg-slate-950 border-slate-700 text-slate-100' },
  { id: 'sepia', name: 'بني دافئ', previewClass: 'bg-[#2b261f] border-[#5b4d3c] text-amber-100' },
  { id: 'emerald', name: 'زمردي أخضر', previewClass: 'bg-emerald-950 border-emerald-700 text-emerald-100' },
  { id: 'gold', name: 'ذهبي ملكي', previewClass: 'bg-[#1f1b13] border-amber-600/70 text-amber-200' },
  { id: 'navy', name: 'أزرق ليلي', previewClass: 'bg-[#0b1528] border-sky-800 text-sky-100' },
  { id: 'plum', name: 'عنابي هادئ', previewClass: 'bg-[#1e1222] border-purple-800 text-purple-100' },
  { id: 'teal', name: 'تركواز عميق', previewClass: 'bg-[#091e21] border-teal-700 text-teal-100' },
  { id: 'light', name: 'نهاري مضيء', previewClass: 'bg-[#f8f6f0] border-stone-300 text-stone-900' },
];

export const ACCENT_OPTIONS: {
  id: AppAccentColor;
  name: string;
  swatchClass: string;
}[] = [
  { id: 'emerald', name: 'زمردي', swatchClass: 'bg-emerald-500' },
  { id: 'green', name: 'أخضر', swatchClass: 'bg-green-500' },
  { id: 'teal', name: 'فيروزي', swatchClass: 'bg-teal-500' },
  { id: 'cyan', name: 'مائي', swatchClass: 'bg-cyan-500' },
  { id: 'sky', name: 'سماوي', swatchClass: 'bg-sky-500' },
  { id: 'indigo', name: 'نيلي', swatchClass: 'bg-indigo-500' },
  { id: 'violet', name: 'بنفسجي', swatchClass: 'bg-violet-500' },
  { id: 'fuchsia', name: 'أرجواني', swatchClass: 'bg-fuchsia-500' },
  { id: 'rose', name: 'وردي', swatchClass: 'bg-rose-500' },
  { id: 'red', name: 'قرمزي', swatchClass: 'bg-red-500' },
  { id: 'orange', name: 'برتقالي', swatchClass: 'bg-orange-500' },
  { id: 'amber', name: 'ذهبي', swatchClass: 'bg-amber-500' },
];

export function getFontClass(fontFamily: QuranFontFamily): string {
  const found = FONT_OPTIONS.find((f) => f.id === fontFamily);
  return found ? found.className : 'font-amiri';
}

export function getFontSizeClass(fontSize: number): string {
  const clamped = Math.min(42, Math.max(16, Math.round(fontSize)));
  const map: Record<number, string> = {
    16: 'text-[16px]',
    17: 'text-[17px]',
    18: 'text-[18px]',
    19: 'text-[19px]',
    20: 'text-[20px]',
    21: 'text-[21px]',
    22: 'text-[22px]',
    23: 'text-[23px]',
    24: 'text-[24px]',
    25: 'text-[25px]',
    26: 'text-[26px]',
    27: 'text-[27px]',
    28: 'text-[28px]',
    29: 'text-[29px]',
    30: 'text-[30px]',
    31: 'text-[31px]',
    32: 'text-[32px]',
    33: 'text-[33px]',
    34: 'text-[34px]',
    35: 'text-[35px]',
    36: 'text-[36px]',
    37: 'text-[37px]',
    38: 'text-[38px]',
    39: 'text-[39px]',
    40: 'text-[40px]',
    41: 'text-[41px]',
    42: 'text-[42px]',
  };
  return map[clamped] || 'text-[24px]';
}

export interface ThemeStyles {
  isLight: boolean;
  appBg: string;
  navBg: string;
  phoneBg: string;
  surfaceBg: string;
  cardBg: string;
  subSurfaceBg: string;
  border: string;
  textPrimary: string;
  textSecondary: string;
  mushafText: string;
  accentBg: string;
  accentText: string;
  accentSoftBg: string;
  accentBorder: string;
  accentRing: string;
  progressBarBg: string;
}

export function getThemeStyles(
  theme: AppTheme,
  accentColor: AppAccentColor,
  readingMode: boolean
): ThemeStyles {
  const effectiveTheme: AppTheme = readingMode ? 'sepia' : theme;
  const isLight = effectiveTheme === 'light';

  const baseByTheme: Record<
    AppTheme,
    Pick<
      ThemeStyles,
      'appBg' | 'navBg' | 'phoneBg' | 'surfaceBg' | 'cardBg' | 'subSurfaceBg' | 'border' | 'textPrimary' | 'textSecondary' | 'mushafText'
    >
  > = {
    dark: {
      appBg: 'bg-slate-950 text-slate-100',
      navBg: 'bg-slate-900/90 border-slate-800',
      phoneBg: 'bg-slate-950 text-slate-100',
      surfaceBg: 'bg-slate-900/95',
      cardBg: 'bg-slate-900',
      subSurfaceBg: 'bg-slate-950',
      border: 'border-slate-800',
      textPrimary: 'text-slate-100',
      textSecondary: 'text-slate-400',
      mushafText: 'text-slate-100',
    },
    sepia: {
      appBg: 'bg-[#17130e] text-[#efe5d5]',
      navBg: 'bg-[#221c15]/95 border-[#3f3427]',
      phoneBg: 'bg-[#1b1712] text-[#efe5d5]',
      surfaceBg: 'bg-[#241e17]',
      cardBg: 'bg-[#29221a]',
      subSurfaceBg: 'bg-[#1a1510]',
      border: 'border-[#45392b]',
      textPrimary: 'text-[#f3eadb]',
      textSecondary: 'text-[#bcae99]',
      mushafText: 'text-[#f5ebd9]',
    },
    emerald: {
      appBg: 'bg-[#031914] text-emerald-50',
      navBg: 'bg-[#06261e]/95 border-emerald-900/60',
      phoneBg: 'bg-[#041d17] text-emerald-50',
      surfaceBg: 'bg-[#072a21]',
      cardBg: 'bg-[#093228]',
      subSurfaceBg: 'bg-[#041914]',
      border: 'border-emerald-800/60',
      textPrimary: 'text-emerald-50',
      textSecondary: 'text-emerald-300/75',
      mushafText: 'text-emerald-50',
    },
    gold: {
      appBg: 'bg-[#14110a] text-amber-50',
      navBg: 'bg-[#1f1a10]/95 border-amber-800/50',
      phoneBg: 'bg-[#18140c] text-amber-50',
      surfaceBg: 'bg-[#231d12]',
      cardBg: 'bg-[#292215]',
      subSurfaceBg: 'bg-[#14110a]',
      border: 'border-amber-800/50',
      textPrimary: 'text-amber-50',
      textSecondary: 'text-amber-200/70',
      mushafText: 'text-amber-50',
    },
    navy: {
      appBg: 'bg-[#060d1c] text-sky-50',
      navBg: 'bg-[#0b1730]/95 border-sky-900/60',
      phoneBg: 'bg-[#081124] text-sky-50',
      surfaceBg: 'bg-[#0e1b36]',
      cardBg: 'bg-[#122242]',
      subSurfaceBg: 'bg-[#070f20]',
      border: 'border-sky-800/60',
      textPrimary: 'text-sky-50',
      textSecondary: 'text-sky-300/75',
      mushafText: 'text-sky-50',
    },
    plum: {
      appBg: 'bg-[#140b18] text-purple-50',
      navBg: 'bg-[#211328]/95 border-purple-900/60',
      phoneBg: 'bg-[#180d1d] text-purple-50',
      surfaceBg: 'bg-[#25152c]',
      cardBg: 'bg-[#2d1a36]',
      subSurfaceBg: 'bg-[#150b19]',
      border: 'border-purple-800/50',
      textPrimary: 'text-purple-50',
      textSecondary: 'text-purple-300/75',
      mushafText: 'text-purple-50',
    },
    teal: {
      appBg: 'bg-[#05181b] text-teal-50',
      navBg: 'bg-[#0a262b]/95 border-teal-900/60',
      phoneBg: 'bg-[#061c20] text-teal-50',
      surfaceBg: 'bg-[#0b2a30]',
      cardBg: 'bg-[#0f333a]',
      subSurfaceBg: 'bg-[#05171a]',
      border: 'border-teal-800/60',
      textPrimary: 'text-teal-50',
      textSecondary: 'text-teal-300/75',
      mushafText: 'text-teal-50',
    },
    light: {
      appBg: 'bg-[#f4f1ea] text-stone-900',
      navBg: 'bg-[#faf8f3]/95 border-stone-200',
      phoneBg: 'bg-[#fbf9f4] text-stone-900',
      surfaceBg: 'bg-white',
      cardBg: 'bg-[#f3efe6]',
      subSurfaceBg: 'bg-[#ebe5d8]',
      border: 'border-stone-300',
      textPrimary: 'text-stone-900',
      textSecondary: 'text-stone-600',
      mushafText: 'text-stone-900',
    },
  };

  const accentMap: Record<
    AppAccentColor,
    Pick<
      ThemeStyles,
      'accentBg' | 'accentText' | 'accentSoftBg' | 'accentBorder' | 'accentRing' | 'progressBarBg'
    >
  > = {
    emerald: {
      accentBg: 'bg-emerald-600 hover:bg-emerald-500 text-white',
      accentText: isLight ? 'text-emerald-700' : 'text-emerald-400',
      accentSoftBg: isLight ? 'bg-emerald-100/80 text-emerald-900' : 'bg-emerald-950/50 text-emerald-200',
      accentBorder: isLight ? 'border-emerald-300' : 'border-emerald-700/60',
      accentRing: 'ring-emerald-500',
      progressBarBg: 'bg-emerald-500',
    },
    amber: {
      accentBg: 'bg-amber-600 hover:bg-amber-500 text-white',
      accentText: isLight ? 'text-amber-700' : 'text-amber-400',
      accentSoftBg: isLight ? 'bg-amber-100/80 text-amber-900' : 'bg-amber-950/50 text-amber-200',
      accentBorder: isLight ? 'border-amber-300' : 'border-amber-700/60',
      accentRing: 'ring-amber-500',
      progressBarBg: 'bg-amber-500',
    },
    sky: {
      accentBg: 'bg-sky-600 hover:bg-sky-500 text-white',
      accentText: isLight ? 'text-sky-700' : 'text-sky-400',
      accentSoftBg: isLight ? 'bg-sky-100/80 text-sky-900' : 'bg-sky-950/50 text-sky-200',
      accentBorder: isLight ? 'border-sky-300' : 'border-sky-700/60',
      accentRing: 'ring-sky-500',
      progressBarBg: 'bg-sky-500',
    },
    teal: {
      accentBg: 'bg-teal-600 hover:bg-teal-500 text-white',
      accentText: isLight ? 'text-teal-700' : 'text-teal-400',
      accentSoftBg: isLight ? 'bg-teal-100/80 text-teal-900' : 'bg-teal-950/50 text-teal-200',
      accentBorder: isLight ? 'border-teal-300' : 'border-teal-700/60',
      accentRing: 'ring-teal-500',
      progressBarBg: 'bg-teal-500',
    },
    violet: {
      accentBg: 'bg-violet-600 hover:bg-violet-500 text-white',
      accentText: isLight ? 'text-violet-700' : 'text-violet-400',
      accentSoftBg: isLight ? 'bg-violet-100/80 text-violet-900' : 'bg-violet-950/50 text-violet-200',
      accentBorder: isLight ? 'border-violet-300' : 'border-violet-700/60',
      accentRing: 'ring-violet-500',
      progressBarBg: 'bg-violet-500',
    },
    rose: {
      accentBg: 'bg-rose-600 hover:bg-rose-500 text-white',
      accentText: isLight ? 'text-rose-700' : 'text-rose-400',
      accentSoftBg: isLight ? 'bg-rose-100/80 text-rose-900' : 'bg-rose-950/50 text-rose-200',
      accentBorder: isLight ? 'border-rose-300' : 'border-rose-700/60',
      accentRing: 'ring-rose-500',
      progressBarBg: 'bg-rose-500',
    },
    indigo: {
      accentBg: 'bg-indigo-600 hover:bg-indigo-500 text-white',
      accentText: isLight ? 'text-indigo-700' : 'text-indigo-400',
      accentSoftBg: isLight ? 'bg-indigo-100/80 text-indigo-900' : 'bg-indigo-950/50 text-indigo-200',
      accentBorder: isLight ? 'border-indigo-300' : 'border-indigo-700/60',
      accentRing: 'ring-indigo-500',
      progressBarBg: 'bg-indigo-500',
    },
    cyan: {
      accentBg: 'bg-cyan-600 hover:bg-cyan-500 text-white',
      accentText: isLight ? 'text-cyan-700' : 'text-cyan-400',
      accentSoftBg: isLight ? 'bg-cyan-100/80 text-cyan-900' : 'bg-cyan-950/50 text-cyan-200',
      accentBorder: isLight ? 'border-cyan-300' : 'border-cyan-700/60',
      accentRing: 'ring-cyan-500',
      progressBarBg: 'bg-cyan-500',
    },
    green: {
      accentBg: 'bg-green-600 hover:bg-green-500 text-white',
      accentText: isLight ? 'text-green-700' : 'text-green-400',
      accentSoftBg: isLight ? 'bg-green-100/80 text-green-900' : 'bg-green-950/50 text-green-200',
      accentBorder: isLight ? 'border-green-300' : 'border-green-700/60',
      accentRing: 'ring-green-500',
      progressBarBg: 'bg-green-500',
    },
    orange: {
      accentBg: 'bg-orange-600 hover:bg-orange-500 text-white',
      accentText: isLight ? 'text-orange-700' : 'text-orange-400',
      accentSoftBg: isLight ? 'bg-orange-100/80 text-orange-900' : 'bg-orange-950/50 text-orange-200',
      accentBorder: isLight ? 'border-orange-300' : 'border-orange-700/60',
      accentRing: 'ring-orange-500',
      progressBarBg: 'bg-orange-500',
    },
    fuchsia: {
      accentBg: 'bg-fuchsia-600 hover:bg-fuchsia-500 text-white',
      accentText: isLight ? 'text-fuchsia-700' : 'text-fuchsia-400',
      accentSoftBg: isLight ? 'bg-fuchsia-100/80 text-fuchsia-900' : 'bg-fuchsia-950/50 text-fuchsia-200',
      accentBorder: isLight ? 'border-fuchsia-300' : 'border-fuchsia-700/60',
      accentRing: 'ring-fuchsia-500',
      progressBarBg: 'bg-fuchsia-500',
    },
    red: {
      accentBg: 'bg-red-600 hover:bg-red-500 text-white',
      accentText: isLight ? 'text-red-700' : 'text-red-400',
      accentSoftBg: isLight ? 'bg-red-100/80 text-red-900' : 'bg-red-950/50 text-red-200',
      accentBorder: isLight ? 'border-red-300' : 'border-red-700/60',
      accentRing: 'ring-red-500',
      progressBarBg: 'bg-red-500',
    },
  };

  return {
    isLight,
    ...baseByTheme[effectiveTheme],
    ...accentMap[accentColor],
  };
}
