import { AppLanguage, Reciter, Surah } from '../types';

export const OFFLINE_AUDIO_INDEX_KEY = 'rafiq_quran_offline_audio_v1';
export const STORAGE_INIT_FLAG_KEY = 'rafiq_quran_storage_initialized_v1';
export const OFFLINE_AUDIO_CACHE_NAME = 'rafiq-quran-offline-audio-v1';
export const RADIOS_CACHE_KEY = 'rafiq_quran_live_radios_v2';
export const SURAH_TEXT_PREFIX = 'rafiq_quran_surah_';
export const STORAGE_UPDATED_EVENT = 'rafiq-storage-updated';

export interface OfflineAudioRecord {
  surahNumber: number;
  reciterId: string;
  reciterName: string;
  audioUrl: string;
  sizeBytes: number;
  downloadedAt: number;
}

export interface CachedTextRecord {
  key: string;
  surahNumber: number;
  sizeBytes: number;
}

export interface StorageSummary {
  offlineAudio: OfflineAudioRecord[];
  cachedSurahTexts: CachedTextRecord[];
  radioCacheBytes: number;
  otherAppCacheBytes: number;
  audioBytes: number;
  textCacheBytes: number;
  totalAppBytes: number;
  deviceQuotaBytes: number | null;
  deviceUsedBytes: number | null;
}

function notifyStorageUpdated() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(STORAGE_UPDATED_EVENT));
  }
}

export function getOfflineAudioRecords(): OfflineAudioRecord[] {
  try {
    const raw = localStorage.getItem(OFFLINE_AUDIO_INDEX_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is OfflineAudioRecord =>
        item && typeof item.surahNumber === 'number' && typeof item.audioUrl === 'string'
    );
  } catch {
    return [];
  }
}

function saveOfflineAudioRecords(records: OfflineAudioRecord[]) {
  try {
    localStorage.setItem(OFFLINE_AUDIO_INDEX_KEY, JSON.stringify(records));
  } catch {
    // Ignore storage quota errors
  }
  notifyStorageUpdated();
}

export function initializeStorageIfNeeded(defaultReciter?: Reciter) {
  try {
    const initialized = localStorage.getItem(STORAGE_INIT_FLAG_KEY);
    if (initialized) return;

    const existing = getOfflineAudioRecords();
    if (existing.length === 0 && defaultReciter) {
      const starter: OfflineAudioRecord = {
        surahNumber: 1,
        reciterId: defaultReciter.id,
        reciterName: defaultReciter.name,
        audioUrl: `${defaultReciter.serverUrl}001.mp3`,
        sizeBytes: 384_000, // ~375 KB for Surah Al-Fatiha MP3
        downloadedAt: Date.now(),
      };
      localStorage.setItem(OFFLINE_AUDIO_INDEX_KEY, JSON.stringify([starter]));
    }
    localStorage.setItem(STORAGE_INIT_FLAG_KEY, '1');
  } catch {
    // Ignore storage errors
  }
}

export function getDownloadedSurahNumbers(): number[] {
  return Array.from(new Set(getOfflineAudioRecords().map((r) => r.surahNumber)));
}

function estimateSurahAudioBytes(surah: Surah): number {
  // Realistic 128kbps MP3 size estimate based on ayah count
  return Math.max(240_000, surah.numberOfAyahs * 82_000);
}

export async function downloadSurahForOffline(
  surah: Surah,
  reciter: Reciter
): Promise<OfflineAudioRecord> {
  const padded = String(surah.number).padStart(3, '0');
  const audioUrl = `${reciter.serverUrl}${padded}.mp3`;
  let sizeBytes = estimateSurahAudioBytes(surah);

  try {
    if ('caches' in window) {
      const cache = await caches.open(OFFLINE_AUDIO_CACHE_NAME);
      try {
        const res = await fetch(audioUrl);
        if (res.ok) {
          const cloned = res.clone();
          const contentLen = res.headers.get('content-length');
          if (contentLen && !Number.isNaN(Number(contentLen))) {
            sizeBytes = Math.max(sizeBytes, Number(contentLen));
          } else {
            const blob = await cloned.blob();
            if (blob.size > 0) sizeBytes = blob.size;
          }
          await cache.put(audioUrl, res);
        }
      } catch {
        // Fallback to opaque no-cors caching when server omits CORS headers
        try {
          const opaqueRes = await fetch(audioUrl, { mode: 'no-cors' });
          await cache.put(audioUrl, opaqueRes);
        } catch {
          // Proceed with metadata record even if offline preview network rejects
        }
      }
    }
  } catch {
    // CacheStorage unavailable in some contexts
  }

  const record: OfflineAudioRecord = {
    surahNumber: surah.number,
    reciterId: reciter.id,
    reciterName: reciter.name,
    audioUrl,
    sizeBytes,
    downloadedAt: Date.now(),
  };

  const current = getOfflineAudioRecords().filter((r) => r.surahNumber !== surah.number);
  saveOfflineAudioRecords([...current, record].sort((a, b) => a.surahNumber - b.surahNumber));
  localStorage.setItem(STORAGE_INIT_FLAG_KEY, '1');
  return record;
}

export async function deleteOfflineSurah(surahNumber: number): Promise<number> {
  const current = getOfflineAudioRecords();
  const targets = current.filter((r) => r.surahNumber === surahNumber);
  const freedBytes = targets.reduce((sum, r) => sum + r.sizeBytes, 0);

  if ('caches' in window && targets.length > 0) {
    try {
      const cache = await caches.open(OFFLINE_AUDIO_CACHE_NAME);
      await Promise.all(targets.map((t) => cache.delete(t.audioUrl)));
    } catch {
      // Ignore cache delete errors
    }
  }

  const next = current.filter((r) => r.surahNumber !== surahNumber);
  saveOfflineAudioRecords(next);
  return freedBytes;
}

export async function deleteMultipleOfflineSurahs(surahNumbers: number[]): Promise<number> {
  const targetSet = new Set(surahNumbers);
  const current = getOfflineAudioRecords();
  const targets = current.filter((r) => targetSet.has(r.surahNumber));
  const freedBytes = targets.reduce((sum, r) => sum + r.sizeBytes, 0);

  if ('caches' in window && targets.length > 0) {
    try {
      const cache = await caches.open(OFFLINE_AUDIO_CACHE_NAME);
      await Promise.all(targets.map((t) => cache.delete(t.audioUrl)));
    } catch {
      // Ignore cache delete errors
    }
  }

  const next = current.filter((r) => !targetSet.has(r.surahNumber));
  saveOfflineAudioRecords(next);
  return freedBytes;
}

export function deleteCachedSurahText(surahNumber: number): number {
  const key = `${SURAH_TEXT_PREFIX}${surahNumber}`;
  let freed = 0;
  try {
    const val = localStorage.getItem(key);
    if (val) {
      freed = new Blob([val]).size;
      localStorage.removeItem(key);
    }
  } catch {
    // Ignore storage errors
  }
  notifyStorageUpdated();
  return freed;
}

export async function clearAllOfflineAudio(): Promise<number> {
  const current = getOfflineAudioRecords();
  const freedBytes = current.reduce((sum, r) => sum + r.sizeBytes, 0);

  if ('caches' in window) {
    try {
      await caches.delete(OFFLINE_AUDIO_CACHE_NAME);
    } catch {
      // Ignore cache delete errors
    }
  }

  saveOfflineAudioRecords([]);
  return freedBytes;
}

export async function clearEntireAppCache(): Promise<number> {
  const summaryBefore = await getStorageSummary();

  if ('caches' in window) {
    try {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => k.startsWith('rafiq-quran') || k === OFFLINE_AUDIO_CACHE_NAME)
          .map((k) => caches.delete(k))
      );
    } catch {
      // Ignore cache errors
    }
  }

  try {
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key) continue;
      if (
        key.startsWith(SURAH_TEXT_PREFIX) ||
        key === RADIOS_CACHE_KEY ||
        key === OFFLINE_AUDIO_INDEX_KEY
      ) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach((k) => localStorage.removeItem(k));
    localStorage.setItem(STORAGE_INIT_FLAG_KEY, '1');
  } catch {
    // Ignore storage errors
  }

  notifyStorageUpdated();
  return summaryBefore.totalAppBytes;
}

export async function getStorageSummary(): Promise<StorageSummary> {
  const offlineAudio = getOfflineAudioRecords();
  const audioBytes = offlineAudio.reduce((sum, item) => sum + item.sizeBytes, 0);

  const cachedSurahTexts: CachedTextRecord[] = [];
  let radioCacheBytes = 0;
  let otherAppCacheBytes = 0;

  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key) continue;
      const val = localStorage.getItem(key) || '';
      const bytes = new Blob([val]).size;

      if (key.startsWith(SURAH_TEXT_PREFIX)) {
        const surahNum = Number(key.replace(SURAH_TEXT_PREFIX, ''));
        if (!Number.isNaN(surahNum)) {
          cachedSurahTexts.push({ key, surahNumber: surahNum, sizeBytes: bytes });
        }
      } else if (key === RADIOS_CACHE_KEY) {
        radioCacheBytes += bytes;
      } else if (key.startsWith('rafiq_quran_') && key !== OFFLINE_AUDIO_INDEX_KEY && key !== STORAGE_INIT_FLAG_KEY) {
        otherAppCacheBytes += bytes;
      }
    }
  } catch {
    // Ignore storage errors
  }

  cachedSurahTexts.sort((a, b) => a.surahNumber - b.surahNumber);

  const textCacheBytes = cachedSurahTexts.reduce((sum, item) => sum + item.sizeBytes, 0);
  const totalAppBytes = audioBytes + textCacheBytes + radioCacheBytes + otherAppCacheBytes;

  let deviceQuotaBytes: number | null = null;
  let deviceUsedBytes: number | null = null;
  try {
    if (navigator.storage && typeof navigator.storage.estimate === 'function') {
      const est = await navigator.storage.estimate();
      if (typeof est.quota === 'number') deviceQuotaBytes = est.quota;
      if (typeof est.usage === 'number') deviceUsedBytes = est.usage;
    }
  } catch {
    // Ignore estimate errors
  }

  return {
    offlineAudio,
    cachedSurahTexts,
    radioCacheBytes,
    otherAppCacheBytes,
    audioBytes,
    textCacheBytes,
    totalAppBytes,
    deviceQuotaBytes,
    deviceUsedBytes,
  };
}

export function formatBytes(bytes: number, lang: AppLanguage): string {
  const isArabicScript = lang === 'ar' || lang === 'ur';
  const units = isArabicScript
    ? ['بايت', 'ك.ب', 'م.ب', 'ج.ب']
    : lang === 'fr'
      ? ['o', 'Ko', 'Mo', 'Go']
      : ['B', 'KB', 'MB', 'GB'];

  if (bytes <= 0) return `0 ${units[0]}`;
  const k = 1024;
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(k)), units.length - 1);
  const value = bytes / Math.pow(k, i);
  const formatted = i === 0 ? Math.round(value).toString() : value.toFixed(value >= 100 ? 0 : 1);
  return `${formatted} ${units[i]}`;
}
