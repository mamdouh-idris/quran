export interface ExpectedWordEntry {
  word: string;
  cleanWord: string;
  ayahNumber: number;
}

export type WordMatchStatus = 'matched' | 'mismatch' | 'missed';

export interface AlignedWordResult {
  ayahNumber: number;
  wordIndex: number;
  expectedWord: string;
  spokenWord: string;
  status: WordMatchStatus;
}

export interface RecitationEvaluation {
  accuracy: number;
  matchedCount: number;
  totalCount: number;
  alignedWords: AlignedWordResult[];
  mistakes: Array<{
    ayahNumber: number;
    wordIndex: number;
    expectedWord: string;
    spokenWord: string;
    correction: string;
  }>;
}

const CANONICAL_PAIRS: Record<string, string> = {
  الرحمان: 'الرحمن',
  الصلوه: 'الصلاه',
  الزكوه: 'الزكاه',
  الحيوه: 'الحياه',
  ملك: 'مالك',
  السموت: 'السماوات',
  سموت: 'سماوات',
  السموات: 'السماوات',
  هاذا: 'هذا',
  هاذه: 'هذه',
  هؤلا: 'هولا',
  هؤلاء: 'هولا',
  لاكن: 'لكن',
  يايها: 'ياايها',
  باسم: 'بسم',
  تبرك: 'تبارك',
  العلمين: 'العالمين',
  المستقم: 'المستقيم',
};

/**
 * Normalizes Arabic text for phonetic & orthographic comparison between
 * Uthmani script and Web Speech API transcripts.
 */
export function normalizeArabicWordForTasmie(word: string): string {
  const cleaned = word
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640\u200B-\u200F]/g, '')
    .replace(/[۞۝ۚۖۗۘۙۛ،؛؟.,!:"'()«»\-]/g, '')
    .replace(/ٱ/g, 'ا')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .trim();

  return CANONICAL_PAIRS[cleaned] || cleaned;
}

function editDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  const dp: number[] = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= n; j++) {
      const temp = dp[j];
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[j] = Math.min(dp[j] + 1, dp[j - 1] + 1, prev + cost);
      prev = temp;
    }
  }
  return dp[n];
}

export function areQuranWordsEquivalent(spokenClean: string, expectedClean: string): boolean {
  if (!spokenClean || !expectedClean) return false;
  if (spokenClean === expectedClean) return true;
  // Allow single-character STT tolerance for longer Quranic words (e.g., missed silent alef/waw)
  if (expectedClean.length >= 5 && spokenClean.length >= 4) {
    return editDistance(spokenClean, expectedClean) <= 1;
  }
  return false;
}

/**
 * Prevents Android/Chrome SpeechRecognition's cumulative-buffer bug where `event.results[i]`
 * repeats earlier finalized utterances or restarts from the first ayah.
 */
export function mergeSpeechChunkWithoutRepetition(
  accumulatedText: string,
  incomingChunk: string
): string {
  const accWords = accumulatedText.trim().split(/\s+/).filter(Boolean);
  const incWords = incomingChunk.trim().split(/\s+/).filter(Boolean);

  if (incWords.length === 0) return accumulatedText.trim();
  if (accWords.length === 0) return incWords.join(' ');

  const accNorm = accWords.map(normalizeArabicWordForTasmie);
  const incNorm = incWords.map(normalizeArabicWordForTasmie);

  // Case 1: Chrome Android often sends a cumulative hypothesis starting from word 0.
  // Detect how much of the start of `incNorm` matches the start of `accNorm`.
  let prefixMatchLen = 0;
  const maxPrefix = Math.min(accNorm.length, incNorm.length);
  while (
    prefixMatchLen < maxPrefix &&
    areQuranWordsEquivalent(incNorm[prefixMatchLen], accNorm[prefixMatchLen])
  ) {
    prefixMatchLen++;
  }

  // If the incoming chunk is completely covered by the start of accumulated text, ignore duplicate!
  if (prefixMatchLen === incNorm.length) {
    return accWords.join(' ');
  }

  // If incoming starts by repeating >= 2 opening words (e.g., first ayah prefix), drop that replay.
  if (prefixMatchLen >= Math.min(3, accNorm.length) && prefixMatchLen >= 2) {
    const remainder = incWords.slice(prefixMatchLen);
    if (remainder.length === 0) return accWords.join(' ');
    return mergeSpeechChunkWithoutRepetition(accWords.join(' '), remainder.join(' '));
  }

  // Case 2: Overlapping suffix of accumulated == prefix of incoming.
  const maxOverlap = Math.min(accNorm.length, incNorm.length);
  let overlapLen = 0;
  for (let len = maxOverlap; len >= 1; len--) {
    let matched = true;
    for (let k = 0; k < len; k++) {
      if (!areQuranWordsEquivalent(incNorm[k], accNorm[accNorm.length - len + k])) {
        matched = false;
        break;
      }
    }
    if (matched) {
      overlapLen = len;
      break;
    }
  }

  const appended = incWords.slice(overlapLen);
  if (appended.length === 0) return accWords.join(' ');
  return [...accWords, ...appended].join(' ');
}

/**
 * Extracts a clean, non-duplicating transcript from SpeechRecognitionResultList.
 */
export function extractCleanRecognitionTranscript(
  results: ArrayLike<{ isFinal?: boolean; 0?: { transcript?: string } }>
): { finalText: string; interimText: string } {
  let finalText = '';
  let interimText = '';

  for (let i = 0; i < results.length; i++) {
    const item = results[i];
    const chunk = item?.[0]?.transcript?.trim() || '';
    if (!chunk) continue;

    if (item.isFinal) {
      finalText = mergeSpeechChunkWithoutRepetition(finalText, chunk);
    } else {
      interimText = mergeSpeechChunkWithoutRepetition(interimText, chunk);
    }
  }

  return { finalText, interimText };
}

/**
 * Strips optional spoken Istiadhah ("أعوذ بالله من الشيطان الرجيم") or introductory Bismillah
 * when the target expected verses do not begin with Bismillah.
 */
function stripOptionalSpokenIntro(
  spokenRaw: string[],
  spokenNorm: string[],
  expectedNorm: string[]
): { raw: string[]; norm: string[] } {
  let idx = 0;

  const isMatchAt = (pos: number, seq: string[]) =>
    pos + seq.length <= spokenNorm.length &&
    seq.every((w, offset) => areQuranWordsEquivalent(spokenNorm[pos + offset], w));

  const istiadhah = ['اعوذ', 'بالله', 'من', 'الشيطان', 'الرجيم'];
  if (isMatchAt(idx, istiadhah) && !expectedNorm.slice(0, 2).includes('اعوذ')) {
    idx += istiadhah.length;
  }

  const bismillah = ['بسم', 'الله', 'الرحمن', 'الرحيم'];
  const expectedStartsWithBismillah =
    expectedNorm.length >= 4 &&
    bismillah.every((w, offset) => areQuranWordsEquivalent(expectedNorm[offset], w));

  if (!expectedStartsWithBismillah && isMatchAt(idx, bismillah)) {
    idx += bismillah.length;
  }

  return {
    raw: spokenRaw.slice(idx),
    norm: spokenNorm.slice(idx),
  };
}

/**
 * Aligns spoken words against expected Quranic words using Needleman-Wunsch dynamic
 * programming so skipping or repeating a single word does not cascade into false errors
 * across all subsequent words.
 */
export function evaluateRecitationAligned(
  expectedEntries: ExpectedWordEntry[],
  spokenText: string
): RecitationEvaluation {
  const totalCount = expectedEntries.length;
  if (totalCount === 0) {
    return { accuracy: 0, matchedCount: 0, totalCount: 0, alignedWords: [], mistakes: [] };
  }

  const rawTokens = spokenText.trim().split(/\s+/).filter(Boolean);
  const normTokens = rawTokens.map(normalizeArabicWordForTasmie);

  // Filter empty normalized tokens synchronously
  const pairedRaw: string[] = [];
  const pairedNorm: string[] = [];
  rawTokens.forEach((tok, i) => {
    if (normTokens[i]) {
      pairedRaw.push(tok);
      pairedNorm.push(normTokens[i]);
    }
  });

  const expectedNorm = expectedEntries.map((e) => normalizeArabicWordForTasmie(e.word));
  const { raw: spokenRaw, norm: spokenNorm } = stripOptionalSpokenIntro(
    pairedRaw,
    pairedNorm,
    expectedNorm
  );

  const m = expectedEntries.length;
  const n = spokenNorm.length;

  // Dynamic programming score matrix: maximize matches while softly preferring local substitutions
  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  const choice: Uint8Array[] = Array.from({ length: m + 1 }, () => new Uint8Array(n + 1));
  // choice codes: 1 = diag (match/sub), 2 = up (expected missed), 3 = left (extra spoken)

  for (let i = 1; i <= m; i++) {
    dp[i][0] = i * -2;
    choice[i][0] = 2;
  }
  for (let j = 1; j <= n; j++) {
    dp[0][j] = j * -1;
    choice[0][j] = 3;
  }

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const isMatch = areQuranWordsEquivalent(spokenNorm[j - 1], expectedNorm[i - 1]);
      const diagScore = dp[i - 1][j - 1] + (isMatch ? 4 : -1);
      const upScore = dp[i - 1][j] - 2; // expected word skipped
      const leftScore = dp[i][j - 1] - 1; // extra spoken word

      if (diagScore >= upScore && diagScore >= leftScore) {
        dp[i][j] = diagScore;
        choice[i][j] = 1;
      } else if (upScore >= leftScore) {
        dp[i][j] = upScore;
        choice[i][j] = 2;
      } else {
        dp[i][j] = leftScore;
        choice[i][j] = 3;
      }
    }
  }

  // Backtrack alignment for expected indices 0..m-1
  const alignedWords: AlignedWordResult[] = new Array(m);
  let i = m;
  let j = n;
  while (i > 0 || j > 0) {
    const dir = choice[i][j];
    if (i > 0 && j > 0 && dir === 1) {
      const entry = expectedEntries[i - 1];
      const isMatch = areQuranWordsEquivalent(spokenNorm[j - 1], expectedNorm[i - 1]);
      alignedWords[i - 1] = {
        ayahNumber: entry.ayahNumber,
        wordIndex: i,
        expectedWord: entry.word,
        spokenWord: spokenRaw[j - 1],
        status: isMatch ? 'matched' : 'mismatch',
      };
      i--;
      j--;
    } else if (i > 0 && (j === 0 || dir === 2)) {
      const entry = expectedEntries[i - 1];
      alignedWords[i - 1] = {
        ayahNumber: entry.ayahNumber,
        wordIndex: i,
        expectedWord: entry.word,
        spokenWord: '—',
        status: 'missed',
      };
      i--;
    } else {
      j--;
    }
  }

  let matchedCount = 0;
  const mistakes: RecitationEvaluation['mistakes'] = [];

  alignedWords.forEach((item) => {
    if (item.status === 'matched') {
      matchedCount++;
    } else {
      mistakes.push({
        ayahNumber: item.ayahNumber,
        wordIndex: item.wordIndex,
        expectedWord: item.expectedWord,
        spokenWord: item.spokenWord,
        correction: item.expectedWord,
      });
    }
  });

  const accuracy = Math.round((matchedCount / totalCount) * 100);

  return {
    accuracy,
    matchedCount,
    totalCount,
    alignedWords,
    mistakes,
  };
}

export interface LiveSpokenWordEval {
  spokenWord: string;
  isCorrect: boolean;
  expectedWord?: string;
}

export interface LiveSpokenEvaluation {
  words: LiveSpokenWordEval[];
  matchedExpectedUpTo: number;
  reachedEnd: boolean;
  mistakeCount: number;
}

/**
 * Evaluates ONLY what the user has actually spoken so far against the prefix of expected words.
 * Never pre-fills expected words; preserves each spoken word verbatim and flags errors in red.
 */
export function evaluateSpokenWordsLive(
  expectedEntries: ExpectedWordEntry[],
  spokenText: string
): LiveSpokenEvaluation {
  const rawTokens = spokenText.trim().split(/\s+/).filter(Boolean);
  if (rawTokens.length === 0) {
    return { words: [], matchedExpectedUpTo: 0, reachedEnd: false, mistakeCount: 0 };
  }

  const pairedRaw: string[] = [];
  const pairedNorm: string[] = [];
  rawTokens.forEach((tok) => {
    const norm = normalizeArabicWordForTasmie(tok);
    if (norm) {
      pairedRaw.push(tok);
      pairedNorm.push(norm);
    }
  });

  if (pairedRaw.length === 0 || expectedEntries.length === 0) {
    return {
      words: rawTokens.map((w) => ({ spokenWord: w, isCorrect: expectedEntries.length > 0 })),
      matchedExpectedUpTo: 0,
      reachedEnd: false,
      mistakeCount: 0,
    };
  }

  const expectedNorm = expectedEntries.map((e) => normalizeArabicWordForTasmie(e.word));
  const { raw: spokenRaw, norm: spokenNorm } = stripOptionalSpokenIntro(
    pairedRaw,
    pairedNorm,
    expectedNorm
  );
  const introCount = pairedRaw.length - spokenRaw.length;
  const introEval: LiveSpokenWordEval[] = pairedRaw.slice(0, introCount).map((w) => ({
    spokenWord: w,
    isCorrect: true,
  }));

  const n = spokenNorm.length;
  if (n === 0) {
    return {
      words: introEval,
      matchedExpectedUpTo: 0,
      reachedEnd: false,
      mistakeCount: 0,
    };
  }

  const mEff = Math.min(expectedNorm.length, n + 40);
  const dp: number[][] = Array.from({ length: mEff + 1 }, () => new Array(n + 1).fill(0));
  const choice: Uint8Array[] = Array.from({ length: mEff + 1 }, () => new Uint8Array(n + 1));

  for (let i = 1; i <= mEff; i++) {
    dp[i][0] = i * -2;
    choice[i][0] = 2;
  }
  for (let j = 1; j <= n; j++) {
    dp[0][j] = j * -2;
    choice[0][j] = 3;
  }

  for (let i = 1; i <= mEff; i++) {
    for (let j = 1; j <= n; j++) {
      const isMatch = areQuranWordsEquivalent(spokenNorm[j - 1], expectedNorm[i - 1]);
      const diagScore = dp[i - 1][j - 1] + (isMatch ? 4 : -2);
      const upScore = dp[i - 1][j] - 2;
      const leftScore = dp[i][j - 1] - 2;

      if (diagScore >= upScore && diagScore >= leftScore) {
        dp[i][j] = diagScore;
        choice[i][j] = 1;
      } else if (upScore >= leftScore) {
        dp[i][j] = upScore;
        choice[i][j] = 2;
      } else {
        dp[i][j] = leftScore;
        choice[i][j] = 3;
      }
    }
  }

  // Pick the shortest expected prefix achieving maximum alignment score for the N spoken words
  let bestI = 0;
  let bestScore = dp[0][n];
  for (let i = 1; i <= mEff; i++) {
    if (dp[i][n] > bestScore) {
      bestScore = dp[i][n];
      bestI = i;
    }
  }

  const bodyEval: LiveSpokenWordEval[] = new Array(n);
  let i = bestI;
  let j = n;
  while (j > 0) {
    const dir = choice[i][j];
    if (i > 0 && dir === 1) {
      const isMatch = areQuranWordsEquivalent(spokenNorm[j - 1], expectedNorm[i - 1]);
      bodyEval[j - 1] = {
        spokenWord: spokenRaw[j - 1],
        isCorrect: isMatch,
        expectedWord: expectedEntries[i - 1]?.word,
      };
      i--;
      j--;
    } else if (i > 0 && dir === 2) {
      i--;
    } else {
      bodyEval[j - 1] = {
        spokenWord: spokenRaw[j - 1],
        isCorrect: false,
      };
      j--;
    }
  }

  const words = [...introEval, ...bodyEval];
  const mistakeCount = words.filter((w) => !w.isCorrect).length;
  const reachedEnd =
    expectedEntries.length > 0 &&
    mEff === expectedEntries.length &&
    bestI >= expectedEntries.length &&
    spokenRaw.length >= Math.max(1, expectedEntries.length - 1);

  return {
    words,
    matchedExpectedUpTo: bestI,
    reachedEnd,
    mistakeCount,
  };
}
