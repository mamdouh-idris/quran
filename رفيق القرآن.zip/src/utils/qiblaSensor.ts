export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export type MagneticFieldQuality = 'optimal' | 'moderate' | 'interference' | 'unavailable';

export interface MagneticFieldStatus {
  magnitudeUt: number | null;
  quality: MagneticFieldQuality;
}

export interface TiltLevelStatus {
  tiltDeg: number;
  isLevel: boolean;
  bubbleX: number; // Normalized [-1, 1]
  bubbleY: number; // Normalized [-1, 1]
}

export function normalizeAngle360(deg: number): number {
  return ((deg % 360) + 360) % 360;
}

export function shortestAngleDiff(target: number, current: number): number {
  let diff = ((target - current + 540) % 360) - 180;
  if (diff < -180) diff += 360;
  return diff;
}

/**
 * Circular exponential moving average filter that avoids 0°/360° wraparound jumps.
 */
export function circularLowPassFilter(prevDeg: number, nextDeg: number, alpha: number): number {
  const diff = shortestAngleDiff(nextDeg, prevDeg);
  return normalizeAngle360(prevDeg + diff * alpha);
}

/**
 * Keeps the visual CSS dial rotation continuous across the 0°/360° boundary
 * so rotating from 359° to 1° animates +2° instead of spinning -358° backward.
 */
export function advanceUnwrappedRotation(prevUnwrapped: number, targetDeg: number): number {
  const diff = shortestAngleDiff(targetDeg, prevUnwrapped);
  return prevUnwrapped + diff;
}

/**
 * Estimates Earth's local magnetic declination (in degrees East of True North)
 * using degree-2 spherical harmonic geomagnetic coefficients (WMM 2025 baseline).
 */
export function estimateMagneticDeclination(latDeg: number, lngDeg: number): number {
  const rad = Math.PI / 180;
  const clampedLat = Math.max(-89.5, Math.min(89.5, latDeg));
  const theta = (90 - clampedLat) * rad;
  const phi = lngDeg * rad;
  const sT = Math.sin(theta);
  const cT = Math.cos(theta);

  // WMM2025 Schmidt quasi-normalized Gauss coefficients (n=1,2) in nT
  const g10 = -29350;
  const g11 = -1410;
  const h11 = 4545;
  const g20 = -2556;
  const g21 = 2951;
  const h21 = -3136;
  const g22 = 1649;
  const h22 = -815;

  const s3 = Math.sqrt(3);
  const P10 = cT;
  const dP10 = -sT;
  const P11 = sT;
  const dP11 = cT;
  const dP20 = -3 * cT * sT;
  const P21 = s3 * sT * cT;
  const dP21 = s3 * (cT * cT - sT * sT);
  const P22 = 0.5 * s3 * sT * sT;
  const dP22 = s3 * sT * cT;

  void P10;

  const c1 = Math.cos(phi);
  const s1 = Math.sin(phi);
  const c2 = Math.cos(2 * phi);
  const s2 = Math.sin(2 * phi);

  const northX =
    g10 * dP10 +
    (g11 * c1 + h11 * s1) * dP11 +
    g20 * dP20 +
    (g21 * c1 + h21 * s1) * dP21 +
    (g22 * c2 + h22 * s2) * dP22;

  const safeSinT = Math.abs(sT) < 1e-6 ? 1e-6 : sT;
  const eastY =
    ((g11 * s1 - h11 * c1) * P11 +
      (g21 * s1 - h21 * c1) * P21 +
      2 * (g22 * s2 - h22 * c2) * P22) /
    safeSinT;

  return Number(((Math.atan2(eastY, northX) * 180) / Math.PI).toFixed(1));
}

/**
 * Converts a device orientation quaternion [x, y, z, w] (ENU Earth frame)
 * into a clockwise compass azimuth heading (0° = North, 90° = East).
 */
export function quaternionToCompassHeading(q: readonly [number, number, number, number]): number {
  const [x, y, z, w] = q;
  // Device +Y axis (screen top) projected onto Earth ENU: (East, North, Up)
  const east = 2 * (x * y - w * z);
  const north = 1 - 2 * (x * x + z * z);

  // If device is held nearly vertical (top pointing nearly straight up), blend/switch to back-of-phone (-Z)
  const horizLen = Math.hypot(east, north);
  if (horizLen < 0.25) {
    const camEast = -2 * (x * z + w * y);
    const camNorth = -2 * (y * z - w * x);
    if (Math.hypot(camEast, camNorth) > 0.1) {
      return normalizeAngle360((Math.atan2(camEast, camNorth) * 180) / Math.PI);
    }
  }

  return normalizeAngle360((Math.atan2(east, north) * 180) / Math.PI);
}

/**
 * Computes tilt-compensated magnetic compass azimuth using either 3-axis Accelerometer
 * (cross-product frame E = m × g, N = g × E) or DeviceOrientation Euler beta/gamma angles.
 */
export function computeTiltCompensatedHeading(
  mag: Vec3,
  accel: Vec3 | null,
  betaDeg: number | null,
  gammaDeg: number | null
): number {
  // Primary: true 3D gravity vector cross-product frame (gimbal-lock free)
  if (accel) {
    const gNorm = Math.hypot(accel.x, accel.y, accel.z);
    if (gNorm > 1e-3) {
      const gx = accel.x / gNorm;
      const gy = accel.y / gNorm;
      const gz = accel.z / gNorm;

      // E = m × g points toward Magnetic East
      const ex = mag.y * gz - mag.z * gy;
      const ey = mag.z * gx - mag.x * gz;
      const ez = mag.x * gy - mag.y * gx;
      const eNorm = Math.hypot(ex, ey, ez);

      if (eNorm > 1e-3) {
        const Ex = ex / eNorm;
        const Ey = ey / eNorm;
        const Ez = ez / eNorm;

        // N = g × E points toward Magnetic North
        const Ny = gz * Ex - gx * Ez;
        // Ey is the East component along device +Y axis (screen top)
        void Ey;
        return normalizeAngle360((Math.atan2(Ey, Ny) * 180) / Math.PI);
      }
    }
  }

  // Secondary: Euler tilt compensation using beta (pitch) & gamma (roll)
  if (typeof betaDeg === 'number' && typeof gammaDeg === 'number') {
    const rad = Math.PI / 180;
    const pitch = betaDeg * rad;
    const roll = gammaDeg * rad;

    const cP = Math.cos(pitch);
    const sP = Math.sin(pitch);
    const cR = Math.cos(roll);
    const sR = Math.sin(roll);

    // Project magnetic vector onto horizontal plane
    const xH = mag.x * cR + mag.z * sR;
    const yH = mag.x * sP * sR + mag.y * cP - mag.z * sP * cR;

    if (Math.hypot(xH, yH) > 1e-3) {
      return normalizeAngle360((Math.atan2(-xH, yH) * 180) / Math.PI);
    }
  }

  // Fallback planar heading
  return normalizeAngle360((Math.atan2(-mag.x, mag.y) * 180) / Math.PI);
}

/**
 * Evaluates local geomagnetic field magnitude (Earth normal range: ~25 to 65 µT).
 * Large deviations warn of nearby speakers, magnets, or metal interference.
 */
export function assessMagneticField(mag: Vec3 | null): MagneticFieldStatus {
  if (!mag) {
    return { magnitudeUt: null, quality: 'unavailable' };
  }
  const magnitudeUt = Number(Math.hypot(mag.x, mag.y, mag.z).toFixed(1));
  if (magnitudeUt < 18 || magnitudeUt > 75) {
    return { magnitudeUt, quality: 'interference' };
  }
  if (magnitudeUt < 25 || magnitudeUt > 65) {
    return { magnitudeUt, quality: 'moderate' };
  }
  return { magnitudeUt, quality: 'optimal' };
}

/**
 * Calculates device tilt angle and spirit-level bubble coordinates in [-1, 1].
 */
export function assessTiltLevel(betaDeg: number | null, gammaDeg: number | null): TiltLevelStatus {
  const beta = typeof betaDeg === 'number' && !Number.isNaN(betaDeg) ? betaDeg : 0;
  const gamma = typeof gammaDeg === 'number' && !Number.isNaN(gammaDeg) ? gammaDeg : 0;
  const tiltDeg = Math.round(Math.min(90, Math.hypot(beta, gamma)));
  const clamp = (v: number) => Math.max(-1, Math.min(1, v));

  return {
    tiltDeg,
    isLevel: tiltDeg <= 20,
    bubbleX: clamp(gamma / 45),
    bubbleY: clamp(beta / 45),
  };
}

export function getScreenOrientationOffset(): number {
  if (typeof window === 'undefined') return 0;
  if (window.screen?.orientation && typeof window.screen.orientation.angle === 'number') {
    return window.screen.orientation.angle;
  }
  const legacyOrientation = (window as unknown as { orientation?: number }).orientation;
  return typeof legacyOrientation === 'number' ? legacyOrientation : 0;
}

let sharedAudioCtx: AudioContext | null = null;

function getOrCreateAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (typeof AudioCtx !== 'function') return null;
  if (!sharedAudioCtx) {
    sharedAudioCtx = new AudioCtx();
  }
  return sharedAudioCtx;
}

/**
 * Unlocks Web Audio API playback on iOS/Android during a user gesture
 * so automatic sensor-triggered Qibla lock alerts play reliably.
 */
export function unlockQiblaAudio(): void {
  try {
    const ctx = getOrCreateAudioContext();
    if (ctx && ctx.state === 'suspended') {
      void ctx.resume();
    }
  } catch {
    // Ignore audio context restrictions
  }
}

/**
 * Plays a gentle two-tone harmonic confirmation chime when Qibla angle locks in.
 */
export function playQiblaAlignChime(): boolean {
  try {
    const ctx = getOrCreateAudioContext();
    if (!ctx) return false;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }

    const now = ctx.currentTime;
    const notes = [
      { freq: 528, start: 0, dur: 0.24, gain: 0.16 },
      { freq: 792, start: 0.11, dur: 0.36, gain: 0.14 },
    ];

    notes.forEach(({ freq, start, dur, gain }) => {
      const osc = ctx.createOscillator();
      const amp = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + start);

      amp.gain.setValueAtTime(0.0001, now + start);
      amp.gain.exponentialRampToValueAtTime(gain, now + start + 0.025);
      amp.gain.exponentialRampToValueAtTime(0.0001, now + start + dur);

      osc.connect(amp);
      amp.connect(ctx.destination);
      osc.start(now + start);
      osc.stop(now + start + dur + 0.02);
    });

    return true;
  } catch {
    return false;
  }
}

/**
 * Triggers a distinct double-pulse haptic vibration pattern on Qibla alignment.
 */
export function triggerQiblaHaptic(): boolean {
  if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
    try {
      return navigator.vibrate([45, 55, 95]);
    } catch {
      return false;
    }
  }
  return false;
}

