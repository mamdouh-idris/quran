import { CalculatedPrayerItem } from './prayerMath';

export type ObligatoryPrayerKey = 'Fajr' | 'Dhuhr' | 'Asr' | 'Maghrib' | 'Isha';

export interface PrayerAdhanPrefs {
  cityId: string;
  gpsCoords: { lat: number; lng: number } | null;
  timeOffsetMinutes: number;
  autoAdhanEnabled: boolean;
  enabledPrayers: Record<ObligatoryPrayerKey, boolean>;
}

export const PRAYER_PREFS_STORAGE_KEY = 'rafiq_quran_prayer_prefs_v1';
export const PRAYER_LAST_FIRED_KEY = 'rafiq_quran_adhan_last_fired_v1';
export const PRAYER_PREFS_UPDATED_EVENT = 'rafiq-prayer-prefs-updated';
export const ADHAN_CONTROL_EVENT = 'rafiq-adhan-control';
export const ADHAN_STATE_EVENT = 'rafiq-adhan-state';

export interface AdhanStateDetail {
  isPlaying: boolean;
  usedBackup: boolean;
  activePrayerName?: string;
  muezzinName?: string;
}

export const DEFAULT_PRAYER_PREFS: PrayerAdhanPrefs = {
  cityId: 'cairo',
  gpsCoords: null,
  timeOffsetMinutes: 0,
  autoAdhanEnabled: true,
  enabledPrayers: {
    Fajr: true,
    Dhuhr: true,
    Asr: true,
    Maghrib: true,
    Isha: true,
  },
};

export function loadPrayerPrefs(): PrayerAdhanPrefs {
  try {
    const raw = localStorage.getItem(PRAYER_PREFS_STORAGE_KEY);
    if (!raw) return DEFAULT_PRAYER_PREFS;
    const parsed = JSON.parse(raw) as Partial<PrayerAdhanPrefs>;
    return {
      cityId: typeof parsed.cityId === 'string' && parsed.cityId ? parsed.cityId : 'cairo',
      gpsCoords:
        parsed.gpsCoords &&
        typeof parsed.gpsCoords.lat === 'number' &&
        typeof parsed.gpsCoords.lng === 'number'
          ? parsed.gpsCoords
          : null,
      timeOffsetMinutes:
        typeof parsed.timeOffsetMinutes === 'number' ? parsed.timeOffsetMinutes : 0,
      autoAdhanEnabled:
        typeof parsed.autoAdhanEnabled === 'boolean' ? parsed.autoAdhanEnabled : true,
      enabledPrayers: {
        Fajr: parsed.enabledPrayers?.Fajr ?? true,
        Dhuhr: parsed.enabledPrayers?.Dhuhr ?? true,
        Asr: parsed.enabledPrayers?.Asr ?? true,
        Maghrib: parsed.enabledPrayers?.Maghrib ?? true,
        Isha: parsed.enabledPrayers?.Isha ?? true,
      },
    };
  } catch {
    return DEFAULT_PRAYER_PREFS;
  }
}

export function savePrayerPrefs(prefs: PrayerAdhanPrefs) {
  try {
    localStorage.setItem(PRAYER_PREFS_STORAGE_KEY, JSON.stringify(prefs));
  } catch {
    // ignore quota errors
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(PRAYER_PREFS_UPDATED_EVENT, { detail: prefs }));
  }
}

export function getLastFiredAdhanMap(): Record<string, string> {
  try {
    const raw = localStorage.getItem(PRAYER_LAST_FIRED_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export function markAdhanFired(dateKey: string, prayerKey: ObligatoryPrayerKey) {
  try {
    const map = getLastFiredAdhanMap();
    map[`${dateKey}_${prayerKey}`] = String(Date.now());
    localStorage.setItem(PRAYER_LAST_FIRED_KEY, JSON.stringify(map));
  } catch {
    // ignore storage errors
  }
}

export function findDuePrayer(
  schedule: CalculatedPrayerItem[],
  cityNow: Date,
  dateKey: string,
  enabledPrayers: Record<ObligatoryPrayerKey, boolean>,
  catchUpWindowSeconds: number = 120
): CalculatedPrayerItem | null {
  const nowSeconds =
    cityNow.getHours() * 3600 + cityNow.getMinutes() * 60 + cityNow.getSeconds();
  const firedMap = getLastFiredAdhanMap();

  for (const item of schedule) {
    if (!item.isObligatory) continue;
    const key = item.key as ObligatoryPrayerKey;
    if (!enabledPrayers[key]) continue;
    if (firedMap[`${dateKey}_${key}`]) continue;

    const targetSeconds = item.minutesFromMidnight * 60;
    const diff = nowSeconds - targetSeconds;
    if (diff >= 0 && diff <= catchUpWindowSeconds) {
      return item;
    }
  }
  return null;
}

export function dispatchAdhanControl(
  action: 'play-test' | 'stop' | 'switch-muezzin',
  muezzinId?: string
) {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(
    new CustomEvent(ADHAN_CONTROL_EVENT, { detail: { action, muezzinId } })
  );
}

export const ADHAN_AUDIO_CACHE_NAME = 'adhan-audio-cache';
export const ADHAN_CACHE_UPDATED_EVENT = 'rafiq-adhan-cache-updated';

async function cacheSingleAdhanUrl(url: string): Promise<boolean> {
  if (!url || typeof window === 'undefined' || !('caches' in window)) return false;
  try {
    const cache = await caches.open(ADHAN_AUDIO_CACHE_NAME);
    const existing = await cache.match(url);
    if (existing) return true;

    try {
      const corsRes = await fetch(url, { mode: 'cors', credentials: 'omit' });
      if (corsRes.ok) {
        await cache.put(url, corsRes.clone());
        return true;
      }
    } catch {
      // Fallback to opaque request for CDNs without CORS headers
    }

    const opaqueRes = await fetch(url, { mode: 'no-cors', credentials: 'omit' });
    if (opaqueRes && (opaqueRes.ok || opaqueRes.type === 'opaque')) {
      await cache.put(url, opaqueRes);
      return true;
    }
  } catch {
    // Ignore offline/network failures while caching
  }
  return false;
}

export async function cacheMuezzinAudio(muezzin: {
  id: string;
  audioUrl: string;
  backupUrl?: string;
}): Promise<boolean> {
  const primarySaved = await cacheSingleAdhanUrl(muezzin.audioUrl);
  let backupSaved = false;
  if (muezzin.backupUrl) {
    backupSaved = await cacheSingleAdhanUrl(muezzin.backupUrl);
  }
  const anySaved = primarySaved || backupSaved;
  if (anySaved && typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent(ADHAN_CACHE_UPDATED_EVENT, { detail: { muezzinId: muezzin.id } })
    );
  }
  return anySaved;
}

export async function isMuezzinAudioCached(muezzin: {
  audioUrl: string;
  backupUrl?: string;
}): Promise<boolean> {
  if (typeof window === 'undefined' || !('caches' in window)) return false;
  try {
    const cache = await caches.open(ADHAN_AUDIO_CACHE_NAME);
    if (await cache.match(muezzin.audioUrl)) return true;
    if (muezzin.backupUrl && (await cache.match(muezzin.backupUrl))) return true;
  } catch {
    return false;
  }
  return false;
}

export async function resolvePlayableAdhanUrl(
  url: string
): Promise<{ src: string; isObjectUrl: boolean }> {
  if (!url || typeof window === 'undefined' || !('caches' in window)) {
    return { src: url, isObjectUrl: false };
  }
  try {
    const cache = await caches.open(ADHAN_AUDIO_CACHE_NAME);
    const cached = await cache.match(url);
    if (cached && cached.type !== 'opaque') {
      const blob = await cached.blob();
      if (blob.size > 0) {
        return { src: URL.createObjectURL(blob), isObjectUrl: true };
      }
    }
  } catch {
    // Fallback cleanly to URL
  }
  return { src: url, isObjectUrl: false };
}
