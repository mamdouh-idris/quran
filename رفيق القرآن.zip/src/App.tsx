/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { sampleSurahs, recitersList, radioStationsList, adhkarList } from './data/quranData';
import { AppSettings } from './types';
import { Navbar } from './components/Navbar';
import { MobileFrame } from './components/MobileFrame';
import { getThemeStyles } from './utils/theme';
import { getDirection, getTranslations } from './utils/i18n';

const SETTINGS_STORAGE_KEY = 'rafiq_quran_settings_v1';

const DEFAULT_SETTINGS: AppSettings = {
  fontSize: 24,
  fontFamily: 'Amiri',
  theme: 'dark',
  accentColor: 'emerald',
  language: 'ar',
  readingMode: false,
  navigationMode: 'swipe',
  pageFlipAnimation: true,
  reciterId: 'mishary',
  muezzinId: 'makkah',
  tafsirType: 'jalalayn',
  wifiOnlyDownload: true,
  shortAdhan: false,
  flipMuteEnabled: true,
  notificationsEnabled: true,
  smartPauseEnabled: true,
};

function loadInitialSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<AppSettings>) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export default function App() {
  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(() => loadInitialSettings());

  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // ignore storage quota errors
    }
  }, [settings]);

  useEffect(() => {
    const handleQuotaExceeded = () => setMapsQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuotaExceeded);
  }, []);

  const themeStyles = getThemeStyles(settings.theme, settings.accentColor, settings.readingMode);
  const t = getTranslations(settings.language);
  const dir = getDirection(settings.language);

  return (
    <div
      className={`h-[100dvh] overflow-hidden w-full ${themeStyles.appBg} flex flex-col font-cairo transition-colors duration-300`}
      dir={dir}
    >
      {mapsQuotaExceeded && (
        <div
          dir="ltr"
          className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2 text-xs md:text-sm text-center shrink-0 z-50 shadow-sm"
        >
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Top App Bar */}
      <Navbar
        settings={settings}
        setSettings={setSettings}
        themeStyles={themeStyles}
        t={t}
      />

      {/* Main Content View */}
      <main className="flex-1 min-h-0 flex flex-col w-full">
        <MobileFrame
          surahs={sampleSurahs}
          reciters={recitersList}
          radioStations={radioStationsList}
          adhkar={adhkarList}
          settings={settings}
          setSettings={setSettings}
          themeStyles={themeStyles}
          t={t}
        />
      </main>
    </div>
  );
}
