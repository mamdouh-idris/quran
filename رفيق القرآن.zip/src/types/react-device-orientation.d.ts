declare module 'react-device-orientation' {
  import React from 'react';

  export interface DeviceOrientationState {
    absolute: boolean;
    alpha: number | null;
    beta: number | null;
    gamma: number | null;
  }

  export interface DeviceOrientationProps {
    children: (orientation: DeviceOrientationState) => React.ReactNode;
  }

  export default class DeviceOrientation extends React.Component<DeviceOrientationProps> {}
}
