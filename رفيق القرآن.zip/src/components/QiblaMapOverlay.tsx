import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  APIProvider,
  APILoadingStatus,
  AdvancedMarker,
  ColorScheme,
  InfoWindow,
  Map as GoogleMap,
  useAdvancedMarkerRef,
  useApiLoadingStatus,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  CheckCircle2,
  Crosshair,
  Globe,
  Layers,
  Maximize2,
  Minimize2,
  RotateCw,
} from 'lucide-react';
import { AppLanguage } from '../types';
import { Translations } from '../utils/i18n';
import { KAABA_LAT, KAABA_LNG } from '../utils/prayerMath';
import { ThemeStyles } from '../utils/theme';

interface QiblaMapOverlayProps {
  lat: number;
  lng: number;
  locationLabel: string;
  effectiveHeading: number;
  qiblaBearing: number;
  distanceKm: number;
  isFacingQibla: boolean;
  isLocating: boolean;
  onRequestGps: () => void;
  language?: AppLanguage;
  themeStyles: ThemeStyles;
  t: Translations;
}

type MapViewMode = 'route' | 'focus';
type MapLayerMode = 'roadmap' | 'hybrid';

const GOOGLE_MAPS_API_KEY =
  import.meta.env.VITE_GOOGLE_MAPS_API_KEY ||
  (typeof __GOOGLE_MAPS_API_KEY__ !== 'undefined' ? __GOOGLE_MAPS_API_KEY__ : '');

function destinationPoint(latDeg: number, lngDeg: number, bearingDeg: number, distKm: number) {
  const earthRadiusKm = 6371;
  const angularDist = distKm / earthRadiusKm;
  const brng = (bearingDeg * Math.PI) / 180;
  const lat1 = (latDeg * Math.PI) / 180;
  const lng1 = (lngDeg * Math.PI) / 180;

  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(angularDist) +
      Math.cos(lat1) * Math.sin(angularDist) * Math.cos(brng)
  );
  const lng2 =
    lng1 +
    Math.atan2(
      Math.sin(brng) * Math.sin(angularDist) * Math.cos(lat1),
      Math.cos(angularDist) - Math.sin(lat1) * Math.sin(lat2)
    );

  return {
    lat: (lat2 * 180) / Math.PI,
    lng: (((lng2 * 180) / Math.PI + 540) % 360) - 180,
  };
}

interface SightLinesControllerProps {
  lat: number;
  lng: number;
  effectiveHeading: number;
  distanceKm: number;
  isFacingQibla: boolean;
  viewMode: MapViewMode;
  recenterSignal: number;
}

const QiblaSightLinesController: React.FC<SightLinesControllerProps> = ({
  lat,
  lng,
  effectiveHeading,
  distanceKm,
  isFacingQibla,
  viewMode,
  recenterSignal,
}) => {
  const map = useMap();
  const coreLib = useMapsLibrary('core');
  const mapsLib = useMapsLibrary('maps');

  // Fit bounds to User <-> Kaaba in 'route' mode, or focus tightly on User in 'focus' mode
  useEffect(() => {
    if (!map) return;

    if (viewMode === 'route') {
      if (!coreLib) return;
      const bounds = new coreLib.LatLngBounds();
      bounds.extend({ lat, lng });
      bounds.extend({ lat: KAABA_LAT, lng: KAABA_LNG });
      map.fitBounds(bounds, { top: 44, right: 36, bottom: 54, left: 36 });
    } else {
      map.panTo({ lat, lng });
      map.setZoom(15);
    }
  }, [map, coreLib, lat, lng, viewMode, recenterSignal]);

  // Draw Geodesic Qibla Line of Sight + Live Phone Heading Ray
  useEffect(() => {
    if (!map || !mapsLib) return;

    const rayDistanceKm =
      viewMode === 'focus' ? 1.6 : Math.max(180, Math.min(2200, distanceKm * 0.48));
    const headingEndpoint = destinationPoint(lat, lng, effectiveHeading, rayDistanceKm);

    const qiblaLine = new mapsLib.Polyline({
      path: [
        { lat, lng },
        { lat: KAABA_LAT, lng: KAABA_LNG },
      ],
      geodesic: true,
      strokeColor: isFacingQibla ? '#10b981' : '#16a34a',
      strokeOpacity: 0.92,
      strokeWeight: isFacingQibla ? 4.5 : 3.5,
      zIndex: 10,
      map,
    });

    const headingLine = new mapsLib.Polyline({
      path: [{ lat, lng }, headingEndpoint],
      geodesic: true,
      strokeOpacity: 0,
      zIndex: 12,
      icons: [
        {
          icon: {
            path: 'M 0,-1 0,1',
            strokeOpacity: 0.95,
            strokeColor: isFacingQibla ? '#34d399' : '#f59e0b',
            strokeWeight: 3,
            scale: 2.5,
          },
          offset: '0',
          repeat: '12px',
        },
      ],
      map,
    });

    return () => {
      qiblaLine.setMap(null);
      headingLine.setMap(null);
    };
  }, [map, mapsLib, lat, lng, effectiveHeading, distanceKm, isFacingQibla, viewMode]);

  return null;
};

interface InnerGoogleMapProps {
  lat: number;
  lng: number;
  locationLabel: string;
  effectiveHeading: number;
  qiblaBearing: number;
  distanceKm: number;
  isFacingQibla: boolean;
  viewMode: MapViewMode;
  mapType: MapLayerMode;
  recenterSignal: number;
  themeStyles: ThemeStyles;
  onFallback: () => void;
}

const InnerGoogleMap: React.FC<InnerGoogleMapProps> = ({
  lat,
  lng,
  locationLabel,
  effectiveHeading,
  qiblaBearing,
  distanceKm,
  isFacingQibla,
  viewMode,
  mapType,
  recenterSignal,
  themeStyles,
  onFallback,
}) => {
  const apiStatus = useApiLoadingStatus();
  const [userMarkerRef, userMarker] = useAdvancedMarkerRef();
  const [kaabaMarkerRef, kaabaMarker] = useAdvancedMarkerRef();
  const [openInfo, setOpenInfo] = useState<'user' | 'kaaba' | null>(null);

  useEffect(() => {
    if (
      apiStatus === APILoadingStatus.FAILED ||
      apiStatus === APILoadingStatus.AUTH_FAILURE
    ) {
      onFallback();
    }
  }, [apiStatus, onFallback]);

  const handleCloseInfo = useCallback(() => setOpenInfo(null), []);

  return (
    <GoogleMap
      mapId="DEMO_MAP_ID"
      internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
      colorScheme={themeStyles.isLight ? ColorScheme.LIGHT : ColorScheme.DARK}
      mapTypeId={mapType}
      defaultCenter={{ lat, lng }}
      defaultZoom={5}
      gestureHandling="greedy"
      disableDefaultUI
      className="w-full h-full"
    >
      <QiblaSightLinesController
        lat={lat}
        lng={lng}
        effectiveHeading={effectiveHeading}
        distanceKm={distanceKm}
        isFacingQibla={isFacingQibla}
        viewMode={viewMode}
        recenterSignal={recenterSignal}
      />

      {/* User Location Advanced Marker + Live Heading Cone */}
      <AdvancedMarker
        ref={userMarkerRef}
        position={{ lat, lng }}
        title={locationLabel}
        onClick={() => setOpenInfo((prev) => (prev === 'user' ? null : 'user'))}
        zIndex={20}
      >
        <div className="relative flex items-center justify-center w-12 h-12 pointer-events-auto cursor-pointer">
          {/* Live Heading Cone */}
          <div
            className="absolute inset-0 flex items-start justify-center transition-transform duration-75"
            style={{ transform: `rotate(${effectiveHeading}deg)` }}
          >
            <div
              className={`w-0 h-0 border-l-[11px] border-r-[11px] border-t-[24px] border-l-transparent border-r-transparent -mt-1 ${
                isFacingQibla ? 'border-t-emerald-400/75' : 'border-t-amber-400/70'
              }`}
            />
          </div>
          {/* Pulsing User Dot */}
          <span
            className={`absolute w-6 h-6 rounded-full animate-ping opacity-35 ${
              isFacingQibla ? 'bg-emerald-400' : 'bg-sky-400'
            }`}
          />
          <span
            className={`relative w-4 h-4 rounded-full border-2 border-white shadow-md ${
              isFacingQibla ? 'bg-emerald-500' : 'bg-sky-600'
            }`}
          />
        </div>
      </AdvancedMarker>

      {/* Sacred Kaaba Advanced Marker */}
      <AdvancedMarker
        ref={kaabaMarkerRef}
        position={{ lat: KAABA_LAT, lng: KAABA_LNG }}
        title="الكعبة المشرفة"
        onClick={() => setOpenInfo((prev) => (prev === 'kaaba' ? null : 'kaaba'))}
        zIndex={25}
      >
        <div className="relative flex items-center justify-center cursor-pointer">
          {isFacingQibla && (
            <span className="absolute -inset-2 rounded-lg bg-emerald-400/40 animate-pulse" />
          )}
          <div className="relative w-7 h-7 rounded-md bg-zinc-900 border-2 border-amber-400 shadow-lg flex flex-col justify-start overflow-hidden">
            <div className="w-full h-1.5 bg-amber-400 mt-1.5" />
          </div>
        </div>
      </AdvancedMarker>

      {openInfo === 'user' && userMarker && (
        <InfoWindow anchor={userMarker} onCloseClick={handleCloseInfo} maxWidth={200}>
          <div className="text-xs text-slate-800 space-y-0.5 p-0.5">
            <div className="font-bold">{locationLabel}</div>
            <div dir="ltr" className="text-[11px] text-slate-600 tabular-nums">
              {lat.toFixed(4)}°, {lng.toFixed(4)}°
            </div>
          </div>
        </InfoWindow>
      )}

      {openInfo === 'kaaba' && kaabaMarker && (
        <InfoWindow anchor={kaabaMarker} onCloseClick={handleCloseInfo} maxWidth={220}>
          <div className="text-xs text-slate-800 space-y-0.5 p-0.5">
            <div className="font-bold text-emerald-700">الكعبة المشرفة — مكة المكرمة</div>
            <div dir="ltr" className="text-[11px] text-slate-600 tabular-nums">
              {qiblaBearing}° · {distanceKm.toFixed(1)} km
            </div>
          </div>
        </InfoWindow>
      )}
    </GoogleMap>
  );
};

export const QiblaMapOverlay: React.FC<QiblaMapOverlayProps> = ({
  lat,
  lng,
  locationLabel,
  effectiveHeading,
  qiblaBearing,
  distanceKm,
  isFacingQibla,
  isLocating,
  onRequestGps,
  language = 'ar',
  themeStyles,
  t,
}) => {
  const [isMapExpanded, setIsMapExpanded] = useState(false);
  const [viewMode, setViewMode] = useState<MapViewMode>('route');
  const [mapType, setMapType] = useState<MapLayerMode>('roadmap');
  const [recenterSignal, setRecenterSignal] = useState(0);
  const [useFallbackSvg, setUseFallbackSvg] = useState(!GOOGLE_MAPS_API_KEY);

  useEffect(() => {
    const onQuota = () => setUseFallbackSvg(true);
    window.addEventListener('gmp-quota-exceeded', onQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuota);
  }, []);

  const handleFallback = useCallback(() => {
    setUseFallbackSvg(true);
  }, []);

  const handleRecenter = () => {
    onRequestGps();
    setRecenterSignal((n) => n + 1);
  };

  // Fallback SVG geographic projection when Maps key is absent or unavailable
  const fallbackProjection = useMemo(() => {
    const minLat = Math.min(lat, KAABA_LAT) - 4;
    const maxLat = Math.max(lat, KAABA_LAT) + 4;
    const minLng = Math.min(lng, KAABA_LNG) - 5;
    const maxLng = Math.max(lng, KAABA_LNG) + 5;

    const spanLat = Math.max(10, maxLat - minLat);
    const spanLng = Math.max(14, maxLng - minLng);

    const project = (pLat: number, pLng: number) => {
      const x = ((pLng - minLng) / spanLng) * 320;
      const y = (1 - (pLat - minLat) / spanLat) * 150;
      return { x, y };
    };

    const userPt = project(lat, lng);
    const kaabaPt = project(KAABA_LAT, KAABA_LNG);
    const headingTarget = destinationPoint(lat, lng, effectiveHeading, Math.max(250, distanceKm * 0.45));
    const headingPt = project(headingTarget.lat, headingTarget.lng);

    const redSeaCoords: Array<[number, number]> = [
      [29.9, 32.55],
      [27.8, 34.3],
      [24.0, 35.5],
      [20.0, 37.3],
      [15.5, 40.2],
      [12.7, 43.3],
      [14.5, 43.1],
      [19.5, 40.9],
      [21.5, 39.1],
      [25.5, 36.8],
      [28.5, 34.8],
      [29.6, 34.95],
      [27.8, 34.3],
    ];
    const medCoastCoords: Array<[number, number]> = [
      [31.5, 25.0],
      [31.2, 29.9],
      [31.5, 31.8],
      [31.1, 33.8],
      [32.1, 34.7],
      [33.8, 35.4],
      [36.5, 36.0],
      [36.8, 28.0],
    ];
    const persianGulfCoords: Array<[number, number]> = [
      [30.0, 48.0],
      [28.0, 49.0],
      [26.0, 50.6],
      [24.4, 54.4],
      [26.2, 56.4],
      [27.0, 56.2],
      [29.5, 50.5],
    ];

    const toSvgPath = (coords: Array<[number, number]>, closed = false) =>
      coords
        .map(([cLat, cLng], idx) => {
          const p = project(cLat, cLng);
          return `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`;
        })
        .join(' ') + (closed ? ' Z' : '');

    return {
      userPt,
      kaabaPt,
      headingPt,
      redSeaPath: toSvgPath(redSeaCoords, true),
      medPath: toSvgPath(medCoastCoords, false),
      gulfPath: toSvgPath(persianGulfCoords, true),
    };
  }, [lat, lng, effectiveHeading, distanceKm]);

  const distanceUnit =
    t.qiblaTitle === 'القبلة' || t.qiblaTitle === 'قبلہ' ? 'كم' : 'km';

  return (
    <div
      className={`relative rounded-2xl overflow-hidden border ${
        isFacingQibla ? 'border-emerald-500 ring-2 ring-emerald-500/35' : themeStyles.border
      } bg-[#dce4db] transition-all duration-300 shadow-sm ${
        isMapExpanded ? 'h-72' : 'h-44'
      }`}
    >
      {!useFallbackSvg && GOOGLE_MAPS_API_KEY ? (
        <div className="w-full h-full">
          <APIProvider
            apiKey={GOOGLE_MAPS_API_KEY}
            language={language}
            libraries={['marker', 'maps', 'core']}
          >
            <InnerGoogleMap
              lat={lat}
              lng={lng}
              locationLabel={locationLabel}
              effectiveHeading={effectiveHeading}
              qiblaBearing={qiblaBearing}
              distanceKm={distanceKm}
              isFacingQibla={isFacingQibla}
              viewMode={viewMode}
              mapType={mapType}
              recenterSignal={recenterSignal}
              themeStyles={themeStyles}
              onFallback={handleFallback}
            />
          </APIProvider>
        </div>
      ) : (
        <svg
          viewBox="0 0 320 150"
          preserveAspectRatio="xMidYMid slice"
          className="w-full h-full block select-none"
        >
          <rect
            x="0"
            y="0"
            width="320"
            height="150"
            fill={themeStyles.isLight ? '#d9dfd3' : '#132024'}
          />
          <ellipse
            cx="95"
            cy="70"
            rx="110"
            ry="60"
            fill={themeStyles.isLight ? '#cfd6c9' : '#1a2b30'}
            opacity="0.65"
          />
          <ellipse
            cx="245"
            cy="90"
            rx="95"
            ry="55"
            fill={themeStyles.isLight ? '#d3dacd' : '#1e3136'}
            opacity="0.65"
          />

          <path
            d={fallbackProjection.medPath}
            fill="none"
            stroke={themeStyles.isLight ? '#5b9aa9' : '#245869'}
            strokeWidth="20"
            opacity="0.65"
          />
          <path
            d={fallbackProjection.redSeaPath}
            fill={themeStyles.isLight ? '#4d909e' : '#1d4f60'}
            opacity="0.88"
          />
          <path
            d={fallbackProjection.gulfPath}
            fill={themeStyles.isLight ? '#4d909e' : '#1d4f60'}
            opacity="0.82"
          />

          {/* Geodesic Line of Sight to Kaaba */}
          <line
            x1={fallbackProjection.userPt.x}
            y1={fallbackProjection.userPt.y}
            x2={fallbackProjection.kaabaPt.x}
            y2={fallbackProjection.kaabaPt.y}
            stroke={isFacingQibla ? '#10b981' : '#15803d'}
            strokeWidth={isFacingQibla ? '3.5' : '2.8'}
            strokeLinecap="round"
          />

          {/* Live Heading Indicator Ray */}
          <line
            x1={fallbackProjection.userPt.x}
            y1={fallbackProjection.userPt.y}
            x2={fallbackProjection.headingPt.x}
            y2={fallbackProjection.headingPt.y}
            stroke={isFacingQibla ? '#34d399' : '#f59e0b'}
            strokeWidth="2.5"
            strokeDasharray="5 4"
            strokeLinecap="round"
          />

          <g
            transform={`translate(${fallbackProjection.userPt.x}, ${fallbackProjection.userPt.y})`}
          >
            <circle r="7" fill="#ffffff" stroke="#0284c7" strokeWidth="2" />
            <circle r="3.5" fill={isFacingQibla ? '#10b981' : '#0284c7'} />
          </g>

          <g
            transform={`translate(${fallbackProjection.kaabaPt.x - 9}, ${fallbackProjection.kaabaPt.y - 9})`}
          >
            <rect
              width="18"
              height="18"
              rx="3"
              fill="#18181b"
              stroke="#eab308"
              strokeWidth="1.5"
            />
            <line x1="2" y1="6" x2="16" y2="6" stroke="#facc15" strokeWidth="2" />
          </g>
        </svg>
      )}

      {/* Top-Left Map Controls (Expand + Layer Toggle) */}
      <div className="absolute top-2 left-2 z-20 flex items-center gap-1.5">
        <button
          onClick={() => setIsMapExpanded((v) => !v)}
          className="w-8 h-8 rounded-full bg-white/95 text-slate-700 flex items-center justify-center shadow border border-slate-300/70 hover:bg-white transition-colors"
          title={isMapExpanded ? 'تصغير الخريطة' : 'توسيع الخريطة'}
          aria-label="توسيع الخريطة"
        >
          {isMapExpanded ? (
            <Minimize2 className="w-3.5 h-3.5" />
          ) : (
            <Maximize2 className="w-3.5 h-3.5" />
          )}
        </button>

        {!useFallbackSvg && GOOGLE_MAPS_API_KEY && (
          <button
            onClick={() => setMapType((m) => (m === 'roadmap' ? 'hybrid' : 'roadmap'))}
            className={`w-8 h-8 rounded-full flex items-center justify-center shadow border transition-colors ${
              mapType === 'hybrid'
                ? 'bg-emerald-600 text-white border-emerald-500'
                : 'bg-white/95 text-slate-700 border-slate-300/70 hover:bg-white'
            }`}
            title={mapType === 'hybrid' ? 'خريطة طرق' : 'قمر صناعي'}
            aria-label="تبديل نمط الخريطة"
          >
            <Layers className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Top-Right Camera & GPS Controls (Route vs User Aim + GPS Refresh) */}
      <div className="absolute top-2 right-2 z-20 flex items-center gap-1.5">
        {!useFallbackSvg && GOOGLE_MAPS_API_KEY && (
          <button
            onClick={() => setViewMode((v) => (v === 'route' ? 'focus' : 'route'))}
            className="h-8 px-2.5 rounded-full bg-white/95 text-slate-800 text-[11px] font-bold flex items-center gap-1 shadow border border-slate-300/70 hover:bg-white transition-colors"
            title={
              viewMode === 'route'
                ? 'تقريب لموقعي واتجاه النظر'
                : 'عرض المسار الكامل نحو الكعبة'
            }
          >
            {viewMode === 'route' ? (
              <>
                <Crosshair className="w-3.5 h-3.5 text-emerald-600" />
                <span>موقعي</span>
              </>
            ) : (
              <>
                <Globe className="w-3.5 h-3.5 text-emerald-600" />
                <span>للكعبة</span>
              </>
            )}
          </button>
        )}

        <button
          onClick={handleRecenter}
          className="w-8 h-8 rounded-full bg-white/95 text-slate-700 flex items-center justify-center shadow border border-slate-300/70 hover:bg-white transition-colors"
          title={t.enableGps}
          aria-label={t.enableGps}
        >
          <RotateCw className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Bottom Sightline Telemetry HUD */}
      <div
        dir="ltr"
        className="pointer-events-none absolute bottom-0 inset-x-0 z-10 bg-gradient-to-t from-black/80 via-black/45 to-transparent px-3 py-2 flex items-center justify-between text-white text-xs font-bold tabular-nums"
      >
        <div className="flex items-center gap-1.5">
          <span className="px-1.5 py-0.5 rounded bg-emerald-600/90 text-[11px]">
            {qiblaBearing}°
          </span>
          {isFacingQibla && (
            <span className="flex items-center gap-1 text-[10px] text-emerald-300">
              <CheckCircle2 className="w-3 h-3" />
            </span>
          )}
        </div>

        <span className="text-[10px] font-medium text-white/95 truncate max-w-[140px]">
          {locationLabel}
        </span>

        <span>
          {distanceKm.toFixed(1)} {distanceUnit}
        </span>
      </div>
    </div>
  );
};
