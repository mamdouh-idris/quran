import React, { useState } from 'react';
import { implementationPlanData } from '../../data/implementationPlan';
import { Layers, Cpu, Database, ShieldCheck, ChevronDown, ChevronUp, Sparkles, CheckCircle2 } from 'lucide-react';
import { ThemeStyles } from '../../utils/theme';

interface PlanTabProps {
  themeStyles: ThemeStyles;
}

export const PlanTab: React.FC<PlanTabProps> = ({ themeStyles }) => {
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    'phase-mvp': true,
    'tech-stack': true,
    'architecture': true,
    'challenges': true,
  });

  const toggleSection = (id: string) => {
    setOpenSections((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layers': return <Layers className={`w-5 h-5 ${themeStyles.accentText}`} />;
      case 'Cpu': return <Cpu className={`w-5 h-5 ${themeStyles.accentText}`} />;
      case 'Database': return <Database className={`w-5 h-5 ${themeStyles.accentText}`} />;
      case 'ShieldCheck': return <ShieldCheck className={`w-5 h-5 ${themeStyles.accentText}`} />;
      default: return <Sparkles className={`w-5 h-5 ${themeStyles.accentText}`} />;
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6 font-cairo w-full">
      {/* Header Banner */}
      <div className={`${themeStyles.accentSoftBg} p-6 rounded-3xl border ${themeStyles.accentBorder} shadow-2xl relative overflow-hidden`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-2xl ${themeStyles.accentBg} flex items-center justify-center shadow-lg border ${themeStyles.accentBorder} shrink-0`}>
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h2 className={`text-2xl font-bold font-amiri ${themeStyles.accentText}`}>
                خطة التنفيذ الهندسية الشاملة لتطبيق "رفيق القرآن"
              </h2>
              <p className={`text-xs ${themeStyles.textSecondary} mt-1`}>
                خطة عمل منظمة ومفصلة لتطوير تطبيق موبايل متكامل (Android / iOS) بمعايير احترافية عالية.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Sections Accordions */}
      <div className="space-y-4">
        {implementationPlanData.map((section) => {
          const isOpen = openSections[section.id];
          return (
            <div
              key={section.id}
              className={`${themeStyles.cardBg} border ${themeStyles.border} rounded-2xl overflow-hidden shadow-xl transition-all`}
            >
              <button
                onClick={() => toggleSection(section.id)}
                className={`w-full px-6 py-4 flex items-center justify-between text-right ${themeStyles.surfaceBg} hover:opacity-90 transition-colors`}
              >
                <div className="flex items-center gap-3">
                  {getIcon(section.icon)}
                  <div>
                    <h3 className={`text-base font-bold ${themeStyles.accentText} font-cairo`}>{section.title}</h3>
                    <p className={`text-xs ${themeStyles.textSecondary} mt-0.5`}>{section.summary}</p>
                  </div>
                </div>
                {isOpen ? (
                  <ChevronUp className={`w-5 h-5 ${themeStyles.accentText}`} />
                ) : (
                  <ChevronDown className={`w-5 h-5 ${themeStyles.textSecondary}`} />
                )}
              </button>

              {isOpen && (
                <div className={`p-6 border-t ${themeStyles.border} space-y-6 ${themeStyles.subSurfaceBg} animate-in fade-in`}>
                  {section.content.map((c, idx) => (
                    <div key={idx} className="space-y-3">
                      <h4 className={`text-sm font-bold ${themeStyles.accentText} font-cairo flex items-center gap-2`}>
                        <span className={`w-2 h-2 rounded-full ${themeStyles.progressBarBg}`}></span>
                        {c.subtitle}
                      </h4>

                      <ul className="space-y-2 pr-4">
                        {c.details.map((detail, dIdx) => (
                          <li key={dIdx} className={`text-xs ${themeStyles.textPrimary} flex items-start gap-2 leading-relaxed`}>
                            <CheckCircle2 className={`w-4 h-4 ${themeStyles.accentText} shrink-0 mt-0.5`} />
                            <span>{detail}</span>
                          </li>
                        ))}
                      </ul>

                      {c.technologies && (
                        <div className="flex flex-wrap gap-1.5 pt-2">
                          {c.technologies.map((tech, tIdx) => (
                            <span
                              key={tIdx}
                              className={`text-[11px] ${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} px-2.5 py-1 rounded-xl font-cairo`}
                            >
                              {tech}
                            </span>
                          ))}
                        </div>
                      )}

                      {c.challenges && (
                        <div className="space-y-3 pt-2">
                          {c.challenges.map((ch, chIdx) => (
                            <div key={chIdx} className="bg-red-950/30 border border-red-900/40 p-4 rounded-xl space-y-2">
                              <span className="text-xs font-bold text-red-400 block">التحدي: {ch.problem}</span>
                              <div className={`text-xs ${themeStyles.accentText} pt-1 border-t border-red-900/30`}>
                                <span className="font-bold ml-1">الحل الهندسي:</span>
                                <span>{ch.solution}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
