import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import Hls from 'hls.js';
import { RadioStation } from '../../types';
import {
  Radio,
  Play,
  Pause,
  RefreshCcw,
  AlertCircle,
  PhoneOff,
  Wifi,
  Search,
} from 'lucide-react';
import { useSmartPause } from '../../context/SmartPauseContext';
import { ThemeStyles } from '../../utils/theme';
import { Translations } from '../../utils/i18n';

interface RadioTabProps {
  radioStations: RadioStation[];
  themeStyles: ThemeStyles;
  t: Translations;
}

const RADIOS_CACHE_KEY = 'rafiq_quran_live_radios_v2';
const HLS_FALLBACK_URL = 'https://win.holol.com/live/quran/playlist.m3u8';
const ICECAST_FALLBACK_URL = 'https://backup.qurango.net/radio/tarateel';

const isHlsUrl = (url: string) => /\.m3u8(\?|$)/i.test(url);

function buildBackupUrls(primaryUrl: string): string[] {
  const backups: string[] = [];
  if (primaryUrl.includes('backup.qurango.net')) {
    backups.push(primaryUrl.replace('backup.qurango.net', 'qurango.net'));
  } else if (primaryUrl.includes('qurango.net')) {
    backups.push(primaryUrl.replace('qurango.net', 'backup.qurango.net'));
  }
  backups.push(HLS_FALLBACK_URL, ICECAST_FALLBACK_URL);
  return Array.from(new Set(backups.filter((u) => u && u !== primaryUrl)));
}

export const RadioTab: React.FC<RadioTabProps> = ({ radioStations, themeStyles, t }) => {
  const [stations, setStations] = useState<RadioStation[]>(radioStations);
  const [currentStation, setCurrentStation] = useState<RadioStation>(radioStations[0]);
  const [frequencyIndex, setFrequencyIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isBuffering, setIsBuffering] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [isRefreshingList, setIsRefreshingList] = useState(false);
  const [streamError, setStreamError] = useState(false);
  const [statusNote, setStatusNote] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [lastUpdatedLabel, setLastUpdatedLabel] = useState<string>('');

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const hlsRef = useRef<Hls | null>(null);
  const watchdogTimerRef = useRef<number | null>(null);

  const isPlayingRef = useRef<boolean>(false);
  isPlayingRef.current = isPlaying;

  const stationRef = useRef<RadioStation>(currentStation);
  stationRef.current = currentStation;

  const freqIndexRef = useRef<number>(frequencyIndex);
  freqIndexRef.current = frequencyIndex;

  const userStoppedRef = useRef<boolean>(true);

  const {
    pausedBySmartPause,
    registerAudioController,
    notifyAudioStarted,
    notifyAudioStopped,
  } = useSmartPause();

  const clearWatchdog = useCallback(() => {
    if (watchdogTimerRef.current !== null) {
      window.clearTimeout(watchdogTimerRef.current);
      watchdogTimerRef.current = null;
    }
  }, []);

  const destroyHls = useCallback(() => {
    if (hlsRef.current) {
      try {
        hlsRef.current.destroy();
      } catch {
        // ignore cleanup errors
      }
      hlsRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      clearWatchdog();
      destroyHls();
    };
  }, [clearWatchdog, destroyHls]);

  const mergeWithCurated = useCallback(
    (apiRadios: Array<{ id: number; name: string; url: string }>): RadioStation[] => {
      const seenUrls = new Set(radioStations.map((s) => s.url));
      const dynamicStations: RadioStation[] = [];

      for (const r of apiRadios) {
        if (!r?.url || !r?.name) continue;
        const cleanUrl = r.url.replace(/^http:\/\//i, 'https://');
        if (seenUrls.has(cleanUrl)) continue;
        seenUrls.add(cleanUrl);
        dynamicStations.push({
          id: `api_${r.id}`,
          name: `إذاعة ${r.name}`,
          url: cleanUrl,
          backupUrls: buildBackupUrls(cleanUrl),
          country: 'بث مباشر متجدد',
          streamType: isHlsUrl(cleanUrl) ? 'HLS' : 'Icecast',
        });
        if (dynamicStations.length >= 25) break;
      }

      return [...radioStations, ...dynamicStations];
    },
    [radioStations]
  );

  // Load cached renewable radio directory & refresh from live API
  const refreshStationsList = useCallback(
    async (silent = false) => {
      if (!silent) setIsRefreshingList(true);
      try {
        const res = await fetch('https://mp3quran.net/api/v3/radios?language=ar');
        if (!res.ok) throw new Error('Failed to fetch radio list');
        const json = await res.json();
        if (Array.isArray(json?.radios) && json.radios.length > 0) {
          const merged = mergeWithCurated(json.radios);
          setStations(merged);
          const timeLabel = new Date().toLocaleTimeString('ar-EG', {
            hour: '2-digit',
            minute: '2-digit',
          });
          setLastUpdatedLabel(`محدّثة (${timeLabel})`);
          try {
            localStorage.setItem(
              RADIOS_CACHE_KEY,
              JSON.stringify({ radios: json.radios.slice(0, 30), timeLabel })
            );
          } catch {
            // ignore storage errors
          }
        }
      } catch {
        // Keep bundled/cached list silently
      } finally {
        if (!silent) setIsRefreshingList(false);
      }
    },
    [mergeWithCurated]
  );

  useEffect(() => {
    try {
      const cachedRaw = localStorage.getItem(RADIOS_CACHE_KEY);
      if (cachedRaw) {
        const parsed = JSON.parse(cachedRaw);
        if (Array.isArray(parsed?.radios)) {
          setStations(mergeWithCurated(parsed.radios));
          if (parsed.timeLabel) setLastUpdatedLabel(`محدّثة (${parsed.timeLabel})`);
        }
      }
    } catch {
      // ignore
    }
    refreshStationsList(true);
  }, [mergeWithCurated, refreshStationsList]);

  const getAllFrequencies = (station: RadioStation): string[] => {
    return Array.from(new Set([station.url, ...(station.backupUrls || [])].filter(Boolean)));
  };

  const playFrequency = useCallback(
    (station: RadioStation, idx: number) => {
      if (!audioRef.current) return;
      const freqs = getAllFrequencies(station);
      if (freqs.length === 0) return;

      const safeIdx = idx % freqs.length;
      const targetUrl = freqs[safeIdx];
      const hlsMode = isHlsUrl(targetUrl);

      clearWatchdog();
      destroyHls();

      setFrequencyIndex(safeIdx);
      setStreamError(false);
      setIsBuffering(true);
      setStatusNote(
        safeIdx === 0
          ? `جاري الاتصال بالبث الأساسي (${hlsMode ? 'HLS' : 'Icecast'})...`
          : `تعذر البث السابق · تبديل تلقائي للرابط البديل (${safeIdx + 1}/${freqs.length})...`
      );

      userStoppedRef.current = false;
      notifyAudioStarted('radio');

      const audioEl = audioRef.current;
      audioEl.pause();

      const fallbackToNext = () => {
        clearWatchdog();
        destroyHls();
        if (userStoppedRef.current) return;
        if (idx + 1 < freqs.length) {
          setIsReconnecting(true);
          setTimeout(() => {
            setIsReconnecting(false);
            playFrequency(station, idx + 1);
          }, 350);
        } else {
          setIsPlaying(false);
          setIsBuffering(false);
          setIsReconnecting(false);
          setStreamError(true);
          setStatusNote('تعذر الاتصال بجميع الروابط البديلة حالياً');
          notifyAudioStopped('radio');
        }
      };

      // 9-second connection watchdog so stalled mounts fail over automatically
      watchdogTimerRef.current = window.setTimeout(() => {
        if (!isPlayingRef.current && !userStoppedRef.current) {
          fallbackToNext();
        }
      }, 9000);

      if (hlsMode && Hls.isSupported()) {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: true,
          manifestLoadingTimeOut: 7000,
          fragLoadingTimeOut: 7000,
        });
        hlsRef.current = hls;
        hls.loadSource(targetUrl);
        hls.attachMedia(audioEl);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          audioEl
            .play()
            .then(() => {
              clearWatchdog();
              setIsPlaying(true);
              setIsBuffering(false);
              setStatusNote(
                safeIdx === 0
                  ? 'بث مباشر مستقر (HLS)'
                  : `رابط بديل نشط (#${safeIdx + 1} · HLS)`
              );
            })
            .catch(fallbackToNext);
        });
        hls.on(Hls.Events.ERROR, (_evt, data) => {
          if (data.fatal) {
            fallbackToNext();
          }
        });
      } else {
        audioEl.src = targetUrl;
        audioEl.load();
        audioEl
          .play()
          .then(() => {
            clearWatchdog();
            setIsPlaying(true);
            setIsBuffering(false);
            setStatusNote(
              safeIdx === 0
                ? `بث مباشر مستقر (${hlsMode ? 'HLS' : 'Icecast'})`
                : `رابط بديل نشط (#${safeIdx + 1} · ${hlsMode ? 'HLS' : 'Icecast'})`
            );
          })
          .catch(fallbackToNext);
      }
    },
    [clearWatchdog, destroyHls, notifyAudioStarted, notifyAudioStopped]
  );

  useEffect(() => {
    return registerAudioController('radio', {
      pause: () => {
        userStoppedRef.current = true;
        clearWatchdog();
        destroyHls();
        audioRef.current?.pause();
        setIsPlaying(false);
        setIsBuffering(false);
      },
      resume: () => {
        if (!audioRef.current) return;
        playFrequency(stationRef.current, freqIndexRef.current);
      },
      isPlaying: () => isPlayingRef.current,
    });
  }, [registerAudioController, playFrequency, clearWatchdog, destroyHls]);

  const togglePlay = (station: RadioStation) => {
    if (currentStation.id === station.id) {
      if (isPlaying || isBuffering) {
        userStoppedRef.current = true;
        clearWatchdog();
        destroyHls();
        audioRef.current?.pause();
        setIsPlaying(false);
        setIsBuffering(false);
        setStatusNote('');
        notifyAudioStopped('radio');
      } else {
        playFrequency(station, 0);
      }
    } else {
      setCurrentStation(station);
      playFrequency(station, 0);
    }
  };

  const handleAudioError = () => {
    if (userStoppedRef.current) return;
    const freqs = getAllFrequencies(stationRef.current);
    const nextIdx = freqIndexRef.current + 1;

    clearWatchdog();
    destroyHls();

    if (nextIdx < freqs.length) {
      setIsReconnecting(true);
      setStatusNote(`انقطع البث الحالي، جاري التبديل التلقائي للرابط البديل (${nextIdx + 1})...`);
      setTimeout(() => {
        setIsReconnecting(false);
        playFrequency(stationRef.current, nextIdx);
      }, 400);
    } else {
      setIsPlaying(false);
      setIsBuffering(false);
      setIsReconnecting(false);
      setStreamError(true);
      notifyAudioStopped('radio');
    }
  };

  const handleRetryStream = () => {
    const freqs = getAllFrequencies(currentStation);
    const nextIdx = (frequencyIndex + 1) % freqs.length;
    setIsReconnecting(true);
    setStreamError(false);
    setTimeout(() => {
      setIsReconnecting(false);
      playFrequency(currentStation, nextIdx);
    }, 350);
  };

  const currentFreqs = getAllFrequencies(currentStation);
  const activeUrl = currentFreqs[frequencyIndex] || currentStation.url;
  const activeProtocol = isHlsUrl(activeUrl) ? 'HLS' : 'Icecast';

  const filteredStations = useMemo(() => {
    const q = searchQuery.trim();
    if (!q) return stations;
    return stations.filter(
      (s) => s.name.includes(q) || s.country.includes(q)
    );
  }, [stations, searchQuery]);

  return (
    <div
      className={`flex flex-col h-full ${themeStyles.phoneBg} font-cairo p-4 overflow-y-auto space-y-4 transition-colors duration-300`}
    >
      <audio
        ref={audioRef}
        preload="none"
        onPlaying={() => {
          clearWatchdog();
          setIsPlaying(true);
          setIsBuffering(false);
          setStreamError(false);
        }}
        onWaiting={() => {
          if (!userStoppedRef.current) setIsBuffering(true);
        }}
        onPause={() => {
          if (userStoppedRef.current) setIsPlaying(false);
        }}
        onError={handleAudioError}
        onStalled={handleAudioError}
      />

      {/* Radio Header */}
      <div
        className={`${themeStyles.accentSoftBg} p-4 rounded-2xl border ${themeStyles.accentBorder} shadow-lg text-center space-y-1`}
      >
        <div
          className={`w-12 h-12 rounded-full ${themeStyles.subSurfaceBg} border ${themeStyles.accentBorder} mx-auto flex items-center justify-center ${themeStyles.accentText} shadow-md`}
        >
          <Radio className="w-6 h-6" />
        </div>
        <h2 className={`text-lg font-bold ${themeStyles.accentText} font-amiri mt-2`}>
          {t.radioTitle}
        </h2>
        <p className={`text-xs ${themeStyles.textSecondary}`}>{t.radioSubtitle}</p>
      </div>

      {/* Now Playing & Auto-Failover Banner */}
      <div
        className={`${themeStyles.cardBg} border ${themeStyles.accentBorder} p-4 rounded-2xl space-y-3 shadow-md`}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isPlaying
                  ? `${themeStyles.progressBarBg}`
                  : isBuffering || isReconnecting
                  ? 'bg-amber-400 animate-pulse'
                  : 'bg-slate-600'
              }`}
            />
            <span className={`text-xs font-bold ${themeStyles.accentText}`}>
              {streamError
                ? 'تعذر الاتصال - جرب رابطاً بديلاً'
                : isBuffering || isReconnecting
                ? 'جاري تحميل البث المباشر...'
                : isPlaying
                ? 'البث المباشر يعمل الآن'
                : 'جاهز للتشغيل'}
            </span>
          </div>

          <div className={`text-[11px] font-semibold ${themeStyles.textSecondary} flex items-center gap-1.5 tabular-nums`}>
            <Wifi className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
            <span>{activeProtocol}</span>
            <span>·</span>
            <span>
              {frequencyIndex + 1}/{currentFreqs.length}
            </span>
          </div>
        </div>

        <div className="text-center py-1">
          <h3 className={`text-base font-bold ${themeStyles.accentText} font-amiri`}>
            {currentStation.name}
          </h3>
          <p className={`text-xs ${themeStyles.textSecondary} mt-1`}>
            {statusNote || `${currentStation.country} · تبديل تلقائي بين روابط HLS و Icecast`}
          </p>
        </div>

        {pausedBySmartPause === 'radio' && (
          <div className="bg-amber-950/60 border border-amber-700/50 p-2.5 rounded-xl text-xs text-amber-200 flex items-center justify-center gap-2">
            <PhoneOff className="w-4 h-4 text-amber-400 shrink-0" />
            <span>التوقف الذكي: تم إيقاف البث مؤقتاً وسيعود بعد انتهاء الحدث</span>
          </div>
        )}

        {streamError && (
          <div className="bg-amber-950/40 border border-amber-900/50 p-2.5 rounded-xl text-xs text-amber-300 flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4" /> تعذر الرابط الحالي، التبديل لرابط بديل
            </span>
            <button
              onClick={handleRetryStream}
              className={`${themeStyles.accentBg} px-3 py-1 rounded-lg text-xs font-semibold`}
            >
              رابط بديل
            </button>
          </div>
        )}

        <div className="flex items-center justify-center gap-3 pt-1">
          <button
            onClick={() => togglePlay(currentStation)}
            className={`w-12 h-12 rounded-full ${themeStyles.accentBg} flex items-center justify-center shadow-lg transition-transform active:scale-95`}
            title={isPlaying ? t.stop : t.listen}
          >
            {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
          </button>

          <button
            onClick={handleRetryStream}
            disabled={isReconnecting}
            className={`flex items-center gap-1.5 ${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} px-3 py-2 rounded-xl text-xs font-semibold border ${themeStyles.border} transition-colors`}
          >
            <RefreshCcw
              className={`w-4 h-4 ${
                isReconnecting || isBuffering ? `animate-spin ${themeStyles.accentText}` : ''
              }`}
            />
            <span>{isReconnecting ? 'جاري التبديل...' : 'تبديل للرابط البديل'}</span>
          </button>
        </div>
      </div>

      {/* Renewable Live Stations Directory */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between gap-2 px-1">
          <div>
            <h3 className={`text-xs font-bold ${themeStyles.textPrimary}`}>
              {t.radioStationsList} ({stations.length})
            </h3>
            {lastUpdatedLabel && (
              <span className={`text-[10px] ${themeStyles.textSecondary}`}>{lastUpdatedLabel}</span>
            )}
          </div>
          <button
            onClick={() => refreshStationsList(false)}
            disabled={isRefreshingList}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold border ${themeStyles.subSurfaceBg} ${themeStyles.accentText} ${themeStyles.accentBorder} hover:opacity-90`}
          >
            <RefreshCcw className={`w-3.5 h-3.5 ${isRefreshingList ? 'animate-spin' : ''}`} />
            <span>تحديث القائمة</span>
          </button>
        </div>

        {/* Search Input for Large Renewable List */}
        <div className={`flex items-center gap-2 ${themeStyles.cardBg} border ${themeStyles.border} rounded-xl px-3 py-2`}>
          <Search className={`w-4 h-4 ${themeStyles.textSecondary} shrink-0`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن إذاعة أو قارئ..."
            className={`w-full bg-transparent text-xs ${themeStyles.textPrimary} placeholder:${themeStyles.textSecondary} focus:outline-none`}
          />
        </div>

        {filteredStations.map((station) => {
          const isSelected = currentStation.id === station.id;
          const totalLinks = getAllFrequencies(station).length;
          return (
            <div
              key={station.id}
              onClick={() => togglePlay(station)}
              className={`flex items-center justify-between p-3.5 rounded-xl border transition-all cursor-pointer ${
                isSelected
                  ? `${themeStyles.accentSoftBg} ${themeStyles.accentBorder} shadow-md`
                  : `${themeStyles.cardBg} ${themeStyles.border} hover:opacity-90`
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isSelected
                      ? themeStyles.accentBg
                      : `${themeStyles.subSurfaceBg} ${themeStyles.textSecondary}`
                  }`}
                >
                  <Radio className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h4 className={`text-xs font-bold ${themeStyles.textPrimary} truncate`}>
                    {station.name}
                  </h4>
                  <span className={`text-[10px] ${themeStyles.textSecondary}`}>
                    {station.country} · {station.streamType || (isHlsUrl(station.url) ? 'HLS' : 'Icecast')} · {totalLinks} روابط بديلة
                  </span>
                </div>
              </div>

              <button
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                  isSelected && isPlaying
                    ? themeStyles.accentBg
                    : `${themeStyles.subSurfaceBg} ${themeStyles.textSecondary}`
                }`}
              >
                {isSelected && isPlaying ? (
                  <Pause className="w-3.5 h-3.5" />
                ) : (
                  <Play className="w-3.5 h-3.5 ml-0.5" />
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
