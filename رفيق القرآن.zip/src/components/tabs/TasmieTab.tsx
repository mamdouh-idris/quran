import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AppSettings, Ayah, Surah, TasmieResult } from '../../types';
import {
  AlertTriangle,
  Award,
  BookOpen,
  CheckCircle2,
  Eraser,
  Eye,
  EyeOff,
  Mic,
  MicOff,
  RotateCcw,
  Sparkles,
  BarChart3,
  Trophy,
  TrendingUp,
  X,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ThemeStyles, getFontClass } from '../../utils/theme';
import { Translations } from '../../utils/i18n';
import { sanitizeSurahAyahs, stripLeadingBismillah } from '../../utils/quranHelpers';
import {
  AlignedWordResult,
  ExpectedWordEntry,
  evaluateRecitationAligned,
  evaluateSpokenWordsLive,
  extractCleanRecognitionTranscript,
  mergeSpeechChunkWithoutRepetition,
  normalizeArabicWordForTasmie,
} from '../../utils/tasmieMatcher';
import { loadTasmieStats, recordTasmieSession, TasmieStatsRecord } from '../../utils/tasmieStats';

interface TasmieTabProps {
  surahs: Surah[];
  settings: AppSettings;
  themeStyles: ThemeStyles;
  t: Translations;
}

type RecitationScope = 'single' | 'range' | 'surah';

export const TasmieTab: React.FC<TasmieTabProps> = ({ surahs, settings, themeStyles, t }) => {
  const [selectedSurahIndex, setSelectedSurahIndex] = useState<number>(0);
  const selectedSurah = surahs[selectedSurahIndex] || surahs[0];

  const [fetchedAyahsMap, setFetchedAyahsMap] = useState<Record<number, Ayah[]>>({});
  const [isLoadingSurah, setIsLoadingSurah] = useState<boolean>(false);

  const [scope, setScope] = useState<RecitationScope>('single');
  const [selectedAyahNumber, setSelectedAyahNumber] = useState<number>(1);
  const [rangeStart, setRangeStart] = useState<number>(1);
  const [rangeEnd, setRangeEnd] = useState<number>(3);

  const [isAyahHidden, setIsAyahHidden] = useState<boolean>(true);
  const [revealedHintCount, setRevealedHintCount] = useState<number>(0);

  const [isListening, setIsListening] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [hasInterimSpeech, setHasInterimSpeech] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [result, setResult] = useState<TasmieResult | null>(null);
  const [alignedReview, setAlignedReview] = useState<AlignedWordResult[]>([]);
  const [speechSupported, setSpeechSupported] = useState(false);

  const recognitionRef = useRef<any>(null);
  const restartTimerRef = useRef<number | null>(null);
  const shouldKeepListeningRef = useRef<boolean>(false);
  const sessionBaseTranscriptRef = useRef<string>('');
  const transcriptRef = useRef<string>('');
  transcriptRef.current = liveTranscript;

  const [statsData, setStatsData] = useState<TasmieStatsRecord>(() => loadTasmieStats());
  const [showStatsModal, setShowStatsModal] = useState<boolean>(false);

  const activeFontClass = getFontClass(settings.fontFamily);

  // Hydrate full ayahs for selected Surah (shared cache with MushafTab)
  useEffect(() => {
    const surahNum = selectedSurah.number;
    if (fetchedAyahsMap[surahNum] || selectedSurah.ayahs.length >= selectedSurah.numberOfAyahs) {
      return;
    }

    const cacheKey = `rafiq_quran_surah_${surahNum}`;
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached) as Ayah[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          const cleaned = sanitizeSurahAyahs(surahNum, parsed);
          setFetchedAyahsMap((prev) => ({ ...prev, [surahNum]: cleaned }));
          try {
            localStorage.setItem(cacheKey, JSON.stringify(cleaned));
          } catch {
            // Ignore quota errors
          }
          return;
        }
      }
    } catch {
      // Ignore storage errors
    }

    let cancelled = false;
    setIsLoadingSurah(true);
    fetch(`https://api.alquran.cloud/v1/surah/${surahNum}/quran-uthmani`)
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error('Failed'))))
      .then((data) => {
        if (cancelled || !data?.data?.ayahs) return;
        const parsedAyahs: Ayah[] = data.data.ayahs.map((item: any, idx: number) => {
          const rawText: string = item.text || '';
          const text =
            idx === 0 && surahNum !== 1 && surahNum !== 9
              ? stripLeadingBismillah(rawText)
              : rawText;
          return {
            number: item.numberInSurah || idx + 1,
            text,
            juz: item.juz || 1,
            page: item.page || surahNum,
          };
        });
        setFetchedAyahsMap((prev) => ({ ...prev, [surahNum]: parsedAyahs }));
        try {
          localStorage.setItem(cacheKey, JSON.stringify(parsedAyahs));
        } catch {
          // Ignore quota errors
        }
      })
      .catch(() => {
        // Fallback to bundled ayahs
      })
      .finally(() => {
        if (!cancelled) setIsLoadingSurah(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selectedSurah, fetchedAyahsMap]);

  const activeAyahs: Ayah[] = useMemo(() => {
    const raw = fetchedAyahsMap[selectedSurah.number] || selectedSurah.ayahs;
    return sanitizeSurahAyahs(selectedSurah.number, raw);
  }, [fetchedAyahsMap, selectedSurah]);

  const targetAyahs: Ayah[] = useMemo(() => {
    if (scope === 'surah') {
      return activeAyahs;
    }
    if (scope === 'range') {
      const min = Math.min(rangeStart, rangeEnd);
      const max = Math.max(rangeStart, rangeEnd);
      const sliced = activeAyahs.filter((a) => a.number >= min && a.number <= max);
      return sliced.length > 0 ? sliced : activeAyahs.slice(0, 1);
    }
    const found = activeAyahs.find((a) => a.number === selectedAyahNumber) || activeAyahs[0];
    return found ? [found] : [];
  }, [activeAyahs, scope, rangeStart, rangeEnd, selectedAyahNumber]);

  const expectedEntries: ExpectedWordEntry[] = useMemo(() => {
    const list: ExpectedWordEntry[] = [];
    targetAyahs.forEach((ayah) => {
      ayah.text
        .trim()
        .split(/\s+/)
        .filter(Boolean)
        .forEach((word) => {
          const cleanWord = normalizeArabicWordForTasmie(word);
          if (cleanWord) {
            list.push({ word, cleanWord, ayahNumber: ayah.number });
          }
        });
    });
    return list;
  }, [targetAyahs]);

  const clearTimersAndSpeech = () => {
    shouldKeepListeningRef.current = false;
    if (restartTimerRef.current !== null) {
      window.clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // Ignore stop errors
      }
    }
  };

  // Initialize SpeechRecognition cleanly — never pre-fills verses before user speaks
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      setSpeechSupported(true);
      const recognition = new SpeechRecognition();
      recognition.lang = 'ar-SA';
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      recognition.onresult = (event: any) => {
        const { finalText, interimText } = extractCleanRecognitionTranscript(event.results);
        setHasInterimSpeech(Boolean(interimText));

        let sessionMerged = finalText || '';
        if (interimText) {
          sessionMerged = sessionMerged
            ? mergeSpeechChunkWithoutRepetition(sessionMerged, interimText)
            : interimText;
        }

        const display = sessionMerged
          ? mergeSpeechChunkWithoutRepetition(sessionBaseTranscriptRef.current, sessionMerged)
          : sessionBaseTranscriptRef.current;

        setLiveTranscript(display);
      };

      recognition.onerror = (event: any) => {
        const err = event?.error;
        if (err === 'not-allowed' || err === 'service-not-allowed') {
          shouldKeepListeningRef.current = false;
          setIsListening(false);
          setHasInterimSpeech(false);
          setMicError('يرجى السماح بالوصول إلى الميكروفون من إعدادات المتصفح أو الهاتف لبدء التسميع.');
          return;
        }
        if (err === 'audio-capture') {
          shouldKeepListeningRef.current = false;
          setIsListening(false);
          setHasInterimSpeech(false);
          setMicError('تعذر الوصول إلى الميكروفون. تأكد من عدم استخدامه في تطبيق آخر.');
          return;
        }
        // Transient errors ('no-speech', 'aborted', 'network'): stay open until user stops or finishes Surah
      };

      recognition.onend = () => {
        // Commit recognized transcript before restarting session so pausing never loses words
        sessionBaseTranscriptRef.current = transcriptRef.current;
        setHasInterimSpeech(false);

        if (shouldKeepListeningRef.current) {
          restartTimerRef.current = window.setTimeout(() => {
            if (!shouldKeepListeningRef.current) return;
            try {
              recognition.start();
            } catch {
              // Retry once after brief pause in case recognizer was resetting
              restartTimerRef.current = window.setTimeout(() => {
                if (!shouldKeepListeningRef.current) return;
                try {
                  recognition.start();
                } catch {
                  shouldKeepListeningRef.current = false;
                  setIsListening(false);
                }
              }, 260);
            }
          }, 120);
          return;
        }
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } else {
      setSpeechSupported(false);
    }

    return () => {
      shouldKeepListeningRef.current = false;
      if (restartTimerRef.current !== null) {
        window.clearTimeout(restartTimerRef.current);
        restartTimerRef.current = null;
      }
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  const resetTest = () => {
    clearTimersAndSpeech();
    sessionBaseTranscriptRef.current = '';
    setLiveTranscript('');
    setHasInterimSpeech(false);
    setMicError(null);
    setResult(null);
    setAlignedReview([]);
    setIsListening(false);
    setRevealedHintCount(0);
  };

  const evaluateRecitation = (spokenText: string) => {
    const evalRes = evaluateRecitationAligned(expectedEntries, spokenText);

    const firstAyah = targetAyahs[0]?.number || 1;
    const lastAyah = targetAyahs[targetAyahs.length - 1]?.number || firstAyah;

    const res: TasmieResult = {
      surahNumber: selectedSurah.number,
      ayahStart: firstAyah,
      ayahEnd: lastAyah,
      accuracy: evalRes.accuracy,
      mistakes: evalRes.mistakes.slice(0, 15),
      summary:
        evalRes.accuracy >= 90
          ? 'ما شاء الله! تلاوة متقنة ومطابقة للآيات.'
          : evalRes.accuracy >= 70
          ? 'تلاوة طيبة جداً مع بعض الملاحظات البسيطة أدناه.'
          : 'تم رصد بعض الفروقات في الكلمات أثناء التسميع، راجع الكلمات المميزة أدناه.',
      durationSeconds: 10,
    };

    setAlignedReview(evalRes.alignedWords);
    setResult(res);

    const updatedStats = recordTasmieSession({
      surahName: selectedSurah.name,
      accuracy: evalRes.accuracy,
      correctCount: evalRes.matchedCount,
      totalCount: evalRes.totalCount,
      mistakesCount: evalRes.mistakes.length,
    });
    setStatsData(updatedStats);

    if (evalRes.accuracy >= 70) {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.7 },
      });
    }
  };

  const startListening = async () => {
    clearTimersAndSpeech();
    sessionBaseTranscriptRef.current = '';
    setLiveTranscript('');
    setHasInterimSpeech(false);
    setMicError(null);
    setResult(null);
    setAlignedReview([]);

    if (!speechSupported || !recognitionRef.current) {
      setIsListening(false);
      setMicError(
        'ميزة التعرف المباشر على الصوت غير مدعومة في هذا المتصفح. يرجى استخدام Google Chrome على الهاتف أو تفعيل خدمات الصوت.'
      );
      return;
    }

    // Request real microphone access first so Android/WebView grants permission cleanly
    if (navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
      } catch {
        setIsListening(false);
        setMicError('يرجى السماح بالوصول إلى الميكروفون لكي يتمكن التطبيق من سماع تلاوتك.');
        return;
      }
    }

    setIsListening(true);
    shouldKeepListeningRef.current = true;
    try {
      recognitionRef.current.start();
    } catch {
      // Wait briefly if an earlier session was still closing
      restartTimerRef.current = window.setTimeout(() => {
        if (!shouldKeepListeningRef.current) return;
        try {
          recognitionRef.current.start();
        } catch {
          shouldKeepListeningRef.current = false;
          setIsListening(false);
          setMicError('تعذر تشغيل الميكروفون حالياً، حاول مرة أخرى.');
        }
      }, 180);
    }
  };

  const stopListening = () => {
    clearTimersAndSpeech();
    setIsListening(false);
    setHasInterimSpeech(false);
    if (transcriptRef.current.trim()) {
      evaluateRecitation(transcriptRef.current);
    }
  };

  // Evaluate ONLY the words spoken so far verbatim and flag mistakes in red
  const liveEval = useMemo(
    () => evaluateSpokenWordsLive(expectedEntries, liveTranscript),
    [expectedEntries, liveTranscript]
  );

  // When reciting Full Surah, auto-finish only after the full Surah has actually been recited
  useEffect(() => {
    if (
      scope === 'surah' &&
      isListening &&
      !hasInterimSpeech &&
      liveEval.reachedEnd &&
      transcriptRef.current.trim().length > 0
    ) {
      const doneTimer = window.setTimeout(() => {
        if (shouldKeepListeningRef.current) {
          stopListening();
        }
      }, 650);
      return () => window.clearTimeout(doneTimer);
    }
  }, [scope, isListening, hasInterimSpeech, liveEval.reachedEnd]);

  // Live spoken word counter & progress percentage
  const spokenWordCount = liveEval.words.length;

  const progressPct = useMemo(() => {
    if (expectedEntries.length === 0) return 0;
    return Math.min(100, Math.round((liveEval.matchedExpectedUpTo / expectedEntries.length) * 100));
  }, [liveEval.matchedExpectedUpTo, expectedEntries.length]);

  const hintWordsPreview = useMemo(() => {
    if (revealedHintCount <= 0 || expectedEntries.length === 0) return '';
    return expectedEntries
      .slice(0, Math.min(revealedHintCount, expectedEntries.length))
      .map((e) => e.word)
      .join(' ');
  }, [revealedHintCount, expectedEntries]);

  return (
    <div
      className={`flex flex-col h-full ${themeStyles.phoneBg} font-cairo p-4 overflow-y-auto space-y-4 transition-colors duration-300`}
    >
      {/* Banner */}
      <div
        className={`${themeStyles.accentSoftBg} p-4 rounded-2xl border ${themeStyles.accentBorder} shadow-lg text-center`}
      >
        <h2 className={`text-base font-bold ${themeStyles.accentText} ${activeFontClass}`}>
          {t.tasmieTitle}
        </h2>
        <p className={`text-xs ${themeStyles.textSecondary} mt-1`}>{t.tasmieDesc}</p>
      </div>

      {/* Stats Dashboard Trigger Button */}
      <button
        onClick={() => setShowStatsModal(true)}
        className={`w-full py-2.5 px-3 rounded-2xl ${themeStyles.cardBg} border ${themeStyles.border} ${themeStyles.textPrimary} text-xs font-bold flex items-center justify-between gap-2 shadow-sm hover:opacity-90 transition-colors`}
      >
        <div className="flex items-center gap-2">
          <BarChart3 className={`w-4 h-4 ${themeStyles.accentText}`} />
          <span>لوحة إحصائيات التسميع والتحفيز</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={`text-[10px] px-2 py-0.5 rounded-full ${themeStyles.accentSoftBg} ${themeStyles.accentText}`}>
            {statsData.totalSessions} جلسة · {statsData.averageAccuracy}% دقة
          </span>
          <TrendingUp className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
        </div>
      </button>

      {/* Surah, Scope & Ayah Range Selector */}
      <div className={`space-y-3 ${themeStyles.cardBg} p-4 rounded-2xl border ${themeStyles.border}`}>
        <div>
          <label className={`text-xs ${themeStyles.textSecondary} block mb-1`}>{t.selectSurah}</label>
          <select
            value={selectedSurah.number}
            onChange={(e) => {
              const idx = surahs.findIndex((s) => s.number === Number(e.target.value));
              if (idx !== -1) {
                setSelectedSurahIndex(idx);
                setSelectedAyahNumber(1);
                setRangeStart(1);
                setRangeEnd(Math.min(3, surahs[idx].numberOfAyahs));
                resetTest();
              }
            }}
            className={`w-full ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none`}
          >
            {surahs.map((s) => (
              <option key={s.number} value={s.number}>
                {s.number}. {s.name} ({s.numberOfAyahs})
              </option>
            ))}
          </select>
        </div>

        {/* Recitation Scope Switcher */}
        <div className="space-y-1.5">
          <span className={`text-xs ${themeStyles.textSecondary} block`}>{t.recitationScope}</span>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'single', label: t.scopeSingle },
              { id: 'range', label: t.scopeRange },
              { id: 'surah', label: t.scopeFullSurah },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setScope(item.id as RecitationScope);
                  resetTest();
                }}
                className={`py-2 px-2 rounded-xl text-[11px] font-bold border transition-all ${
                  scope === item.id
                    ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow-sm`
                    : `${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {/* Ayah / Range Picker */}
        {scope === 'single' && (
          <div>
            <label className={`text-xs ${themeStyles.textSecondary} block mb-1`}>{t.ayahNumber}</label>
            <select
              value={selectedAyahNumber}
              onChange={(e) => {
                setSelectedAyahNumber(Number(e.target.value));
                resetTest();
              }}
              className={`w-full ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none`}
            >
              {activeAyahs.map((ayah) => (
                <option key={ayah.number} value={ayah.number}>
                  {ayah.number}
                </option>
              ))}
            </select>
          </div>
        )}

        {scope === 'range' && (
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className={`text-[11px] ${themeStyles.textSecondary} block mb-1`}>{t.fromAyah}</label>
              <select
                value={rangeStart}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setRangeStart(val);
                  if (val > rangeEnd) setRangeEnd(val);
                  resetTest();
                }}
                className={`w-full ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-3 py-1.5 text-xs font-semibold focus:outline-none`}
              >
                {activeAyahs.map((ayah) => (
                  <option key={ayah.number} value={ayah.number}>
                    {ayah.number}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className={`text-[11px] ${themeStyles.textSecondary} block mb-1`}>{t.toAyah}</label>
              <select
                value={rangeEnd}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setRangeEnd(val);
                  if (val < rangeStart) setRangeStart(val);
                  resetTest();
                }}
                className={`w-full ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-3 py-1.5 text-xs font-semibold focus:outline-none`}
              >
                {activeAyahs.map((ayah) => (
                  <option key={ayah.number} value={ayah.number}>
                    {ayah.number}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {scope === 'surah' && (
          <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.accentBorder} rounded-xl px-3 py-2 flex items-center justify-between text-xs`}>
            <span className={`flex items-center gap-1.5 font-bold ${themeStyles.accentText}`}>
              <BookOpen className="w-4 h-4" />
              <span>{selectedSurah.name}</span>
            </span>
            <span className={themeStyles.textSecondary}>
              {isLoadingSurah ? '...' : `${activeAyahs.length} آية`}
            </span>
          </div>
        )}

        {/* Hide / Reveal & Progressive Word Hint Controls */}
        <div className={`${themeStyles.subSurfaceBg} p-3.5 rounded-xl border ${themeStyles.border} space-y-2.5`}>
          <div className="flex items-center justify-between gap-2">
            <button
              onClick={() => setIsAyahHidden(!isAyahHidden)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold border transition-all ${
                isAyahHidden
                  ? `${themeStyles.accentBg} ${themeStyles.accentBorder}`
                  : `${themeStyles.cardBg} ${themeStyles.textPrimary} ${themeStyles.border}`
              }`}
            >
              {isAyahHidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span>{isAyahHidden ? t.showAyahText : t.hideAyahText}</span>
            </button>

            {isAyahHidden && expectedEntries.length > 0 && (
              <button
                onClick={() =>
                  setRevealedHintCount((c) =>
                    c >= expectedEntries.length ? 0 : c + 1
                  )
                }
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold border ${themeStyles.cardBg} ${themeStyles.accentText} ${themeStyles.accentBorder}`}
              >
                <Sparkles className="w-3 h-3" />
                <span>
                  {revealedHintCount === 0
                    ? t.revealFirstWord
                    : revealedHintCount >= expectedEntries.length
                    ? 'إخفاء التلميح'
                    : `الكلمة التالية (${revealedHintCount}/${expectedEntries.length})`}
                </span>
              </button>
            )}
          </div>

          {isAyahHidden ? (
            <div className="py-4 px-2 text-center space-y-2">
              <div className={`w-10 h-10 rounded-full ${themeStyles.accentSoftBg} mx-auto flex items-center justify-center ${themeStyles.accentText}`}>
                <EyeOff className="w-5 h-5" />
              </div>
              <p className={`text-xs ${themeStyles.textSecondary}`}>{t.ayahHiddenPlaceholder}</p>
              {hintWordsPreview && (
                <p className={`${activeFontClass} text-lg ${themeStyles.accentText} pt-1 leading-relaxed`} dir="rtl">
                  «{hintWordsPreview}
                  {revealedHintCount < expectedEntries.length ? ' ...' : ''}»
                </p>
              )}
            </div>
          ) : (
            <div
              dir="rtl"
              className={`${activeFontClass} text-lg ${themeStyles.mushafText} leading-loose text-justify max-h-40 overflow-y-auto px-1`}
            >
              {targetAyahs.map((ayah) => (
                <span key={ayah.number} className="inline">
                  {ayah.text}{' '}
                  <span
                    className={`inline-flex items-center justify-center w-6 h-6 mx-1 text-[10px] font-cairo border rounded-full ${themeStyles.cardBg} ${themeStyles.accentBorder} ${themeStyles.accentText}`}
                  >
                    {ayah.number}
                  </span>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Mic Box & Progress */}
      <div
        className={`${themeStyles.cardBg} border ${themeStyles.border} rounded-2xl p-5 flex flex-col items-center justify-center min-h-[136px] relative shadow-inner space-y-3`}
      >
        {isListening ? (
          <div className="flex flex-col items-center gap-2.5 w-full">
            <div className="w-14 h-14 rounded-full bg-red-500/20 border-2 border-red-500 flex items-center justify-center shadow-lg animate-pulse">
              <Mic className="w-7 h-7 text-red-400" />
            </div>
            <span className="text-xs font-bold text-red-400">
              {t.listeningActive}
            </span>
            <div className="w-full max-w-[220px] space-y-1">
              <div className="h-1.5 w-full rounded-full bg-slate-500/20 overflow-hidden">
                <div
                  className={`h-full transition-all duration-200 ${themeStyles.progressBarBg}`}
                  style={{ width: `${progressPct}%` }}
                />
              </div>
              <div className={`text-[10px] text-center ${themeStyles.textSecondary} tabular-nums`}>
                تم سماع {spokenWordCount} كلمة {liveEval.mistakeCount > 0 ? `· ${liveEval.mistakeCount} تحتاج مراجعة` : ''}
              </div>
            </div>
          </div>
        ) : result ? (
          <div className="flex flex-col items-center gap-2 w-full">
            <div
              className={`flex items-center gap-2 ${themeStyles.accentText} ${themeStyles.accentSoftBg} px-4 py-2 rounded-xl border ${themeStyles.accentBorder}`}
            >
              <Award className="w-5 h-5" />
              <span className="text-sm font-bold">
                {t.accuracyScore} {result.accuracy}%
              </span>
            </div>
            <p className={`text-xs ${themeStyles.textSecondary} text-center`}>{result.summary}</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2.5 text-center">
            <div
              className={`w-14 h-14 rounded-full ${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} flex items-center justify-center ${themeStyles.accentText} shadow-md`}
            >
              <Mic className="w-6 h-6" />
            </div>
            <span className={`text-xs ${themeStyles.textSecondary}`}>{t.listeningPrompt}</span>
          </div>
        )}
      </div>

      {/* Microphone Error Banner (Never fakes verses) */}
      {micError && (
        <div className="bg-red-500/15 border border-red-500/40 text-red-400 rounded-xl p-3 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{micError}</span>
        </div>
      )}

      {/* Live Verbatim Spoken Transcript — Highlights any wrong spoken word in RED */}
      {(isListening || liveTranscript) && !result && (
        <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-3 rounded-xl space-y-2`}>
          <div className="flex items-center justify-between gap-2">
            <span className={`text-[11px] font-bold ${themeStyles.accentText}`}>
              {t.transcriptTitle}
            </span>
            <div className="flex items-center gap-2">
              {liveEval.mistakeCount > 0 && (
                <span className="text-[10px] font-bold text-red-500 bg-red-500/15 px-2 py-0.5 rounded-full">
                  أخطاء بالأحمر: {liveEval.mistakeCount}
                </span>
              )}
              {liveTranscript && (
                <button
                  onClick={() => {
                    sessionBaseTranscriptRef.current = '';
                    setLiveTranscript('');
                  }}
                  className={`text-[10px] flex items-center gap-1 ${themeStyles.textSecondary} hover:opacity-80`}
                >
                  <Eraser className="w-3 h-3" />
                  <span>مسح</span>
                </button>
              )}
            </div>
          </div>

          {liveEval.words.length === 0 ? (
            <p className={`text-xs ${themeStyles.textSecondary} text-right py-1`} dir="rtl">
              في انتظار صوتك... لن يظهر أي نص إلا بعد أن تتلو بصوتك.
            </p>
          ) : (
            <div
              className={`${activeFontClass} text-lg text-right leading-loose flex flex-wrap gap-x-1.5 gap-y-1`}
              dir="rtl"
            >
              {liveEval.words.map((w, idx) => (
                <span
                  key={`${w.spokenWord}-${idx}`}
                  className={
                    w.isCorrect
                      ? themeStyles.mushafText
                      : 'text-red-500 bg-red-500/15 underline decoration-red-500 decoration-2 font-bold px-1 rounded'
                  }
                >
                  {w.spokenWord}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Control Buttons */}
      <div className="flex items-center gap-2">
        {!isListening && !result && (
          <button
            onClick={startListening}
            className={`flex-1 py-3 ${themeStyles.accentBg} font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition-all`}
          >
            <Mic className="w-4 h-4" />
            <span>{t.startTasmie}</span>
          </button>
        )}

        {isListening && (
          <button
            onClick={stopListening}
            className="flex-1 py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
          >
            <MicOff className="w-4 h-4" />
            <span>{t.stopAndEvaluate}</span>
          </button>
        )}

        {result && (
          <button
            onClick={resetTest}
            className={`flex-1 py-3 ${themeStyles.cardBg} ${themeStyles.accentText} font-bold rounded-xl text-xs flex items-center justify-center gap-2 border ${themeStyles.accentBorder} transition-all`}
          >
            <RotateCcw className="w-4 h-4" />
            <span>{t.retryTasmie}</span>
          </button>
        )}
      </div>

      {/* Color-Coded Word-by-Word Evaluation Sheet */}
      {result && alignedReview.length > 0 && (
        <div className={`${themeStyles.cardBg} p-4 rounded-2xl border ${themeStyles.border} space-y-2.5`}>
          <div className={`flex items-center justify-between text-xs font-bold border-b ${themeStyles.border} pb-2`}>
            <span className={`flex items-center gap-1.5 ${themeStyles.accentText}`}>
              <CheckCircle2 className="w-4 h-4" />
              <span>مطابقة الكلمات</span>
            </span>
            <span className={`${themeStyles.textSecondary} tabular-nums font-normal`}>
              {alignedReview.filter((w) => w.status === 'matched').length} / {alignedReview.length}
            </span>
          </div>

          <div
            dir="rtl"
            className={`${activeFontClass} text-lg leading-loose flex flex-wrap gap-x-1.5 gap-y-1`}
          >
            {alignedReview.map((w, idx) => (
              <span
                key={`${w.ayahNumber}-${idx}`}
                title={
                  w.status === 'matched'
                    ? 'متطابقة'
                    : `المقروء: ${w.spokenWord}`
                }
                className={`px-1 rounded transition-colors ${
                  w.status === 'matched'
                    ? 'text-emerald-500'
                    : w.status === 'mismatch'
                    ? 'bg-amber-500/15 text-amber-500 underline decoration-amber-500/60'
                    : 'bg-red-500/15 text-red-400 underline decoration-red-400/60'
                }`}
              >
                {w.expectedWord}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Detailed Mistakes Breakdown */}
      {result && result.mistakes.length > 0 && (
        <div className={`${themeStyles.cardBg} p-4 rounded-2xl border ${themeStyles.border} space-y-2 animate-in fade-in`}>
          <h3 className={`text-xs font-bold text-red-400 flex items-center gap-1.5 border-b ${themeStyles.border} pb-2`}>
            <AlertTriangle className="w-4 h-4" />
            <span>{t.mistakesTitle}</span>
          </h3>
          {result.mistakes.map((m, idx) => (
            <div
              key={idx}
              className="bg-red-950/30 border border-red-900/40 p-2.5 rounded-xl text-xs flex items-center justify-between gap-2"
            >
              <span className="text-amber-400 font-semibold">
                آية {m.ayahNumber}: ({m.spokenWord})
              </span>
              <span className={`${themeStyles.accentText} font-bold ${activeFontClass} text-sm`} dir="rtl">
                ✓ {m.correction}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Stats Dashboard Modal */}
      {showStatsModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div
            className={`${themeStyles.surfaceBg} border ${themeStyles.accentBorder} rounded-3xl p-5 w-full max-w-md shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-slate-700/50">
              <div className="flex items-center gap-2">
                <div className={`w-9 h-9 rounded-xl ${themeStyles.accentSoftBg} flex items-center justify-center ${themeStyles.accentText}`}>
                  <Trophy className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`text-sm font-bold ${themeStyles.textPrimary}`}>
                    لوحة تحكم إحصائيات التسميع
                  </h3>
                  <p className={`text-[10px] ${themeStyles.textSecondary}`}>
                    تتبع تقدمك وكلماتك الصحيحة والأخطاء المصححة
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowStatsModal(false)}
                className={`p-1.5 rounded-xl ${themeStyles.cardBg} ${themeStyles.textSecondary} border ${themeStyles.border}`}
                aria-label="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Stats Grid Counters */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-3 rounded-2xl text-center space-y-1`}>
                <span className={`text-[10px] ${themeStyles.textSecondary} block`}>جلسات التسميع</span>
                <span className={`text-xl font-extrabold ${themeStyles.accentText} tabular-nums`}>
                  {statsData.totalSessions}
                </span>
              </div>
              <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-3 rounded-2xl text-center space-y-1`}>
                <span className={`text-[10px] ${themeStyles.textSecondary} block`}>متوسط الإتقان والدقة</span>
                <span className={`text-xl font-extrabold text-emerald-400 tabular-nums`}>
                  {statsData.averageAccuracy}%
                </span>
              </div>
              <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-3 rounded-2xl text-center space-y-1`}>
                <span className={`text-[10px] ${themeStyles.textSecondary} block`}>الكلمات الصحيحة</span>
                <span className="text-xl font-extrabold text-sky-400 tabular-nums">
                  {statsData.correctWordsCount}
                </span>
              </div>
              <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-3 rounded-2xl text-center space-y-1`}>
                <span className={`text-[10px] ${themeStyles.textSecondary} block`}>الأخطاء المصححة</span>
                <span className="text-xl font-extrabold text-amber-400 tabular-nums">
                  {statsData.mistakesCount}
                </span>
              </div>
            </div>

            {/* Motivational Badges */}
            <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-3.5 rounded-2xl space-y-2`}>
              <h4 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5`}>
                <Award className="w-4 h-4" />
                <span>الأوسمة والشارات التحفيزية</span>
              </h4>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className={`p-2 rounded-xl border ${statsData.totalSessions >= 1 ? `${themeStyles.accentSoftBg} ${themeStyles.accentBorder}` : 'bg-black/20 opacity-40 border-slate-800'}`}>
                  <span className="text-lg block">🌟</span>
                  <span className={`text-[10px] font-bold block mt-1 ${themeStyles.textPrimary}`}>بداية مباركة</span>
                </div>
                <div className={`p-2 rounded-xl border ${statsData.totalSessions >= 3 ? `${themeStyles.accentSoftBg} ${themeStyles.accentBorder}` : 'bg-black/20 opacity-40 border-slate-800'}`}>
                  <span className="text-lg block">💎</span>
                  <span className={`text-[10px] font-bold block mt-1 ${themeStyles.textPrimary}`}>الحافظ المثابر</span>
                </div>
                <div className={`p-2 rounded-xl border ${statsData.averageAccuracy >= 85 && statsData.totalSessions >= 2 ? `${themeStyles.accentSoftBg} ${themeStyles.accentBorder}` : 'bg-black/20 opacity-40 border-slate-800'}`}>
                  <span className="text-lg block">🏆</span>
                  <span className={`text-[10px] font-bold block mt-1 ${themeStyles.textPrimary}`}>إتقان تام</span>
                </div>
              </div>
            </div>

            {/* Recitation History */}
            <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-3.5 rounded-2xl space-y-2`}>
              <h4 className={`text-xs font-bold ${themeStyles.textPrimary} flex items-center justify-between`}>
                <span>سجل آخر جلسات التسميع</span>
                <span className={`text-[10px] ${themeStyles.textSecondary}`}>{statsData.history.length} جلسة</span>
              </h4>
              {statsData.history.length === 0 ? (
                <p className={`text-xs ${themeStyles.textSecondary} text-center py-4`}>
                  لم تقم بأي جلسة تسميع بعد. ابدأ الآن واختبر حفظك!
                </p>
              ) : (
                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                  {statsData.history.map((h) => (
                    <div
                      key={h.id}
                      className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} p-2.5 rounded-xl flex items-center justify-between gap-2 text-xs`}
                    >
                      <div>
                        <span className={`font-bold ${themeStyles.textPrimary} block`}>{h.surahName}</span>
                        <span className={`text-[10px] ${themeStyles.textSecondary}`}>{h.date}</span>
                      </div>
                      <div className="text-left" dir="ltr">
                        <span className="text-emerald-400 font-extrabold tabular-nums">{h.accuracy}%</span>
                        <span className={`text-[10px] block ${themeStyles.textSecondary}`}>
                          {h.correctCount}/{h.totalCount} كلمة
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => setShowStatsModal(false)}
              className={`w-full py-2.5 rounded-2xl ${themeStyles.accentBg} text-xs font-bold shadow-md`}
            >
              إغلاق الإحصائيات
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
