import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Surah, Reciter, AppSettings, Ayah } from '../../types';
import {
  Volume2,
  Download,
  ZoomIn,
  ZoomOut,
  Bookmark,
  CheckCircle2,
  Sparkles,
  Play,
  Pause,
  ArrowUp,
  PhoneOff,
} from 'lucide-react';
import { useSmartPause } from '../../context/SmartPauseContext';
import { ThemeStyles, getFontClass, getFontSizeClass } from '../../utils/theme';
import { getTranslations } from '../../utils/i18n';
import { stripLeadingBismillah, sanitizeSurahAyahs } from '../../utils/quranHelpers';
import { InteractiveMushaf, RepeatMode } from '../InteractiveMushaf';
import { SurahTafsirPage } from '../SurahTafsirPage';
import {
  deleteOfflineSurah,
  downloadSurahForOffline,
  getDownloadedSurahNumbers,
  initializeStorageIfNeeded,
  STORAGE_UPDATED_EVENT,
} from '../../utils/storageManager';

export interface BookmarkItem {
  id: string;
  surahIndex: number;
  surahName: string;
  pageIndex: number;
  ayahNumber: number;
  title: string;
  createdAt: string;
}

interface MushafTabProps {
  surahs: Surah[];
  reciters: Reciter[];
  settings: AppSettings;
  themeStyles: ThemeStyles;
}

export const MushafTab: React.FC<MushafTabProps> = ({
  surahs,
  reciters,
  settings,
  themeStyles,
}) => {
  const t = getTranslations(settings.language);
  const [selectedSurahIndex, setSelectedSurahIndex] = useState<number>(0);
  const selectedSurah = surahs[selectedSurahIndex] || surahs[0];

  const [fetchedAyahsMap, setFetchedAyahsMap] = useState<Record<number, Ayah[]>>({});
  const [isLoadingSurahText, setIsLoadingSurahText] = useState<boolean>(false);

  const [selectedReciter, setSelectedReciter] = useState<Reciter>(
    () => reciters.find((r) => r.id === settings.reciterId) || reciters[0]
  );
  const [fontSize, setFontSize] = useState<number>(settings.fontSize || 24);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [downloadedSurahs, setDownloadedSurahs] = useState<number[]>(() => {
    initializeStorageIfNeeded(reciters[0]);
    return getDownloadedSurahNumbers();
  });
  const [isDownloading, setIsDownloading] = useState(false);
  const [showTafsirAtTop, setShowTafsirAtTop] = useState<boolean>(false);
  const [selectedAyahForTafsir, setSelectedAyahForTafsir] = useState<number>(1);
  const [readingProgress, setReadingProgress] = useState<number>(0);
  const [isAnimatingPage, setIsAnimatingPage] = useState<boolean>(false);
  const [flipDirection, setFlipDirection] = useState<'next' | 'prev'>('next');
  const [currentPageIndex, setCurrentPageIndex] = useState<number>(0);

  // Repeat & Ayah Selection mode states
  const [isSelectionMode, setIsSelectionMode] = useState<boolean>(false);
  const [showRepeatPanel, setShowRepeatPanel] = useState<boolean>(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('none');
  const [repeatRangeStart, setRepeatRangeStart] = useState<number>(1);
  const [repeatRangeEnd, setRepeatRangeEnd] = useState<number>(1);
  const [repeatLimit, setRepeatLimit] = useState<number>(3); // 0 = infinite
  const [currentCycle, setCurrentCycle] = useState<number>(1);
  const [currentPlayingAyah, setCurrentPlayingAyah] = useState<number>(1);
  const [isContinuingAfterRepeat, setIsContinuingAfterRepeat] = useState<boolean>(false);
  const [selectionAnchor, setSelectionAnchor] = useState<'start' | 'end'>('start');
  const [showZoomBadge, setShowZoomBadge] = useState<boolean>(false);

  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(() => {
    try {
      const saved = localStorage.getItem('rafiq_quran_bookmarks_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [
      {
        id: '1',
        surahIndex: 0,
        surahName: surahs[0].name,
        pageIndex: 0,
        ayahNumber: 1,
        title: `${surahs[0].name} - البداية`,
        createdAt: new Date().toLocaleDateString('ar-EG'),
      },
    ];
  });
  const [showBookmarksModal, setShowBookmarksModal] = useState<boolean>(false);

  const saveCurrentBookmark = () => {
    const currentAyahNum = pageAyahs[0]?.number || 1;
    const newItem: BookmarkItem = {
      id: Date.now().toString(),
      surahIndex: selectedSurahIndex,
      surahName: selectedSurah.name,
      pageIndex: safePageIndex,
      ayahNumber: currentAyahNum,
      title: `${selectedSurah.name} - آية ${currentAyahNum} (صفحة ${safePageIndex + 1})`,
      createdAt: new Date().toLocaleDateString('ar-EG', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
    };
    const filtered = bookmarks.filter(b => !(b.surahIndex === selectedSurahIndex && b.pageIndex === safePageIndex));
    const updated = [newItem, ...filtered];
    setBookmarks(updated);
    try {
      localStorage.setItem('rafiq_quran_bookmarks_list', JSON.stringify(updated));
    } catch {}
    alert(`تم حفظ العلامة المرجعية في ${newItem.title} بنجاح!`);
  };

  const jumpToBookmarkItem = (item: BookmarkItem) => {
    triggerPageFlip(() => {
      setSelectedSurahIndex(item.surahIndex);
      setCurrentPageIndex(item.pageIndex);
    });
    setShowBookmarksModal(false);
  };

  const deleteBookmarkItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = bookmarks.filter(b => b.id !== id);
    setBookmarks(updated);
    try {
      localStorage.setItem('rafiq_quran_bookmarks_list', JSON.stringify(updated));
    } catch {}
  };

  const mushafWrapperRef = useRef<HTMLDivElement | null>(null);
  const touchStartX = useRef<number>(0);
  const touchEndX = useRef<number>(0);
  const pinchStartDistRef = useRef<number | null>(null);
  const pinchStartFontRef = useRef<number>(fontSize);
  const isPinchingRef = useRef<boolean>(false);
  const zoomBadgeTimerRef = useRef<number | null>(null);
  const fontSizeRef = useRef<number>(fontSize);
  fontSizeRef.current = fontSize;

  const mouseStartX = useRef<number | null>(null);
  const mouseStartY = useRef<number | null>(null);
  const pendingPageEntryRef = useRef<'first' | 'last' | number>('first');
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const isPlayingRef = useRef<boolean>(false);
  isPlayingRef.current = isPlayingAudio;

  const repeatStateRef = useRef({
    repeatMode,
    repeatRangeStart,
    repeatRangeEnd,
    repeatLimit,
    currentCycle,
    currentPlayingAyah,
    selectedSurahIndex,
    isContinuingAfterRepeat,
    surahTotalAyahs: selectedSurah.numberOfAyahs,
  });
  repeatStateRef.current = {
    repeatMode,
    repeatRangeStart,
    repeatRangeEnd,
    repeatLimit,
    currentCycle,
    currentPlayingAyah,
    selectedSurahIndex,
    isContinuingAfterRepeat,
    surahTotalAyahs: selectedSurah.numberOfAyahs,
  };

  const {
    pausedBySmartPause,
    registerAudioController,
    notifyAudioStarted,
    notifyAudioStopped,
  } = useSmartPause();

  useEffect(() => {
    setFontSize(settings.fontSize || 24);
  }, [settings.fontSize]);

  useEffect(() => {
    const matched = reciters.find((r) => r.id === settings.reciterId);
    if (matched) setSelectedReciter(matched);
  }, [settings.reciterId, reciters]);

  useEffect(() => {
    const syncDownloads = () => {
      setDownloadedSurahs(getDownloadedSurahNumbers());
    };
    window.addEventListener(STORAGE_UPDATED_EVENT, syncDownloads);
    return () => window.removeEventListener(STORAGE_UPDATED_EVENT, syncDownloads);
  }, []);

  // Fetch & cache full ayahs of the selected surah when not already loaded
  useEffect(() => {
    const surahNum = selectedSurah.number;
    if (fetchedAyahsMap[surahNum] || selectedSurah.ayahs.length >= selectedSurah.numberOfAyahs) {
      return;
    }

    const cacheKey = `rafiq_quran_surah_${surahNum}`;
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached) as Ayah[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          const cleaned = sanitizeSurahAyahs(surahNum, parsed);
          setFetchedAyahsMap((prev) => ({ ...prev, [surahNum]: cleaned }));
          try {
            localStorage.setItem(cacheKey, JSON.stringify(cleaned));
          } catch {
            // Ignore quota errors
          }
          return;
        }
      }
    } catch {
      // Ignore storage errors
    }

    let cancelled = false;
    setIsLoadingSurahText(true);
    fetch(`https://api.alquran.cloud/v1/surah/${surahNum}/quran-uthmani`)
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error('Failed'))))
      .then((data) => {
        if (cancelled || !data?.data?.ayahs) return;
        const parsedAyahs: Ayah[] = data.data.ayahs.map((item: any, idx: number) => {
          const rawText: string = item.text || '';
          const text =
            idx === 0 && surahNum !== 1 && surahNum !== 9
              ? stripLeadingBismillah(rawText)
              : rawText;
          return {
            number: item.numberInSurah || idx + 1,
            text,
            juz: item.juz || 1,
            page: item.page || surahNum,
            tafsir: {
              jalalayn: `تفسير الجلالين للآية (${item.numberInSurah || idx + 1}) من ${selectedSurah.name}.`,
              saadi: `التفسير الميسر للآية (${item.numberInSurah || idx + 1}) من ${selectedSurah.name}.`,
            },
          };
        });
        setFetchedAyahsMap((prev) => ({ ...prev, [surahNum]: parsedAyahs }));
        try {
          localStorage.setItem(cacheKey, JSON.stringify(parsedAyahs));
        } catch {
          // Ignore quota errors
        }
      })
      .catch(() => {
        // Fallback silently to bundled ayahs
      })
      .finally(() => {
        if (!cancelled) setIsLoadingSurahText(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selectedSurah, fetchedAyahsMap]);

  const activeAyahs: Ayah[] = useMemo(() => {
    return fetchedAyahsMap[selectedSurah.number] || selectedSurah.ayahs;
  }, [fetchedAyahsMap, selectedSurah]);

  // Split current Surah into Mushaf pages
  const surahPages = useMemo(() => {
    if (activeAyahs.length === 0) return [];
    const distinctPages = new Set(activeAyahs.map((a) => a.page));

    if (distinctPages.size > 1) {
      const grouped: { mushafPageNumber: number; ayahs: Ayah[] }[] = [];
      for (const ayah of activeAyahs) {
        const lastGroup = grouped[grouped.length - 1];
        if (lastGroup && lastGroup.mushafPageNumber === ayah.page) {
          lastGroup.ayahs.push(ayah);
        } else {
          grouped.push({ mushafPageNumber: ayah.page, ayahs: [ayah] });
        }
      }
      return grouped;
    }

    const chunkSize = 8;
    const chunked: { mushafPageNumber: number; ayahs: Ayah[] }[] = [];
    for (let i = 0; i < activeAyahs.length; i += chunkSize) {
      chunked.push({
        mushafPageNumber: activeAyahs[i].page || selectedSurah.number,
        ayahs: activeAyahs.slice(i, i + chunkSize),
      });
    }
    return chunked;
  }, [activeAyahs, selectedSurah.number]);

  // Reset range when surah changes
  useEffect(() => {
    setRepeatRangeStart(1);
    setRepeatRangeEnd(Math.min(3, selectedSurah.numberOfAyahs));
    setCurrentPlayingAyah(1);
    setSelectedAyahForTafsir(1);
    setCurrentCycle(1);
    setIsContinuingAfterRepeat(false);
    setSelectionAnchor('start');
  }, [selectedSurahIndex, selectedSurah.numberOfAyahs]);

  // Apply initial/pending page index when Surah or pages finish loading
  useEffect(() => {
    if (surahPages.length === 0) return;
    const pending = pendingPageEntryRef.current;
    if (pending === 'last') {
      setCurrentPageIndex(surahPages.length - 1);
      pendingPageEntryRef.current = 'first';
    } else if (typeof pending === 'number') {
      setCurrentPageIndex(Math.min(Math.max(0, pending), surahPages.length - 1));
      pendingPageEntryRef.current = 'first';
    } else {
      setCurrentPageIndex((prev) => Math.min(prev, surahPages.length - 1));
    }
  }, [selectedSurahIndex, surahPages.length]);

  // Update progress bar based on page progress inside current Surah
  useEffect(() => {
    if (surahPages.length <= 1) {
      setReadingProgress(100);
    } else {
      setReadingProgress(Math.round(((currentPageIndex + 1) / surahPages.length) * 100));
    }
  }, [currentPageIndex, surahPages.length]);

  // Keep visible page synced with currently playing ayah in Ayah-Repeat or Continuation mode
  useEffect(() => {
    if (
      (repeatMode === 'ayahs' || isContinuingAfterRepeat) &&
      isPlayingAudio &&
      surahPages.length > 0
    ) {
      const targetPageIdx = surahPages.findIndex((p) =>
        p.ayahs.some((a) => a.number === currentPlayingAyah)
      );
      if (targetPageIdx !== -1 && targetPageIdx !== currentPageIndex) {
        setCurrentPageIndex(targetPageIdx);
      }
    }
  }, [
    currentPlayingAyah,
    repeatMode,
    isContinuingAfterRepeat,
    isPlayingAudio,
    surahPages,
    currentPageIndex,
  ]);

  useEffect(() => {
    return registerAudioController('mushaf', {
      pause: () => {
        audioRef.current?.pause();
        setIsPlayingAudio(false);
      },
      resume: () => {
        if (!audioRef.current) return;
        notifyAudioStarted('mushaf');
        audioRef.current
          .play()
          .then(() => setIsPlayingAudio(true))
          .catch(() => setIsPlayingAudio(false));
      },
      isPlaying: () => isPlayingRef.current,
    });
  }, [registerAudioController, notifyAudioStarted]);

  const pad3 = (num: number) => String(num).padStart(3, '0');

  const getAudioUrlForState = (
    surahNum: number,
    mode: RepeatMode,
    ayahNum: number,
    reciter: Reciter,
    continuingAfterRepeat: boolean = false
  ) => {
    if (mode === 'ayahs' || continuingAfterRepeat) {
      const base = reciter.ayahServerUrl || 'https://everyayah.com/data/Alafasy_128kbps/';
      return `${base}${pad3(surahNum)}${pad3(ayahNum)}.mp3`;
    }
    return `${reciter.serverUrl}${pad3(surahNum)}.mp3`;
  };

  const audioUrl = getAudioUrlForState(
    selectedSurah.number,
    repeatMode,
    currentPlayingAyah,
    selectedReciter,
    isContinuingAfterRepeat
  );

  // Sync audio src when surah, reciter, repeatMode, or currentPlayingAyah changes
  useEffect(() => {
    if (!audioRef.current) return;
    const wasPlaying = isPlayingRef.current;
    audioRef.current.pause();
    audioRef.current.src = audioUrl;
    audioRef.current.load();
    if (wasPlaying) {
      audioRef.current
        .play()
        .then(() => setIsPlayingAudio(true))
        .catch(() => setIsPlayingAudio(false));
    }
  }, [audioUrl]);

  const triggerPageFlip = (callback: () => void, direction: 'next' | 'prev' = 'next') => {
    setFlipDirection(direction);
    if (settings.pageFlipAnimation) {
      setIsAnimatingPage(true);
      setTimeout(() => {
        callback();
        scrollContainerRef.current?.scrollTo({ top: 0 });
        setIsAnimatingPage(false);
      }, 240);
    } else {
      callback();
      scrollContainerRef.current?.scrollTo({ top: 0 });
    }
  };



  const startPlayback = (startAyah?: number) => {
    if (!audioRef.current) return;
    setIsContinuingAfterRepeat(false);
    if (repeatMode === 'ayahs') {
      const targetAyah = startAyah ?? repeatRangeStart;
      setCurrentPlayingAyah(targetAyah);
      setCurrentCycle(1);
      const nextUrl = getAudioUrlForState(
        selectedSurah.number,
        'ayahs',
        targetAyah,
        selectedReciter,
        false
      );
      audioRef.current.src = nextUrl;
    }
    notifyAudioStarted('mushaf');
    audioRef.current
      .play()
      .then(() => {
        setIsPlayingAudio(true);
      })
      .catch(() => {
        setIsPlayingAudio(false);
        notifyAudioStopped('mushaf');
      });
  };

  const togglePlayAudio = () => {
    if (!audioRef.current) return;
    if (isPlayingAudio) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
      notifyAudioStopped('mushaf');
    } else {
      startPlayback();
    }
  };

  const handleAudioEnded = () => {
    const state = repeatStateRef.current;

    // 1. Continuation phase after finishing repeated ayah range: keep advancing ayah-by-ayah to Surah end
    if (state.isContinuingAfterRepeat) {
      if (state.currentPlayingAyah < state.surahTotalAyahs) {
        setCurrentPlayingAyah(state.currentPlayingAyah + 1);
        return;
      }
      // Finished current Surah after continuation -> move to next Surah smoothly
      setIsContinuingAfterRepeat(false);
      setRepeatMode('none');
      if (state.selectedSurahIndex < surahs.length - 1) {
        triggerPageFlip(() => setSelectedSurahIndex((prev) => prev + 1));
        setIsPlayingAudio(true);
      } else {
        setIsPlayingAudio(false);
        notifyAudioStopped('mushaf');
      }
      return;
    }

    // 2. Repeating selected ayah or ayah range
    if (state.repeatMode === 'ayahs') {
      const start = Math.min(state.repeatRangeStart, state.repeatRangeEnd);
      const end = Math.max(state.repeatRangeStart, state.repeatRangeEnd);

      if (state.currentPlayingAyah < end) {
        const nextAyah = state.currentPlayingAyah + 1;
        setCurrentPlayingAyah(nextAyah);
        return;
      }

      // Reached end of ayah range
      const canContinueRepeat =
        state.repeatLimit === 0 || state.currentCycle < state.repeatLimit;
      if (canContinueRepeat) {
        setCurrentCycle((c) => c + 1);
        if (start === end && audioRef.current) {
          // Replay single ayah immediately
          audioRef.current.currentTime = 0;
          audioRef.current
            .play()
            .then(() => setIsPlayingAudio(true))
            .catch(() => {
              setIsPlayingAudio(false);
              notifyAudioStopped('mushaf');
            });
        } else {
          setCurrentPlayingAyah(start);
        }
        return;
      }

      // Repeat cycles completed -> continue playing following ayahs seamlessly!
      if (end < state.surahTotalAyahs) {
        setIsContinuingAfterRepeat(true);
        setCurrentPlayingAyah(end + 1);
        return;
      }

      // Repeated range reached the very last ayah of the Surah -> advance to next Surah
      setIsContinuingAfterRepeat(false);
      setRepeatMode('none');
      if (state.selectedSurahIndex < surahs.length - 1) {
        triggerPageFlip(() => setSelectedSurahIndex((prev) => prev + 1));
        setIsPlayingAudio(true);
      } else {
        setIsPlayingAudio(false);
        notifyAudioStopped('mushaf');
      }
      return;
    }

    // 3. Repeating full Surah
    if (state.repeatMode === 'surah') {
      const canContinue =
        state.repeatLimit === 0 || state.currentCycle < state.repeatLimit;
      if (canContinue && audioRef.current) {
        setCurrentCycle((c) => c + 1);
        audioRef.current.currentTime = 0;
        audioRef.current
          .play()
          .then(() => setIsPlayingAudio(true))
          .catch(() => {
            setIsPlayingAudio(false);
            notifyAudioStopped('mushaf');
          });
        return;
      }
      setRepeatMode('none');
      if (state.selectedSurahIndex < surahs.length - 1) {
        triggerPageFlip(() => setSelectedSurahIndex((prev) => prev + 1));
        setIsPlayingAudio(true);
      } else {
        setIsPlayingAudio(false);
        notifyAudioStopped('mushaf');
      }
      return;
    }

    // 4. Standard mode ('none'): advance to next surah
    if (state.selectedSurahIndex < surahs.length - 1) {
      triggerPageFlip(() => setSelectedSurahIndex((prev) => prev + 1));
      setIsPlayingAudio(true);
    } else {
      setIsPlayingAudio(false);
      notifyAudioStopped('mushaf');
    }
  };

  const handleAyahClick = (ayahNumber: number) => {
    setSelectedAyahForTafsir(ayahNumber);

    if (isSelectionMode || repeatMode === 'ayahs' || showRepeatPanel) {
      setIsContinuingAfterRepeat(false);
      if (repeatMode !== 'ayahs') {
        setRepeatMode('ayahs');
      }
      if (selectionAnchor === 'start') {
        setRepeatRangeStart(ayahNumber);
        setRepeatRangeEnd(ayahNumber);
        setCurrentPlayingAyah(ayahNumber);
        setSelectionAnchor('end');
      } else {
        const minAyah = Math.min(repeatRangeStart, ayahNumber);
        const maxAyah = Math.max(repeatRangeStart, ayahNumber);
        setRepeatRangeStart(minAyah);
        setRepeatRangeEnd(maxAyah);
        setCurrentPlayingAyah(minAyah);
        setSelectionAnchor('start');
      }
    }
  };

  const selectRepeatMode = (mode: RepeatMode) => {
    setIsContinuingAfterRepeat(false);
    setRepeatMode(mode);
    setCurrentCycle(1);
    if (mode !== 'ayahs') {
      setIsSelectionMode(false);
    }
    if (mode === 'ayahs') {
      setCurrentPlayingAyah(repeatRangeStart);
    }
  };

  const toggleDownload = async (surahNum: number) => {
    if (isDownloading) return;
    setIsDownloading(true);
    try {
      if (downloadedSurahs.includes(surahNum)) {
        await deleteOfflineSurah(surahNum);
      } else {
        const targetSurah = surahs.find((s) => s.number === surahNum) || selectedSurah;
        await downloadSurahForOffline(targetSurah, selectedReciter);
      }
      setDownloadedSurahs(getDownloadedSurahNumbers());
    } finally {
      setIsDownloading(false);
    }
  };

  const nextPage = () => {
    if (currentPageIndex < surahPages.length - 1) {
      triggerPageFlip(() => setCurrentPageIndex((prev) => prev + 1), 'next');
    } else if (selectedSurahIndex < surahs.length - 1) {
      pendingPageEntryRef.current = 0;
      triggerPageFlip(() => {
        setSelectedSurahIndex((prev) => prev + 1);
        setCurrentPageIndex(0);
      }, 'next');
    }
  };

  const prevPage = () => {
    if (currentPageIndex > 0) {
      triggerPageFlip(() => setCurrentPageIndex((prev) => prev - 1), 'prev');
    } else if (selectedSurahIndex > 0) {
      pendingPageEntryRef.current = 'last';
      triggerPageFlip(() => setSelectedSurahIndex((prev) => prev - 1), 'prev');
    }
  };

  const flashZoomBadge = () => {
    setShowZoomBadge(true);
    if (zoomBadgeTimerRef.current !== null) {
      window.clearTimeout(zoomBadgeTimerRef.current);
    }
    zoomBadgeTimerRef.current = window.setTimeout(() => {
      setShowZoomBadge(false);
    }, 1200);
  };

  const adjustFontSize = (nextSize: number) => {
    const clamped = Math.min(42, Math.max(16, Math.round(nextSize)));
    setFontSize(clamped);
    flashZoomBadge();
  };

  // Non-passive touch pinch-to-zoom listener on the Mushaf reading area
  useEffect(() => {
    const el = mushafWrapperRef.current;
    if (!el) return;

    const getTouchDist = (touches: TouchList) => {
      const dx = touches[0].clientX - touches[1].clientX;
      const dy = touches[0].clientY - touches[1].clientY;
      return Math.hypot(dx, dy);
    };

    const onNativeTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        isPinchingRef.current = true;
        touchStartX.current = 0;
        touchEndX.current = 0;
        pinchStartDistRef.current = getTouchDist(e.touches);
        pinchStartFontRef.current = fontSizeRef.current;
      }
    };

    const onNativeTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2 && pinchStartDistRef.current) {
        e.preventDefault();
        const dist = getTouchDist(e.touches);
        if (pinchStartDistRef.current > 0) {
          const scale = dist / pinchStartDistRef.current;
          const nextSize = Math.min(42, Math.max(16, Math.round(pinchStartFontRef.current * scale)));
          if (nextSize !== fontSizeRef.current) {
            setFontSize(nextSize);
          }
          flashZoomBadge();
        }
      }
    };

    const onNativeTouchEnd = (e: TouchEvent) => {
      if (isPinchingRef.current && e.touches.length === 0) {
        pinchStartDistRef.current = null;
        window.setTimeout(() => {
          isPinchingRef.current = false;
        }, 80);
      }
    };

    el.addEventListener('touchstart', onNativeTouchStart, { passive: true });
    el.addEventListener('touchmove', onNativeTouchMove, { passive: false });
    el.addEventListener('touchend', onNativeTouchEnd, { passive: true });
    el.addEventListener('touchcancel', onNativeTouchEnd, { passive: true });

    return () => {
      el.removeEventListener('touchstart', onNativeTouchStart);
      el.removeEventListener('touchmove', onNativeTouchMove);
      el.removeEventListener('touchend', onNativeTouchEnd);
      el.removeEventListener('touchcancel', onNativeTouchEnd);
      if (zoomBadgeTimerRef.current !== null) {
        window.clearTimeout(zoomBadgeTimerRef.current);
      }
    };
  }, []);

  // Authentic Arabic RTL Mushaf Swipe:
  // Spine is on the RIGHT; pages turn from LEFT to RIGHT to advance forward (nextPage),
  // and from RIGHT to LEFT to go backward (prevPage).
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length >= 2 || isPinchingRef.current) {
      touchStartX.current = 0;
      touchEndX.current = 0;
      return;
    }
    if (settings.navigationMode !== 'swipe') return;
    touchStartX.current = e.targetTouches[0].clientX;
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length >= 2 || isPinchingRef.current) return;
    if (settings.navigationMode !== 'swipe') return;
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (isPinchingRef.current) {
      touchStartX.current = 0;
      touchEndX.current = 0;
      return;
    }
    if (settings.navigationMode !== 'swipe') return;
    if (!touchStartX.current && !touchEndX.current) return;
    const distance = touchStartX.current - touchEndX.current;
    const minSwipeDistance = 50;

    if (distance < -minSwipeDistance) {
      // Swiped Left -> Right: Next Page in Arabic Mushaf
      nextPage();
    } else if (distance > minSwipeDistance) {
      // Swiped Right -> Left: Previous Page in Arabic Mushaf
      prevPage();
    }
    touchStartX.current = 0;
    touchEndX.current = 0;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (settings.navigationMode !== 'swipe') return;
    mouseStartX.current = e.clientX;
    mouseStartY.current = e.clientY;
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (settings.navigationMode !== 'swipe') return;
    if (mouseStartX.current === null || mouseStartY.current === null) return;
    const dx = e.clientX - mouseStartX.current;
    const dy = Math.abs(e.clientY - mouseStartY.current);
    mouseStartX.current = null;
    mouseStartY.current = null;

    if (Math.abs(dx) > 60 && dy < 50) {
      if (dx > 0) {
        // Dragged Left -> Right: Next Page in Arabic Mushaf
        nextPage();
      } else {
        // Dragged Right -> Left: Previous Page in Arabic Mushaf
        prevPage();
      }
    }
  };

  const isDownloaded = downloadedSurahs.includes(selectedSurah.number);
  const activeFontClass = getFontClass(settings.fontFamily);
  const activeFontSizeClass = getFontSizeClass(fontSize);

  const safePageIndex = Math.min(currentPageIndex, Math.max(0, surahPages.length - 1));
  const currentPageData = surahPages[safePageIndex] || {
    mushafPageNumber: selectedSurah.number,
    ayahs: activeAyahs,
  };
  const pageAyahs = currentPageData.ayahs;

  const isAtFirstPageOfQuran = selectedSurahIndex === 0 && safePageIndex === 0;
  const isAtLastPageOfQuran =
    selectedSurahIndex === surahs.length - 1 && safePageIndex >= surahPages.length - 1;

  const rangeMin = Math.min(repeatRangeStart, repeatRangeEnd);
  const rangeMax = Math.max(repeatRangeStart, repeatRangeEnd);

  return (
    <div
      ref={mushafWrapperRef}
      className={`flex flex-col h-full font-cairo transition-colors duration-300 relative ${themeStyles.phoneBg}`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
    >
      <audio
        ref={audioRef}
        src={audioUrl}
        onEnded={handleAudioEnded}
        onError={() => {
          setIsPlayingAudio(false);
          notifyAudioStopped('mushaf');
        }}
      />

      {!showTafsirAtTop && (
        <>
          {/* Reading Progress Bar at the Top */}
          <div className={`w-full ${themeStyles.subSurfaceBg} h-1.5 overflow-hidden z-30`}>
            <div
              className={`${themeStyles.progressBarBg} h-full transition-all duration-200`}
              style={{ width: `${readingProgress}%` }}
            ></div>
          </div>

          {/* Top Header Bar inside Mobile View */}
          <div
            className={`border-b ${themeStyles.surfaceBg} ${themeStyles.border} px-3 py-2 flex items-center justify-between gap-2 shadow-sm sticky top-0 z-20 transition-colors duration-300`}
          >
            <div className="flex items-center gap-1.5 flex-1 min-w-0">
              <select
                value={selectedSurah.number}
                onChange={(e) => {
                  const idx = surahs.findIndex((item) => item.number === Number(e.target.value));
                  if (idx !== -1) triggerPageFlip(() => setSelectedSurahIndex(idx));
                }}
                className={`w-full border ${themeStyles.subSurfaceBg} ${themeStyles.accentText} ${themeStyles.accentBorder} rounded-xl px-2.5 py-1.5 text-xs font-bold focus:outline-none truncate`}
              >
                {surahs.map((s) => (
                  <option key={s.number} value={s.number}>
                    {s.number}. {s.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Quick Bookmark & Font Zoom Controls */}
            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={saveCurrentBookmark}
                className="px-2 py-1.5 bg-amber-500/20 text-amber-400 border border-amber-500/40 rounded-lg text-[11px] font-bold flex items-center gap-1"
                title="حفظ علامة القراءة الحالية"
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>حفظ</span>
              </button>

              <button
                onClick={() => setShowBookmarksModal(true)}
                className={`px-2 py-1.5 ${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} rounded-lg text-[11px] font-bold flex items-center gap-1`}
                title="العلامات المرجعية المحفوظة"
              >
                <Bookmark className="w-3.5 h-3.5 fill-current" />
                <span>العلامات ({bookmarks.length})</span>
              </button>

              <button
                onClick={() => adjustFontSize(fontSize - 2)}
                className={`p-1.5 ${themeStyles.cardBg} ${themeStyles.textSecondary} rounded-lg border ${themeStyles.border}`}
                title="تصغير الخط"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => adjustFontSize(fontSize + 2)}
                className={`p-1.5 ${themeStyles.cardBg} ${themeStyles.textSecondary} rounded-lg border ${themeStyles.border}`}
                title="تكبير الخط"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Transient Pinch / Font-Size Feedback HUD */}
          {showZoomBadge && (
            <div
              className={`pointer-events-none absolute top-24 left-1/2 -translate-x-1/2 z-40 px-3 py-1 rounded-full ${themeStyles.surfaceBg} border ${themeStyles.accentBorder} ${themeStyles.accentText} text-xs font-bold shadow-lg tabular-nums`}
            >
              حجم الخط: {fontSize}
            </div>
          )}

          {/* Audio & Reciter Selector Bar (Clean top bar with no Repeat/Tafsir covering Surah title) */}
          <div
            className={`border-b ${themeStyles.cardBg} ${themeStyles.border} px-3 py-2 text-xs transition-colors duration-300`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 flex-1 min-w-0">
                <Volume2 className={`w-4 h-4 ${themeStyles.accentText} shrink-0`} />
                <select
                  value={selectedReciter.id}
                  onChange={(e) => {
                    const r = reciters.find((item) => item.id === e.target.value);
                    if (r) setSelectedReciter(r);
                  }}
                  className={`w-full border ${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} ${themeStyles.border} rounded-lg px-2 py-1 text-xs truncate focus:outline-none`}
                >
                  {reciters.map((rec) => (
                    <option key={rec.id} value={rec.id}>
                      {rec.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={togglePlayAudio}
                  className={`px-3 py-1 rounded-lg font-semibold transition-all flex items-center gap-1 ${
                    isPlayingAudio
                      ? 'bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse'
                      : `${themeStyles.accentBg} shadow-sm`
                  }`}
                >
                  {isPlayingAudio ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>
                    {isPlayingAudio
                      ? t.stop
                      : repeatMode === 'ayahs'
                      ? `(${rangeMin}-${rangeMax})`
                      : repeatMode === 'surah'
                      ? t.repeatAndMemorize
                      : t.listen}
                  </span>
                </button>

                <button
                  onClick={() => toggleDownload(selectedSurah.number)}
                  disabled={isDownloading}
                  className={`flex items-center gap-1 px-2 py-1 rounded-lg border text-xs transition-colors ${
                    isDownloaded
                      ? `${themeStyles.accentSoftBg} ${themeStyles.accentBorder}`
                      : `${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                  }`}
                >
                  {isDownloading ? (
                    <Sparkles className={`w-3.5 h-3.5 animate-spin ${themeStyles.accentText}`} />
                  ) : isDownloaded ? (
                    <CheckCircle2 className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
                  ) : (
                    <Download className="w-3.5 h-3.5" />
                  )}
                  <span>{isDownloaded ? t.downloaded : t.download}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Smart Pause Notice */}
          {pausedBySmartPause === 'mushaf' && (
            <div className="bg-amber-950/70 border-b border-amber-700/50 px-4 py-2 flex items-center justify-center gap-2 text-[11px] text-amber-200">
              <PhoneOff className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>التوقف الذكي نشط: تم إيقاف التلاوة مؤقتاً وسيُستأنف التشغيل بعد انتهاء الحدث</span>
            </div>
          )}
        </>
      )}

      {showTafsirAtTop ? (
        <SurahTafsirPage
          surahs={surahs}
          selectedSurah={selectedSurah}
          activeAyahs={activeAyahs}
          initialAyahNumber={selectedAyahForTafsir}
          selectedReciter={selectedReciter}
          settings={settings}
          fontSize={fontSize}
          themeStyles={themeStyles}
          onChangeSurahIndex={(idx) => {
            setSelectedSurahIndex(idx);
            setCurrentPageIndex(0);
          }}
          onBeforePlayAudio={() => {
            if (isPlayingAudio && audioRef.current) {
              audioRef.current.pause();
              setIsPlayingAudio(false);
              notifyAudioStopped('mushaf');
            }
          }}
          onClose={() => setShowTafsirAtTop(false)}
        />
      ) : (
        <InteractiveMushaf
          selectedSurah={selectedSurah}
          activeAyahs={activeAyahs}
          pageAyahs={pageAyahs}
          currentPageData={currentPageData}
          safePageIndex={safePageIndex}
          totalPages={surahPages.length}
          readingProgress={readingProgress}
          isLoadingSurahText={isLoadingSurahText}
          isAnimatingPage={isAnimatingPage}
          flipDirection={flipDirection}
          isAtFirstPageOfQuran={isAtFirstPageOfQuran}
          isAtLastPageOfQuran={isAtLastPageOfQuran}
          settings={settings}
          themeStyles={themeStyles}
          t={t}
          activeFontClass={activeFontClass}
          activeFontSizeClass={activeFontSizeClass}
          scrollContainerRef={scrollContainerRef}
          isSelectionMode={isSelectionMode}
          setIsSelectionMode={setIsSelectionMode}
          repeatMode={repeatMode}
          onSelectRepeatMode={selectRepeatMode}
          showRepeatPanel={showRepeatPanel}
          setShowRepeatPanel={setShowRepeatPanel}
          repeatRangeStart={repeatRangeStart}
          repeatRangeEnd={repeatRangeEnd}
          setRepeatRangeStart={setRepeatRangeStart}
          setRepeatRangeEnd={setRepeatRangeEnd}
          repeatLimit={repeatLimit}
          setRepeatLimit={setRepeatLimit}
          currentCycle={currentCycle}
          setCurrentCycle={setCurrentCycle}
          currentPlayingAyah={currentPlayingAyah}
          setCurrentPlayingAyah={setCurrentPlayingAyah}
          isContinuingAfterRepeat={isContinuingAfterRepeat}
          isPlayingAudio={isPlayingAudio}
          onStartRangePlayback={startPlayback}
          onTogglePlayAudio={togglePlayAudio}
          showTafsirPanel={showTafsirAtTop}
          setShowTafsirPanel={setShowTafsirAtTop}
          selectedAyahForTafsir={selectedAyahForTafsir}
          onAyahClick={handleAyahClick}
          onNextPage={nextPage}
          onPrevPage={prevPage}
        />
      )}

      {/* Bookmarks Modal */}
      {showBookmarksModal && (
        <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-2xl border ${themeStyles.surfaceBg} ${themeStyles.border} shadow-2xl overflow-hidden flex flex-col max-h-[80vh]`}>
            <div className={`p-4 border-b ${themeStyles.border} flex items-center justify-between`}>
              <div className="flex items-center gap-2">
                <Bookmark className={`w-5 h-5 ${themeStyles.accentText}`} />
                <h3 className={`font-bold text-sm ${themeStyles.textPrimary}`}>العلامات المرجعية المحفوظة</h3>
              </div>
              <button
                onClick={() => setShowBookmarksModal(false)}
                className={`text-xs px-2 py-1 rounded-lg ${themeStyles.subSurfaceBg} ${themeStyles.textSecondary}`}
              >
                إغلاق
              </button>
            </div>

            <div className="p-3 overflow-y-auto space-y-2 flex-1">
              {bookmarks.length === 0 ? (
                <div className="text-center py-8 text-xs text-stone-400">
                  لا توجد علامات مرجعية محفوظة حتى الآن. اضغط على زر حفظ في الأعلى لحفظ موضع قراءتك.
                </div>
              ) : (
                bookmarks.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => jumpToBookmarkItem(item)}
                    className={`p-3 rounded-xl border ${themeStyles.cardBg} ${themeStyles.border} hover:${themeStyles.accentSoftBg} cursor-pointer transition-all flex items-center justify-between group`}
                  >
                    <div className="flex flex-col gap-0.5 min-w-0">
                      <span className={`font-bold text-xs ${themeStyles.textPrimary} truncate`}>
                        {item.surahName}
                      </span>
                      <span className="text-[10px] text-stone-400">
                        {item.title} • {item.createdAt}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full ${themeStyles.accentSoftBg} ${themeStyles.accentText} font-semibold`}>
                        انتقال
                      </span>
                      <button
                        onClick={(e) => deleteBookmarkItem(item.id, e)}
                        className="p-1 rounded-lg hover:bg-red-500/20 text-red-400 opacity-60 group-hover:opacity-100 transition-opacity"
                        title="حذف العلامة"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className={`p-3 border-t ${themeStyles.border} flex justify-between items-center`}>
              <button
                onClick={saveCurrentBookmark}
                className={`w-full py-2 rounded-xl text-xs font-bold ${themeStyles.accentBg} text-white shadow-sm flex items-center justify-center gap-1.5`}
              >
                <Bookmark className="w-4 h-4" />
                <span>حفظ الموضع الحالي كعلامة جديدة</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
