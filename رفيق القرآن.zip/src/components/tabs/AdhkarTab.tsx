import React, { useState, useEffect } from 'react';
import { AppSettings, Dhkar, IstighfarScheduleConfig } from '../../types';
import { fullHisnAlMuslim } from '../../data/adhkarData';
import { RotateCcw, Check, Clock, BellRing, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { ThemeStyles, getFontClass } from '../../utils/theme';
import { Translations } from '../../utils/i18n';
import {
  DEFAULT_DHIKR_OPTIONS,
  getNextIntervalFireAt,
  getNextScheduledSlot,
  getNotificationPermissionState,
  ISTIGHFAR_INAPP_ALERT_EVENT,
  ISTIGHFAR_SCHEDULE_UPDATED_EVENT,
  loadIstighfarSchedule,
  NotificationPermissionState,
  requestNotificationPermission,
  saveIstighfarSchedule,
  scheduleNextInterval,
  sendIstighfarNotification,
  setNextIntervalFireAt,
  unlockReminderAudio,
} from '../../utils/istighfarScheduler';

interface AdhkarTabProps {
  adhkarList: Dhkar[];
  settings: AppSettings;
  themeStyles: ThemeStyles;
  t: Translations;
}

export const AdhkarTab: React.FC<AdhkarTabProps> = ({ settings, themeStyles, t }) => {
  const [activeSubTab, setActiveSubTab] = useState<'adhkar' | 'rosary' | 'timer'>('adhkar');
  const [selectedCategory, setSelectedCategory] = useState<string>('أذكار الصباح');

  // Rosary state
  const [rosaryCount, setRosaryCount] = useState<number>(0);
  const [rosaryTarget] = useState<number>(33);
  const [selectedDhikrType, setSelectedDhikrType] = useState<string>('سُبْحَانَ ٱللَّٰهِ');

  // Istighfar Timer state synced with Settings Notification Scheduler
  const [scheduleConfig, setScheduleConfig] = useState<IstighfarScheduleConfig>(() =>
    loadIstighfarSchedule()
  );
  const [notifPermission, setNotifPermission] = useState<NotificationPermissionState>(() =>
    getNotificationPermissionState()
  );
  const [countdownLabel, setCountdownLabel] = useState<string>('');
  const [testSentFeedback, setTestSentFeedback] = useState<boolean>(false);

  const timerIntervalMinutes = scheduleConfig.intervalMinutes;
  const isTimerActive = scheduleConfig.enabled && scheduleConfig.intervalEnabled;
  const selectedTimerDhikr = scheduleConfig.intervalDhikr;

  const activeFontClass = getFontClass(settings.fontFamily);

  useEffect(() => {
    const syncConfig = (e: Event) => {
      const detail = (e as CustomEvent<IstighfarScheduleConfig>).detail;
      setScheduleConfig(detail || loadIstighfarSchedule());
    };
    const onAlert = () => {
      confetti({
        particleCount: 40,
        spread: 50,
        origin: { y: 0.2 },
      });
    };
    window.addEventListener(ISTIGHFAR_SCHEDULE_UPDATED_EVENT, syncConfig);
    window.addEventListener(ISTIGHFAR_INAPP_ALERT_EVENT, onAlert);
    return () => {
      window.removeEventListener(ISTIGHFAR_SCHEDULE_UPDATED_EVENT, syncConfig);
      window.removeEventListener(ISTIGHFAR_INAPP_ALERT_EVENT, onAlert);
    };
  }, []);

  useEffect(() => {
    if (!isTimerActive) {
      setCountdownLabel('');
      return;
    }

    const updateCountdown = () => {
      const target = getNextIntervalFireAt();
      if (!target) {
        setCountdownLabel('');
        return;
      }
      const remSec = Math.max(0, Math.ceil((target - Date.now()) / 1000));
      const m = Math.floor(remSec / 60);
      const s = remSec % 60;
      setCountdownLabel(`${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`);
    };

    updateCountdown();
    const id = window.setInterval(updateCountdown, 1000);
    return () => window.clearInterval(id);
  }, [isTimerActive, timerIntervalMinutes]);

  const updateSchedule = (updater: (prev: IstighfarScheduleConfig) => IstighfarScheduleConfig) => {
    setScheduleConfig((prev) => {
      const next = updater(prev);
      saveIstighfarSchedule(next);
      return next;
    });
  };

  const toggleIntervalTimer = async () => {
    unlockReminderAudio();
    const nextActive = !isTimerActive;
    if (nextActive) {
      const perm = await requestNotificationPermission();
      setNotifPermission(perm);
      scheduleNextInterval(timerIntervalMinutes);
    } else {
      setNextIntervalFireAt(null);
    }
    updateSchedule((prev) => ({
      ...prev,
      enabled: true,
      intervalEnabled: nextActive,
    }));
  };

  const handleRequestPermission = async () => {
    unlockReminderAudio();
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
  };

  const handleTestIstighfarNotification = async () => {
    unlockReminderAudio();
    if (notifPermission === 'default') {
      const perm = await requestNotificationPermission();
      setNotifPermission(perm);
    }
    sendIstighfarNotification(t.adhkarTabTimer, selectedTimerDhikr);
    setTestSentFeedback(true);
    window.setTimeout(() => setTestSentFeedback(false), 3000);
  };

  const nextScheduled = getNextScheduledSlot(scheduleConfig);

  const categories = Array.from(new Set(fullHisnAlMuslim.map((d) => d.category)));
  const filteredAdhkar = fullHisnAlMuslim.filter((d) => d.category === selectedCategory);

  const incrementRosary = () => {
    const newCount = rosaryCount + 1;
    setRosaryCount(newCount);
    if (newCount === rosaryTarget) {
      confetti({
        particleCount: 50,
        spread: 40,
        origin: { y: 0.7 },
      });
    }
  };

  const resetRosary = () => {
    setRosaryCount(0);
  };

  return (
    <div
      className={`flex flex-col h-full ${themeStyles.phoneBg} font-cairo p-4 overflow-y-auto space-y-4 relative transition-colors duration-300`}
    >
      {/* Sub-tab Switcher */}
      <div className={`flex items-center gap-1 ${themeStyles.cardBg} p-1 rounded-xl border ${themeStyles.border}`}>
        <button
          onClick={() => setActiveSubTab('adhkar')}
          className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
            activeSubTab === 'adhkar'
              ? `${themeStyles.accentBg} shadow-sm`
              : `${themeStyles.textSecondary}`
          }`}
        >
          {t.adhkarTabHisn}
        </button>
        <button
          onClick={() => setActiveSubTab('rosary')}
          className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
            activeSubTab === 'rosary'
              ? `${themeStyles.accentBg} shadow-sm`
              : `${themeStyles.textSecondary}`
          }`}
        >
          {t.adhkarTabRosary}
        </button>
        <button
          onClick={() => setActiveSubTab('timer')}
          className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
            activeSubTab === 'timer'
              ? `${themeStyles.accentBg} shadow-sm`
              : `${themeStyles.textSecondary}`
          }`}
        >
          {t.adhkarTabTimer}
        </button>
      </div>

      {activeSubTab === 'adhkar' ? (
        <div className="space-y-3">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors border ${
                  selectedCategory === cat
                    ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow-md`
                    : `${themeStyles.cardBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="space-y-2.5">
            {filteredAdhkar.map((item) => (
              <div
                key={item.id}
                className={`${themeStyles.cardBg} border ${themeStyles.border} p-3.5 rounded-2xl space-y-2`}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-bold ${themeStyles.accentText}`}>{item.title}</span>
                  <span
                    className={`text-[10px] ${themeStyles.accentSoftBg} px-2 py-0.5 rounded-full border ${themeStyles.accentBorder}`}
                  >
                    التكرار: {item.count}
                  </span>
                </div>
                <p className={`${activeFontClass} text-base ${themeStyles.mushafText} leading-relaxed text-right`}>
                  {item.text}
                </p>
                <div
                  className={`flex justify-between items-center pt-1 border-t ${themeStyles.border} text-[10px] ${themeStyles.textSecondary}`}
                >
                  <span>المصدر: {item.reference}</span>
                  <button className={`${themeStyles.accentText} flex items-center gap-1 font-semibold`}>
                    <Check className="w-3 h-3" /> تم القراءة
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : activeSubTab === 'rosary' ? (
        /* Digital Rosary View */
        <div className="flex flex-col items-center justify-center space-y-6 py-4">
          <div className={`w-full ${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl flex items-center justify-between`}>
            <span className={`text-xs ${themeStyles.textSecondary}`}>الذكر الحالي:</span>
            <select
              value={selectedDhikrType}
              onChange={(e) => setSelectedDhikrType(e.target.value)}
              className={`${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-3 py-1.5 text-xs font-semibold focus:outline-none`}
            >
              <option value="سُبْحَانَ ٱللَّٰهِ">سُبْحَانَ ٱللَّٰهِ</option>
              <option value="ٱلْحَمْدُ لِلَّهِ">ٱلْحَمْدُ لِلَّهِ</option>
              <option value="ٱللَّهُ أَكْبَرُ">ٱللَّهُ أَكْبَرُ</option>
              <option value="لَا إِلهَ إِلَّا ٱللَّهُ">لَا إِلهَ إِلَّا ٱللَّهُ</option>
              <option value="أَسْتَغْفِرُ ٱللَّهَ">أَسْتَغْفِرُ ٱللَّهَ</option>
            </select>
          </div>

          <div className="flex flex-col items-center justify-center py-6">
            <button
              onClick={incrementRosary}
              className={`w-52 h-52 rounded-full ${themeStyles.accentBg} shadow-2xl border-4 ${themeStyles.accentBorder} flex flex-col items-center justify-center transition-transform active:scale-95 group relative`}
            >
              <span className={`text-4xl font-black ${activeFontClass} tracking-wider`}>{rosaryCount}</span>
              <span className="text-xs font-cairo text-white/90 mt-2 font-bold">{selectedDhikrType}</span>
              <span className="text-[10px] text-white/75 mt-1">اضغط للتسبيح</span>
            </button>
          </div>

          <div className={`flex items-center justify-between w-full ${themeStyles.cardBg} p-3 rounded-xl border ${themeStyles.border} text-xs`}>
            <div className="flex items-center gap-2">
              <span className={themeStyles.textSecondary}>الهدف:</span>
              <span className={`font-bold ${themeStyles.accentText}`}>{rosaryTarget} مرة</span>
            </div>
            <button
              onClick={resetRosary}
              className={`flex items-center gap-1 ${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} px-3 py-1.5 rounded-lg border ${themeStyles.border} transition-colors`}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>تصفير العداد</span>
            </button>
          </div>
        </div>
      ) : (
        /* Istighfar Timer View */
        <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-4`}>
          <div className={`flex items-center gap-2 border-b ${themeStyles.border} pb-3`}>
            <Clock className={`w-5 h-5 ${themeStyles.accentText}`} />
            <div>
              <h3 className={`text-xs font-bold ${themeStyles.accentText}`}>مؤقت الاستغفار والتذكير الدوري</h3>
              <p className={`text-[10px] ${themeStyles.textSecondary}`}>
                يظهر لك إشعارات وتنبيهات خفيفة لتذكيرك بذكر الله باستمرار
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="space-y-1">
              <label className={`text-xs ${themeStyles.textSecondary}`}>اختر الذكر المفضل للتذكير:</label>
              <select
                value={selectedTimerDhikr}
                onChange={(e) =>
                  updateSchedule((prev) => ({ ...prev, intervalDhikr: e.target.value }))
                }
                className={`w-full ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none`}
              >
                {DEFAULT_DHIKR_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            {/* Browser / PWA Notification Permission Status */}
            <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl p-2.5 flex items-center justify-between gap-2 flex-wrap`}>
              <div className="flex items-center gap-1.5 text-[11px] min-w-0">
                <ShieldCheck
                  className={`w-4 h-4 shrink-0 ${
                    notifPermission === 'granted'
                      ? 'text-emerald-400'
                      : notifPermission === 'denied'
                      ? 'text-rose-400'
                      : 'text-amber-400'
                  }`}
                />
                <span className={`${themeStyles.textPrimary} font-semibold truncate`}>
                  {notifPermission === 'granted'
                    ? 'إشعارات الجهاز مفعّلة ✓'
                    : notifPermission === 'denied'
                    ? 'الإشعارات محظورة — فعّلها من إعدادات المتصفح'
                    : notifPermission === 'unsupported'
                    ? 'التنبيه الصوتي والمرئي يعمل داخل التطبيق'
                    : 'يلزم السماح بالإشعارات لتظهر في شريط الهاتف'}
                </span>
              </div>
              {notifPermission === 'default' && (
                <button
                  onClick={handleRequestPermission}
                  className={`px-2.5 py-1.5 rounded-lg ${themeStyles.accentBg} text-[10px] font-bold shrink-0`}
                >
                  السماح بالإشعارات
                </button>
              )}
            </div>

            <div className="space-y-1">
              <label className={`text-xs ${themeStyles.textSecondary}`}>الفترة الزمنية للتذكير (بالدقائق):</label>
              <div className="grid grid-cols-4 gap-2">
                {[5, 15, 30, 60].map((mins) => (
                  <button
                    key={mins}
                    onClick={() => {
                      unlockReminderAudio();
                      if (isTimerActive) {
                        scheduleNextInterval(mins);
                      }
                      updateSchedule((prev) => ({ ...prev, intervalMinutes: mins }));
                    }}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      timerIntervalMinutes === mins
                        ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow`
                        : `${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                    }`}
                  >
                    كل {mins} دقائق
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-1 space-y-2">
              <button
                onClick={toggleIntervalTimer}
                className={`w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all ${
                  isTimerActive
                    ? 'bg-red-600 hover:bg-red-500 text-white'
                    : themeStyles.accentBg
                }`}
              >
                <BellRing className="w-4 h-4" />
                <span>{isTimerActive ? 'إيقاف مؤقت الاستغفار' : 'تشغيل وتفعيل مؤقت الاستغفار'}</span>
              </button>

              <button
                onClick={handleTestIstighfarNotification}
                className={`w-full py-2.5 rounded-xl border ${themeStyles.accentBorder} ${themeStyles.accentSoftBg} ${themeStyles.accentText} text-xs font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all`}
              >
                <BellRing className="w-4 h-4" />
                <span>{testSentFeedback ? 'تم إرسال إشعار تجريبي ✓' : 'تجربة إشعار التذكير الآن'}</span>
              </button>
            </div>

            {isTimerActive && (
              <div className={`${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} p-3 rounded-xl text-center text-xs ${themeStyles.accentText} space-y-1`}>
                <div className="font-bold">
                  المؤقت يعمل — تذكير كل {timerIntervalMinutes} دقائق
                </div>
                {countdownLabel && (
                  <div className="text-[11px] font-mono tabular-nums">
                    التذكير القادم خلال: <span dir="ltr" className="font-extrabold">{countdownLabel}</span>
                  </div>
                )}
              </div>
            )}

            {nextScheduled && (
              <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} p-3 rounded-xl flex items-center justify-between gap-2 text-xs`}>
                <span className={`${themeStyles.textSecondary} font-semibold`}>
                  {t.nextReminderLabel}
                </span>
                <span dir="ltr" className={`font-bold ${themeStyles.accentText}`}>
                  {nextScheduled.slot.time}
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
