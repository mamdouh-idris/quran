import React, { useState, useEffect, useMemo } from 'react';
import { AppSettings } from '../../types';
import { muezzinsList } from '../../data/quranData';
import {
  Clock,
  Bell,
  BellOff,
  Compass,
  Smartphone,
  Volume2,
  MapPin,
  Locate,
  Sliders,
  PhoneOff,
  Timer,
  ShieldCheck,
  CheckCircle2,
  Download,
} from 'lucide-react';
import { useSmartPause } from '../../context/SmartPauseContext';
import { ThemeStyles, getFontClass } from '../../utils/theme';
import { Translations } from '../../utils/i18n';
import {
  CITIES_LIST,
  calculatePrayerSchedule,
  getCityLocalDate,
  getNextPrayerCountdown,
  formatMinutesToClock,
} from '../../utils/prayerMath';
import { QiblaCompass } from '../QiblaCompass';
import {
  ADHAN_CACHE_UPDATED_EVENT,
  ADHAN_STATE_EVENT,
  AdhanStateDetail,
  cacheMuezzinAudio,
  dispatchAdhanControl,
  isMuezzinAudioCached,
  loadPrayerPrefs,
  ObligatoryPrayerKey,
  PRAYER_PREFS_UPDATED_EVENT,
  PrayerAdhanPrefs,
  savePrayerPrefs,
} from '../../utils/adhanScheduler';
import {
  getNotificationPermissionState,
  NotificationPermissionState,
  requestNotificationPermission,
  unlockReminderAudio,
} from '../../utils/istighfarScheduler';

interface PrayerTimesTabProps {
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  themeStyles: ThemeStyles;
  t: Translations;
}

const pad2 = (n: number) => String(n).padStart(2, '0');

export const PrayerTimesTab: React.FC<PrayerTimesTabProps> = ({
  settings,
  setSettings,
  themeStyles,
  t,
}) => {
  const [subTab, setSubTab] = useState<'schedule' | 'qibla'>('schedule');
  const [prayerPrefs, setPrayerPrefs] = useState<PrayerAdhanPrefs>(() => loadPrayerPrefs());
  const [adhanState, setAdhanState] = useState<AdhanStateDetail>({
    isPlaying: false,
    usedBackup: false,
  });
  const [notifPermission, setNotifPermission] = useState<NotificationPermissionState>(() =>
    getNotificationPermissionState()
  );

  // Real-time 1-second clock for next prayer countdown
  const [now, setNow] = useState<Date>(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const onPrefsUpdated = (e: Event) => {
      const detail = (e as CustomEvent<PrayerAdhanPrefs>).detail;
      if (detail) setPrayerPrefs(detail);
    };
    const onAdhanState = (e: Event) => {
      const detail = (e as CustomEvent<AdhanStateDetail>).detail;
      if (detail) setAdhanState(detail);
    };
    window.addEventListener(PRAYER_PREFS_UPDATED_EVENT, onPrefsUpdated);
    window.addEventListener(ADHAN_STATE_EVENT, onAdhanState);
    return () => {
      window.removeEventListener(PRAYER_PREFS_UPDATED_EVENT, onPrefsUpdated);
      window.removeEventListener(ADHAN_STATE_EVENT, onAdhanState);
    };
  }, []);

  const updatePrayerPrefs = (updater: (prev: PrayerAdhanPrefs) => PrayerAdhanPrefs) => {
    setPrayerPrefs((prev) => {
      const next = updater(prev);
      savePrayerPrefs(next);
      return next;
    });
  };

  const [isPhoneFlipped, setIsPhoneFlipped] = useState(false);
  const selectedMuezzin =
    muezzinsList.find((m) => m.id === settings.muezzinId) || muezzinsList[0];
  const [isAdhanCachedOffline, setIsAdhanCachedOffline] = useState<boolean>(false);
  const [isSavingAdhanOffline, setIsSavingAdhanOffline] = useState<boolean>(false);

  useEffect(() => {
    let active = true;
    const refreshCacheStatus = () => {
      isMuezzinAudioCached(selectedMuezzin).then((cached) => {
        if (active) setIsAdhanCachedOffline(cached);
      });
    };
    refreshCacheStatus();
    window.addEventListener(ADHAN_CACHE_UPDATED_EVENT, refreshCacheStatus);
    return () => {
      active = false;
      window.removeEventListener(ADHAN_CACHE_UPDATED_EVENT, refreshCacheStatus);
    };
  }, [selectedMuezzin]);

  const { pausedBySmartPause } = useSmartPause();

  const selectedCity =
    CITIES_LIST.find((c) => c.id === prayerPrefs.cityId) || CITIES_LIST[0];
  const gpsCoords = prayerPrefs.gpsCoords;
  const timeOffsetMinutes = prayerPrefs.timeOffsetMinutes;

  const [locationStatus, setLocationStatus] = useState<string>(
    gpsCoords
      ? `تم تحديد الموقع عبر GPS (${gpsCoords.lat.toFixed(2)}°, ${gpsCoords.lng.toFixed(2)}°)`
      : 'تم ضبط الإحداثيات حسب المدينة المختارة'
  );
  const [isLocating, setIsLocating] = useState<boolean>(false);

  const activeLat = gpsCoords ? gpsCoords.lat : selectedCity.lat;
  const activeLng = gpsCoords ? gpsCoords.lng : selectedCity.lng;
  const activeTzOffset = gpsCoords ? -now.getTimezoneOffset() / 60 : selectedCity.tzOffset;

  const cityNow = useMemo(() => getCityLocalDate(now, activeTzOffset), [now, activeTzOffset]);

  const schedule = useMemo(
    () =>
      calculatePrayerSchedule(
        cityNow,
        activeLat,
        activeLng,
        activeTzOffset,
        timeOffsetMinutes,
        settings.language
      ),
    [cityNow, activeLat, activeLng, activeTzOffset, timeOffsetMinutes, settings.language]
  );

  const nextPrayerInfo = useMemo(
    () => getNextPrayerCountdown(schedule, cityNow),
    [schedule, cityNow]
  );

  const currentCityClockStr = useMemo(
    () => formatMinutesToClock(cityNow.getHours() * 60 + cityNow.getMinutes(), settings.language),
    [cityNow, settings.language]
  );

  const requestLocation = () => {
    setIsLocating(true);
    setLocationStatus('جاري تحديد موقعك الجغرافي عبر GPS...');

    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          updatePrayerPrefs((prev) => ({ ...prev, gpsCoords: { lat, lng } }));
          setIsLocating(false);
          setLocationStatus(
            `تم تحديد الموقع بنجاح (${lat.toFixed(2)}°, ${lng.toFixed(2)}°)`
          );
        },
        () => {
          setIsLocating(false);
          setLocationStatus('تعذر الوصول لـ GPS؛ يتم الحساب حسب المدينة المختارة.');
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    } else {
      setIsLocating(false);
      setLocationStatus('خدمة GPS غير متوفرة؛ يتم الحساب حسب المدينة المختارة.');
    }
  };

  const toggleFlipSimulation = () => {
    const newState = !isPhoneFlipped;
    setIsPhoneFlipped(newState);
    if (newState && adhanState.isPlaying) {
      dispatchAdhanControl('stop');
    }
  };

  const testAdhan = () => {
    unlockReminderAudio();
    dispatchAdhanControl('play-test', settings.muezzinId);
  };

  const handleMuezzinChange = (newId: string) => {
    setSettings((prev) => ({ ...prev, muezzinId: newId }));
    if (adhanState.isPlaying) {
      dispatchAdhanControl('switch-muezzin', newId);
    }
  };

  const handleToggleAutoAdhan = async () => {
    unlockReminderAudio();
    const nextEnabled = !prayerPrefs.autoAdhanEnabled;
    updatePrayerPrefs((prev) => ({ ...prev, autoAdhanEnabled: nextEnabled }));
    if (nextEnabled && notifPermission === 'default') {
      const perm = await requestNotificationPermission();
      setNotifPermission(perm);
    }
  };

  const handleEnableNotifPermission = async () => {
    unlockReminderAudio();
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
  };

  const activeFontClass = getFontClass(settings.fontFamily);
  const isArabicLike = settings.language === 'ar' || settings.language === 'ur';

  const formatCountdownWords = (h: number, m: number, s: number) => {
    if (settings.language === 'ar') {
      const parts: string[] = [];
      if (h > 0) parts.push(`${h} ساعة`);
      if (m > 0 || h > 0) parts.push(`${m} دقيقة`);
      parts.push(`${s} ثانية`);
      return `متبقي ${parts.join(' و ')}`;
    }
    if (settings.language === 'ur') {
      return `${h} گھنٹے ${m} منٹ ${s} سیکنڈ باقی`;
    }
    if (settings.language === 'fr') {
      return `Dans ${h}h ${m}m ${s}s`;
    }
    return `In ${h}h ${m}m ${s}s`;
  };

  return (
    <div
      className={`flex flex-col h-full ${themeStyles.phoneBg} font-cairo p-4 overflow-y-auto space-y-4 transition-colors duration-300`}
    >
      {/* Segmented Switcher: Prayer Times vs Qibla */}
      <div className={`grid grid-cols-2 gap-1.5 p-1 rounded-2xl ${themeStyles.subSurfaceBg} border ${themeStyles.border}`}>
        <button
          onClick={() => setSubTab('schedule')}
          className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all min-h-[40px] ${
            subTab === 'schedule'
              ? `${themeStyles.accentBg} shadow-md`
              : `${themeStyles.textSecondary} hover:opacity-80`
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>{t.prayerScheduleTab}</span>
        </button>
        <button
          onClick={() => setSubTab('qibla')}
          className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all min-h-[40px] ${
            subTab === 'qibla'
              ? `${themeStyles.accentBg} shadow-md`
              : `${themeStyles.textSecondary} hover:opacity-80`
          }`}
        >
          <Compass className="w-3.5 h-3.5" />
          <span>{t.qiblaTitle}</span>
        </button>
      </div>

      {subTab === 'qibla' ? (
        <QiblaCompass
          lat={activeLat}
          lng={activeLng}
          locationLabel={gpsCoords ? 'GPS' : selectedCity.name}
          locationStatus={locationStatus}
          isLocating={isLocating}
          onRequestGps={requestLocation}
          onBackToSchedule={() => setSubTab('schedule')}
          language={settings.language}
          themeStyles={themeStyles}
          t={t}
        />
      ) : (
        <>
          {/* Next Prayer Countdown Hero Card */}
          <div
            className={`${themeStyles.accentSoftBg} p-4 rounded-2xl border ${themeStyles.accentBorder} shadow-lg space-y-3`}
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className={`flex items-center gap-1.5 text-[11px] font-bold ${themeStyles.accentText}`}>
                  <Timer className="w-3.5 h-3.5" />
                  <span>{t.nextPrayerLabel}</span>
                </div>
                <h2 className={`text-lg font-bold font-amiri ${themeStyles.textPrimary} mt-0.5`}>
                  {isArabicLike
                    ? `صلاة ${nextPrayerInfo.nextPrayer.arabicName}`
                    : nextPrayerInfo.nextPrayer.englishName}
                </h2>
                <p className={`text-[11px] ${themeStyles.textSecondary}`}>
                  {nextPrayerInfo.nextPrayer.formattedTime} · {t.cityClockLabel}: {currentCityClockStr}
                </p>
              </div>

              <div className="text-left" dir="ltr">
                <span className={`text-[10px] block ${themeStyles.textSecondary} text-right`}>
                  {t.remainingLabel}
                </span>
                <div className={`text-2xl font-extrabold font-mono tabular-nums tracking-tight ${themeStyles.accentText}`}>
                  {pad2(nextPrayerInfo.hoursLeft)}:{pad2(nextPrayerInfo.minutesLeft)}:{pad2(nextPrayerInfo.secondsLeft)}
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="w-full h-2 bg-black/15 dark:bg-white/10 rounded-full overflow-hidden">
                <div
                  className={`h-full ${themeStyles.progressBarBg} transition-all duration-500`}
                  style={{ width: `${nextPrayerInfo.progressPercent}%` }}
                />
              </div>
              <div className={`flex items-center justify-between text-[11px] ${themeStyles.textSecondary}`}>
                <span className={`font-semibold ${themeStyles.textPrimary}`}>
                  {formatCountdownWords(
                    nextPrayerInfo.hoursLeft,
                    nextPrayerInfo.minutesLeft,
                    nextPrayerInfo.secondsLeft
                  )}
                </span>
                <button
                  onClick={() => setSubTab('qibla')}
                  className={`font-bold ${themeStyles.accentText} flex items-center gap-1 hover:underline`}
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>{t.qiblaTitle}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Region & City Selector + Offset */}
          <div className={`${themeStyles.cardBg} p-3.5 rounded-2xl border ${themeStyles.border} space-y-3`}>
            <div className="flex items-center justify-between gap-2">
              <div className={`flex items-center gap-1.5 text-xs ${themeStyles.accentText}`}>
                <MapPin className="w-4 h-4 shrink-0" />
                <span>{t.prayerRegion}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <select
                  value={selectedCity.id}
                  onChange={(e) => {
                    const c = CITIES_LIST.find((item) => item.id === e.target.value);
                    if (c) {
                      updatePrayerPrefs((prev) => ({
                        ...prev,
                        cityId: c.id,
                        gpsCoords: null,
                      }));
                      setLocationStatus(`تم الضبط على ${c.name}`);
                    }
                  }}
                  className={`${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-2.5 py-1.5 text-xs font-semibold focus:outline-none`}
                >
                  {CITIES_LIST.map((city) => (
                    <option key={city.id} value={city.id}>
                      {isArabicLike ? city.name : city.englishName}
                    </option>
                  ))}
                </select>
                <button
                  onClick={requestLocation}
                  disabled={isLocating}
                  className={`p-1.5 rounded-xl ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.border}`}
                  title={t.enableGps}
                >
                  <Locate className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>

            {/* Time Adjust Offset Slider (+/- minutes) */}
            <div className={`${themeStyles.subSurfaceBg} p-3 rounded-xl border ${themeStyles.border} space-y-1.5`}>
              <div className={`flex justify-between text-xs ${themeStyles.textPrimary}`}>
                <span className="flex items-center gap-1">
                  <Sliders className={`w-3.5 h-3.5 ${themeStyles.accentText}`} /> {t.prayerTimeOffset}
                </span>
                <span className={`${themeStyles.accentText} font-bold tabular-nums`}>
                  {timeOffsetMinutes > 0 ? `+${timeOffsetMinutes}` : timeOffsetMinutes} min
                </span>
              </div>
              <input
                type="range"
                min="-30"
                max="30"
                step="1"
                value={timeOffsetMinutes}
                onChange={(e) =>
                  updatePrayerPrefs((prev) => ({
                    ...prev,
                    timeOffsetMinutes: Number(e.target.value),
                  }))
                }
                className="w-full accent-emerald-500 rounded-lg cursor-pointer"
              />
            </div>
          </div>

          {/* Prayer Times List with per-prayer Adhan bell toggles */}
          <div className={`${themeStyles.cardBg} rounded-2xl border ${themeStyles.border} p-3 space-y-2`}>
            <h3 className={`text-xs font-bold ${themeStyles.accentText} px-1 pb-1 border-b ${themeStyles.border} flex items-center justify-between`}>
              <span>
                {t.prayerTimesTitle} ({gpsCoords ? 'GPS' : isArabicLike ? selectedCity.name : selectedCity.englishName})
              </span>
              <Clock className="w-3.5 h-3.5" />
            </h3>

            <div className="space-y-1.5">
              {schedule.map((p) => {
                const isNext = p.key === nextPrayerInfo.nextPrayer.key;
                const bellEnabled = p.isObligatory
                  ? prayerPrefs.autoAdhanEnabled &&
                    prayerPrefs.enabledPrayers[p.key as ObligatoryPrayerKey]
                  : false;

                return (
                  <div
                    key={p.key}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-xl border transition-colors ${
                      isNext
                        ? `${themeStyles.accentSoftBg} ${themeStyles.accentBorder}`
                        : `${themeStyles.subSurfaceBg} ${themeStyles.border}`
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold ${isNext ? themeStyles.accentText : themeStyles.textPrimary}`}>
                        {isArabicLike ? p.arabicName : p.englishName}
                      </span>
                      {isNext && (
                        <span className={`text-[10px] font-semibold ${themeStyles.accentText} tabular-nums`}>
                          · {pad2(nextPrayerInfo.hoursLeft)}:{pad2(nextPrayerInfo.minutesLeft)}:{pad2(nextPrayerInfo.secondsLeft)}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2.5">
                      <span className={`text-xs ${activeFontClass} ${themeStyles.accentText} font-bold tabular-nums`}>
                        {p.formattedTime}
                      </span>
                      {p.isObligatory && (
                        <button
                          onClick={() => {
                            const key = p.key as ObligatoryPrayerKey;
                            updatePrayerPrefs((prev) => ({
                              ...prev,
                              autoAdhanEnabled: true,
                              enabledPrayers: {
                                ...prev.enabledPrayers,
                                [key]: !prev.enabledPrayers[key],
                              },
                            }));
                          }}
                          className={`p-1.5 rounded-lg border transition-colors ${
                            bellEnabled
                              ? `${themeStyles.accentSoftBg} ${themeStyles.accentBorder} ${themeStyles.accentText}`
                              : `${themeStyles.cardBg} ${themeStyles.border} ${themeStyles.textSecondary} opacity-60`
                          }`}
                          aria-label={bellEnabled ? 'إيقاف أذان هذه الصلاة' : 'تفعيل أذان هذه الصلاة'}
                        >
                          {bellEnabled ? (
                            <Bell className="w-3.5 h-3.5" />
                          ) : (
                            <BellOff className="w-3.5 h-3.5" />
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Adhan Settings & Muezzins */}
          <div className={`${themeStyles.cardBg} rounded-2xl border ${themeStyles.border} p-4 space-y-3`}>
            <h3 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5`}>
              <Volume2 className="w-4 h-4" />
              <span>{t.muezzinSection}</span>
            </h3>

            {/* Auto-Adhan Master Toggle */}
            <div className={`flex items-center justify-between ${themeStyles.subSurfaceBg} p-3 rounded-xl border ${themeStyles.border}`}>
              <div>
                <span className={`text-xs font-bold ${themeStyles.textPrimary} block`}>
                  الأذان التلقائي عند دخول الوقت
                </span>
                <span className={`text-[10px] ${themeStyles.textSecondary}`}>
                  تشغيل صوت المؤذن وإرسال تنبيه عند حلول الصلاة
                </span>
              </div>
              <button
                onClick={handleToggleAutoAdhan}
                className={`w-11 h-6 rounded-full transition-colors relative p-1 shrink-0 ${
                  prayerPrefs.autoAdhanEnabled ? themeStyles.progressBarBg : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    prayerPrefs.autoAdhanEnabled ? 'translate-x-0' : '-translate-x-5'
                  }`}
                ></div>
              </button>
            </div>

            {/* Notification Permission Status for Adhan */}
            <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl p-2.5 flex items-center justify-between gap-2 flex-wrap`}>
              <div className="flex items-center gap-1.5 text-[11px] min-w-0">
                <ShieldCheck
                  className={`w-4 h-4 shrink-0 ${
                    notifPermission === 'granted'
                      ? 'text-emerald-400'
                      : notifPermission === 'denied'
                      ? 'text-rose-400'
                      : 'text-amber-400'
                  }`}
                />
                <span className={`${themeStyles.textPrimary} font-semibold truncate`}>
                  {notifPermission === 'granted'
                    ? 'إشعارات الأذان مفعّلة ✓'
                    : notifPermission === 'denied'
                    ? 'إذن الإشعارات مرفوض من إعدادات المتصفح'
                    : notifPermission === 'unsupported'
                    ? 'المتصفح يدعم التنبيه داخل التطبيق'
                    : 'فعّل إذن الإشعارات ليظهر تنبيه الأذان'}
                </span>
              </div>
              {notifPermission === 'default' && (
                <button
                  onClick={handleEnableNotifPermission}
                  className={`px-2.5 py-1.5 rounded-lg ${themeStyles.accentBg} text-[10px] font-bold shrink-0`}
                >
                  تفعيل الإشعارات
                </button>
              )}
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className={`text-xs ${themeStyles.textSecondary}`}>{t.chooseMuezzin}</label>
                <span className={`text-[10px] font-bold ${themeStyles.accentText} tabular-nums`}>
                  {muezzinsList.length}
                </span>
              </div>
              <select
                value={settings.muezzinId}
                onChange={(e) => handleMuezzinChange(e.target.value)}
                className={`w-full ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none`}
              >
                {muezzinsList.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>

              <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl px-3 py-2 flex items-center justify-between gap-2`}>
                <div className="flex items-center gap-1.5 text-[11px] min-w-0">
                  {isAdhanCachedOffline ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <Download className={`w-3.5 h-3.5 ${themeStyles.accentText} shrink-0`} />
                  )}
                  <span className={`${themeStyles.textPrimary} truncate`}>
                    {isAdhanCachedOffline
                      ? 'صوت الأذان محفوظ ويعمل بدون إنترنت ✓'
                      : 'يُحفظ صوت الأذان تلقائياً عند الاستماع للعمل بدون إنترنت'}
                  </span>
                </div>
                {!isAdhanCachedOffline && (
                  <button
                    onClick={async () => {
                      if (isSavingAdhanOffline) return;
                      setIsSavingAdhanOffline(true);
                      const ok = await cacheMuezzinAudio(selectedMuezzin);
                      setIsAdhanCachedOffline(ok);
                      setIsSavingAdhanOffline(false);
                    }}
                    disabled={isSavingAdhanOffline}
                    className={`px-2 py-1 rounded-lg ${themeStyles.accentBg} text-[10px] font-bold shrink-0`}
                  >
                    {isSavingAdhanOffline ? 'جاري الحفظ...' : 'حفظ الآن'}
                  </button>
                )}
              </div>
            </div>

            <div className={`flex items-center justify-between ${themeStyles.subSurfaceBg} p-3 rounded-xl border ${themeStyles.border}`}>
              <div>
                <span className={`text-xs font-semibold ${themeStyles.textPrimary} block`}>
                  {t.shortAdhanTitle}
                </span>
              </div>
              <button
                onClick={() => setSettings((prev) => ({ ...prev, shortAdhan: !prev.shortAdhan }))}
                className={`w-11 h-6 rounded-full transition-colors relative p-1 ${
                  settings.shortAdhan ? themeStyles.progressBarBg : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    settings.shortAdhan ? 'translate-x-0' : '-translate-x-5'
                  }`}
                ></div>
              </button>
            </div>

            <div className={`${themeStyles.subSurfaceBg} p-3 rounded-xl border ${themeStyles.border} space-y-2`}>
              <div className="flex items-center justify-between">
                <div>
                  <span className={`text-xs font-semibold ${themeStyles.textPrimary} block`}>
                    {t.flipMuteTitle}
                  </span>
                </div>
                <button
                  onClick={() =>
                    setSettings((prev) => ({ ...prev, flipMuteEnabled: !prev.flipMuteEnabled }))
                  }
                  className={`w-11 h-6 rounded-full transition-colors relative p-1 ${
                    settings.flipMuteEnabled ? themeStyles.progressBarBg : 'bg-slate-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-transform ${
                      settings.flipMuteEnabled ? 'translate-x-0' : '-translate-x-5'
                    }`}
                  ></div>
                </button>
              </div>

              <div className={`pt-2 border-t ${themeStyles.border} flex items-center justify-between gap-2`}>
                <button
                  onClick={toggleFlipSimulation}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors border ${
                    isPhoneFlipped
                      ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                      : `${themeStyles.cardBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5 inline ml-1" />
                  <span>{isPhoneFlipped ? 'تم الكتم بالقلب' : t.flipMuteTitle}</span>
                </button>

                <button
                  onClick={testAdhan}
                  className={`px-3 py-1.5 ${themeStyles.accentBg} rounded-lg text-xs font-bold transition-colors shadow-md`}
                >
                  {adhanState.isPlaying ? t.stopAdhanBtn : t.testAdhanBtn}
                </button>
              </div>

              {pausedBySmartPause === 'adhan' && (
                <div className="bg-amber-950/60 border border-amber-700/50 p-2 rounded-xl text-[11px] text-amber-200 flex items-center justify-center gap-1.5">
                  <PhoneOff className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{t.smartPauseTitle}</span>
                </div>
              )}

              {adhanState.isPlaying && (
                <div className={`text-[11px] ${themeStyles.accentText} font-semibold text-center pt-1`}>
                  🔊 يعمل الآن: {selectedMuezzin.name}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
