import React, { useCallback, useEffect, useState } from 'react';
import { AppSettings, Reciter, Surah } from '../../types';
import {
  Settings,
  Type,
  Palette,
  Info,
  Moon,
  Check,
  Download,
  CheckCircle2,
  Hand,
  BookOpen,
  PhoneOff,
  Phone,
  Heart,
  Sparkles,
  Globe,
  HardDrive,
  ChevronLeft,
  ChevronRight,
  BellRing,
  Clock,
  Plus,
  Trash2,
  ShieldCheck,
  PhoneIncoming,
} from 'lucide-react';
import { useSmartPause } from '../../context/SmartPauseContext';
import {
  ThemeStyles,
  THEME_OPTIONS,
  ACCENT_OPTIONS,
  FONT_OPTIONS,
  getFontClass,
  getFontSizeClass,
} from '../../utils/theme';
import { getDirection, LANGUAGE_OPTIONS, Translations } from '../../utils/i18n';
import { StorageManagerScreen } from '../StorageManagerScreen';
import {
  downloadSurahForOffline,
  formatBytes,
  getStorageSummary,
  initializeStorageIfNeeded,
  STORAGE_UPDATED_EVENT,
} from '../../utils/storageManager';
import {
  DEFAULT_DHIKR_OPTIONS,
  getNextScheduledSlot,
  getNotificationPermissionState,
  ISTIGHFAR_SCHEDULE_UPDATED_EVENT,
  loadIstighfarSchedule,
  NotificationPermissionState,
  requestNotificationPermission,
  saveIstighfarSchedule,
  scheduleNextInterval,
  sendIstighfarNotification,
  setNextIntervalFireAt,
  unlockReminderAudio,
} from '../../utils/istighfarScheduler';
import { IstighfarScheduleConfig } from '../../types';

interface SettingsTabProps {
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  reciters: Reciter[];
  surahs: Surah[];
  themeStyles: ThemeStyles;
  t: Translations;
}

const FONT_PREVIEW_SAMPLES = [
  'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
  'قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ',
  'إِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ فَإِذَا فَرَغْتَ فَانْصَبْ',
];

export const SettingsTab: React.FC<SettingsTabProps> = ({
  settings,
  setSettings,
  reciters,
  surahs,
  themeStyles,
  t,
}) => {
  const [selectedDownloadReciter, setSelectedDownloadReciter] = useState<string>(reciters[0].id);
  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [downloadComplete, setDownloadComplete] = useState<boolean>(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [showStorageScreen, setShowStorageScreen] = useState(false);
  const [storageStats, setStorageStats] = useState<{ count: number; totalBytes: number }>({
    count: 0,
    totalBytes: 0,
  });
  const [previewSampleIndex, setPreviewSampleIndex] = useState<number>(0);
  const [istighfarConfig, setIstighfarConfig] = useState<IstighfarScheduleConfig>(() =>
    loadIstighfarSchedule()
  );
  const [notifPermission, setNotifPermission] = useState<NotificationPermissionState>(() =>
    getNotificationPermissionState()
  );
  const [newReminderTime, setNewReminderTime] = useState<string>('12:30');
  const [newReminderDhikr, setNewReminderDhikr] = useState<string>(DEFAULT_DHIKR_OPTIONS[0]);
  const [testNotifFeedback, setTestNotifFeedback] = useState<boolean>(false);

  const isRtl = getDirection(settings.language) === 'rtl';
  const { activeInterruption, triggerInterruption, endInterruption } = useSmartPause();

  useEffect(() => {
    const syncSchedule = (e: Event) => {
      const detail = (e as CustomEvent<IstighfarScheduleConfig>).detail;
      setIstighfarConfig(detail || loadIstighfarSchedule());
    };
    window.addEventListener(ISTIGHFAR_SCHEDULE_UPDATED_EVENT, syncSchedule);
    return () => window.removeEventListener(ISTIGHFAR_SCHEDULE_UPDATED_EVENT, syncSchedule);
  }, []);

  const updateIstighfarConfig = (updater: (prev: IstighfarScheduleConfig) => IstighfarScheduleConfig) => {
    setIstighfarConfig((prev) => {
      const next = updater(prev);
      saveIstighfarSchedule(next);
      return next;
    });
  };

  const handleRequestNotifPermission = async () => {
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
  };

  const handleAddReminderSlot = () => {
    if (!newReminderTime) return;
    const cleanDhikr = newReminderDhikr.trim() || DEFAULT_DHIKR_OPTIONS[0];
    updateIstighfarConfig((prev) => ({
      ...prev,
      enabled: true,
      scheduledSlots: [
        ...prev.scheduledSlots,
        {
          id: `slot-${Date.now()}`,
          time: newReminderTime,
          dhikr: cleanDhikr,
          enabled: true,
        },
      ].sort((a, b) => a.time.localeCompare(b.time)),
    }));
  };

  const handleTestNotification = async () => {
    if (notifPermission === 'default') {
      const perm = await requestNotificationPermission();
      setNotifPermission(perm);
    }
    const sampleSlot = istighfarConfig.scheduledSlots.find((s) => s.enabled);
    sendIstighfarNotification(
      t.adhkarTabTimer,
      sampleSlot?.dhikr || istighfarConfig.intervalDhikr
    );
    setTestNotifFeedback(true);
    setTimeout(() => setTestNotifFeedback(false), 3500);
  };

  const nextReminderInfo = getNextScheduledSlot(istighfarConfig);

  const refreshStorageStats = useCallback(async () => {
    initializeStorageIfNeeded(reciters[0]);
    const summary = await getStorageSummary();
    setStorageStats({
      count: summary.offlineAudio.length,
      totalBytes: summary.totalAppBytes,
    });
  }, [reciters]);

  useEffect(() => {
    refreshStorageStats();
    const handler = () => {
      refreshStorageStats();
    };
    window.addEventListener(STORAGE_UPDATED_EVENT, handler);
    return () => window.removeEventListener(STORAGE_UPDATED_EVENT, handler);
  }, [refreshStorageStats]);

  const startDownloadingFullQuran = async () => {
    const reciter = reciters.find((r) => r.id === selectedDownloadReciter) || reciters[0];
    setDownloadProgress(0);
    setDownloadComplete(false);

    const total = surahs.length;
    const batchSize = 4;
    for (let i = 0; i < total; i += batchSize) {
      const batch = surahs.slice(i, i + batchSize);
      await Promise.all(batch.map((s) => downloadSurahForOffline(s, reciter)));
      const completed = Math.min(total, i + batch.length);
      setDownloadProgress(Math.round((completed / total) * 100));
    }

    setDownloadProgress(null);
    setDownloadComplete(true);
    await refreshStorageStats();
  };

  const activeFontClass = getFontClass(settings.fontFamily);
  const activeFontSizeClass = getFontSizeClass(settings.fontSize);

  if (showStorageScreen) {
    return (
      <StorageManagerScreen
        onBack={() => setShowStorageScreen(false)}
        surahs={surahs}
        reciters={reciters}
        language={settings.language}
        themeStyles={themeStyles}
        t={t}
      />
    );
  }

  return (
    <div
      className={`flex flex-col h-full ${themeStyles.phoneBg} font-cairo p-4 overflow-y-auto space-y-4 transition-colors duration-300`}
    >
      {/* Header Banner */}
      <div
        className={`${themeStyles.accentSoftBg} p-4 rounded-2xl border ${themeStyles.accentBorder} flex items-center justify-between`}
      >
        <div>
          <h2 className={`text-sm font-bold ${themeStyles.accentText} font-amiri`}>
            {t.settingsTitle}
          </h2>
          <p className={`text-[10px] ${themeStyles.textSecondary} mt-0.5`}>
            {t.settingsSubtitle}
          </p>
        </div>
        <div className={`w-11 h-11 rounded-xl overflow-hidden border ${themeStyles.accentBorder} shadow-md shrink-0`}>
          <img
            src="/pwa-192x192.png"
            alt={t.appName}
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Multi-Language Selector */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
        <h3 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5 border-b ${themeStyles.border} pb-2`}>
          <Globe className="w-4 h-4" />
          <span>{t.languageSectionTitle}</span>
        </h3>

        <p className={`text-[11px] ${themeStyles.textSecondary}`}>{t.languageLabel}</p>

        <div className="grid grid-cols-2 gap-2">
          {LANGUAGE_OPTIONS.map((lang) => {
            const isSelected = settings.language === lang.id;
            return (
              <button
                key={lang.id}
                onClick={() => setSettings((prev) => ({ ...prev, language: lang.id }))}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-between gap-2 ${
                  isSelected
                    ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow-md`
                    : `${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} ${themeStyles.border} hover:opacity-90`
                }`}
              >
                <span>{lang.nativeName}</span>
                {isSelected && <Check className="w-3.5 h-3.5 shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* App Themes & Colors (Expanded) */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-4`}>
        <h3 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5 border-b ${themeStyles.border} pb-2`}>
          <Palette className="w-4 h-4" />
          <span>{t.themesSectionTitle}</span>
        </h3>

        <div className="space-y-2">
          <span className={`text-[11px] font-semibold ${themeStyles.textSecondary} block`}>
            {t.chooseTheme}
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {THEME_OPTIONS.map((thm) => {
              const isSelected = settings.theme === thm.id && !settings.readingMode;
              return (
                <button
                  key={thm.id}
                  onClick={() =>
                    setSettings((prev) => ({
                      ...prev,
                      theme: thm.id,
                      readingMode: false,
                    }))
                  }
                  className={`p-2.5 rounded-xl text-[11px] font-bold border transition-all flex items-center justify-between gap-1 ${thm.previewClass} ${
                    isSelected ? `ring-2 ${themeStyles.accentRing} shadow-lg scale-[1.02]` : 'opacity-85 hover:opacity-100'
                  }`}
                >
                  <span>{thm.name}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Accent Color Picker */}
        <div className="space-y-2 pt-1">
          <span className={`text-[11px] font-semibold ${themeStyles.textSecondary} block`}>
            {t.accentLabel}
          </span>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {ACCENT_OPTIONS.map((acc) => {
              const isSelected = settings.accentColor === acc.id;
              return (
                <button
                  key={acc.id}
                  onClick={() => setSettings((prev) => ({ ...prev, accentColor: acc.id }))}
                  className={`py-2 px-2 rounded-xl text-[11px] font-bold border flex items-center justify-center gap-1.5 transition-all ${
                    isSelected
                      ? `${themeStyles.accentSoftBg} ${themeStyles.accentBorder} ring-2 ${themeStyles.accentRing}`
                      : `${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                  }`}
                >
                  <span className={`w-3 h-3 rounded-full ${acc.swatchClass} shrink-0`}></span>
                  <span>{acc.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Expanded Font & Live Font Tester Section */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-4`}>
        <h3 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5 border-b ${themeStyles.border} pb-2`}>
          <Type className="w-4 h-4" />
          <span>{t.fontsSectionTitle}</span>
        </h3>

        {/* Live Font Tester Box */}
        <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.accentBorder} rounded-2xl p-3.5 space-y-2.5`}>
          <div className="flex items-center justify-between">
            <span className={`text-[11px] font-bold ${themeStyles.accentText} flex items-center gap-1`}>
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t.liveFontPreview}</span>
            </span>
            <button
              onClick={() =>
                setPreviewSampleIndex((prev) => (prev + 1) % FONT_PREVIEW_SAMPLES.length)
              }
              className={`text-[10px] px-2 py-0.5 rounded-lg border ${themeStyles.cardBg} ${themeStyles.textSecondary} ${themeStyles.border}`}
            >
              {t.changeSampleAyah}
            </button>
          </div>
          <p
            dir="rtl"
            className={`${activeFontClass} ${activeFontSizeClass} ${themeStyles.mushafText} text-center leading-loose py-2 transition-all`}
          >
            {FONT_PREVIEW_SAMPLES[previewSampleIndex]}
          </p>
        </div>

        {/* Font Selector Cards */}
        <div className="grid grid-cols-2 gap-2">
          {FONT_OPTIONS.map((font) => {
            const isSelected = settings.fontFamily === font.id;
            const isFeatured = font.id === 'Amiri Quran';
            return (
              <button
                key={font.id}
                onClick={() => setSettings((prev) => ({ ...prev, fontFamily: font.id }))}
                className={`${isFeatured ? 'col-span-2' : ''} p-2.5 rounded-xl border text-right transition-all flex flex-col gap-0.5 ${
                  isSelected
                    ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow-md`
                    : `${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} ${themeStyles.border} hover:opacity-90`
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-sm font-bold ${font.className}`}>{font.name}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 shrink-0" />}
                </div>
                <span className={`text-[10px] ${isSelected ? 'text-white/85' : themeStyles.textSecondary}`}>
                  {font.description}
                </span>
                <span dir="rtl" className={`text-xs ${font.className} mt-0.5 opacity-90`}>
                  بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                </span>
              </button>
            );
          })}
        </div>

        {/* Font Size Slider */}
        <div className="space-y-1.5 pt-1">
          <div className={`flex justify-between text-xs ${themeStyles.textSecondary}`}>
            <span>{t.fontSizeLabel}</span>
            <span className={`${themeStyles.accentText} font-bold`}>{settings.fontSize} px</span>
          </div>
          <input
            type="range"
            min="18"
            max="36"
            step="2"
            value={settings.fontSize}
            onChange={(e) => setSettings((prev) => ({ ...prev, fontSize: Number(e.target.value) }))}
            className="w-full accent-emerald-500 rounded-lg cursor-pointer"
          />
        </div>
      </div>

      {/* Smart Pause Toggle */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl ${themeStyles.accentSoftBg} flex items-center justify-center border ${themeStyles.accentBorder} shrink-0`}>
              <PhoneOff className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`text-xs font-bold ${themeStyles.accentText}`}>{t.smartPauseTitle}</h3>
              <p className={`text-[10px] ${themeStyles.textSecondary} leading-relaxed`}>
                {t.smartPauseDesc}
              </p>
            </div>
          </div>
          <button
            onClick={() => setSettings((prev) => ({ ...prev, smartPauseEnabled: !prev.smartPauseEnabled }))}
            className={`w-11 h-6 rounded-full transition-colors relative p-1 shrink-0 ${
              settings.smartPauseEnabled ? themeStyles.progressBarBg : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform ${
                settings.smartPauseEnabled ? 'translate-x-0' : '-translate-x-5'
              }`}
            ></div>
          </button>
        </div>

        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={() =>
              activeInterruption?.type === 'call'
                ? endInterruption()
                : triggerInterruption('call')
            }
            className={`flex-1 py-2 px-3 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors ${
              activeInterruption?.type === 'call'
                ? 'bg-red-600/20 border-red-500/50 text-red-400'
                : `${themeStyles.subSurfaceBg} ${themeStyles.border} ${themeStyles.textPrimary}`
            }`}
          >
            <PhoneIncoming className="w-3.5 h-3.5 shrink-0" />
            <span>{activeInterruption?.type === 'call' ? t.endCall : t.simCall}</span>
          </button>
          <button
            onClick={() => triggerInterruption('notification')}
            className={`flex-1 py-2 px-3 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1.5 ${themeStyles.subSurfaceBg} ${themeStyles.border} ${themeStyles.textPrimary}`}
          >
            <BellRing className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>{t.simAlert}</span>
          </button>
        </div>
      </div>

      {/* Page Flip 3D Animation Toggle */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`w-9 h-9 rounded-xl ${themeStyles.accentSoftBg} flex items-center justify-center border ${themeStyles.accentBorder}`}>
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`text-xs font-bold ${themeStyles.accentText}`}>{t.pageFlipTitle}</h3>
              <p className={`text-[10px] ${themeStyles.textSecondary}`}>{t.pageFlipDesc}</p>
            </div>
          </div>
          <button
            onClick={() => setSettings((prev) => ({ ...prev, pageFlipAnimation: !prev.pageFlipAnimation }))}
            className={`w-11 h-6 rounded-full transition-colors relative p-1 ${
              settings.pageFlipAnimation ? themeStyles.progressBarBg : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform ${
                settings.pageFlipAnimation ? 'translate-x-0' : '-translate-x-5'
              }`}
            ></div>
          </button>
        </div>
      </div>

      {/* Page Turning Mode (Swipe vs Buttons) */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
        <h3 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5 border-b ${themeStyles.border} pb-2`}>
          <Hand className="w-4 h-4" />
          <span>{t.navModeTitle}</span>
        </h3>

        <div className="grid grid-cols-2 gap-2">
          {[
            { id: 'swipe', name: t.navModeSwipe },
            { id: 'buttons', name: t.navModeButtons },
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setSettings((prev) => ({ ...prev, navigationMode: mode.id as 'swipe' | 'buttons' }))}
              className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-2 ${
                settings.navigationMode === mode.id
                  ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow-md`
                  : `${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} ${themeStyles.border}`
              }`}
            >
              <span>{mode.name}</span>
              {settings.navigationMode === mode.id && <Check className="w-3.5 h-3.5" />}
            </button>
          ))}
        </div>
      </div>

      {/* Comfortable Reading Mode Toggle */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Moon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-amber-400">{t.readingModeTitle}</h3>
              <p className={`text-[10px] ${themeStyles.textSecondary}`}>{t.readingModeDesc}</p>
            </div>
          </div>
          <button
            onClick={() => setSettings((prev) => ({ ...prev, readingMode: !prev.readingMode }))}
            className={`w-11 h-6 rounded-full transition-colors relative p-1 ${
              settings.readingMode ? 'bg-amber-600' : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform ${
                settings.readingMode ? 'translate-x-0' : '-translate-x-5'
              }`}
            ></div>
          </button>
        </div>
      </div>

      {/* Offline Reciter Download Manager */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
        <h3 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5 border-b ${themeStyles.border} pb-2`}>
          <Download className="w-4 h-4" />
          <span>{t.offlineTitle} ({surahs.length})</span>
        </h3>

        <div className="space-y-2">
          <label className={`text-xs ${themeStyles.textSecondary}`}>{t.offlineLabel}</label>
          <select
            value={selectedDownloadReciter}
            onChange={(e) => setSelectedDownloadReciter(e.target.value)}
            className={`w-full ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none`}
          >
            {reciters.map((rec) => (
              <option key={rec.id} value={rec.id}>
                {rec.name} ({rec.style})
              </option>
            ))}
          </select>

          <div className="pt-2 flex items-center justify-between">
            <button
              onClick={startDownloadingFullQuran}
              disabled={downloadProgress !== null}
              className={`flex-1 py-2.5 ${themeStyles.accentBg} disabled:opacity-50 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md transition-all`}
            >
              <Download className="w-4 h-4" />
              <span>
                {downloadProgress !== null ? `${downloadProgress}%` : t.offlineBtn}
              </span>
            </button>
          </div>

          {downloadProgress !== null && (
            <div className={`w-full ${themeStyles.subSurfaceBg} rounded-full h-2 overflow-hidden border ${themeStyles.border} mt-2`}>
              <div
                className={`${themeStyles.progressBarBg} h-full transition-all duration-300`}
                style={{ width: `${downloadProgress}%` }}
              ></div>
            </div>
          )}

          {downloadComplete && (
            <div className={`flex items-center gap-2 ${themeStyles.accentText} text-xs ${themeStyles.accentSoftBg} p-2.5 rounded-xl border ${themeStyles.accentBorder}`}>
              <CheckCircle2 className="w-4 h-4" />
              <span>Offline Ready ✓</span>
            </div>
          )}
        </div>
      </div>

      {/* Storage Management Entry Card */}
      <button
        onClick={() => setShowStorageScreen(true)}
        className={`w-full ${themeStyles.cardBg} border ${themeStyles.accentBorder} p-4 rounded-2xl flex items-center justify-between gap-3 hover:opacity-95 transition-all text-start`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <div className={`w-10 h-10 rounded-xl ${themeStyles.accentSoftBg} flex items-center justify-center border ${themeStyles.accentBorder} shrink-0`}>
            <HardDrive className={`w-5 h-5 ${themeStyles.accentText}`} />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className={`text-xs font-bold ${themeStyles.accentText}`}>{t.storageTitle}</h3>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${themeStyles.subSurfaceBg} border ${themeStyles.border} ${themeStyles.textPrimary}`}>
                {storageStats.count} {t.storageSurahsCount} • {formatBytes(storageStats.totalBytes, settings.language)}
              </span>
            </div>
            <p className={`text-[10px] ${themeStyles.textSecondary} mt-0.5 truncate`}>
              {t.storageSubtitle}
            </p>
          </div>
        </div>
        {isRtl ? (
          <ChevronLeft className={`w-5 h-5 ${themeStyles.accentText} shrink-0`} />
        ) : (
          <ChevronRight className={`w-5 h-5 ${themeStyles.accentText} shrink-0`} />
        )}
      </button>

      {/* Istighfar Notification API Scheduler */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3.5`}>
        <div className={`flex items-center justify-between gap-2 border-b ${themeStyles.border} pb-2.5`}>
          <div className="flex items-center gap-2 min-w-0">
            <BellRing className={`w-4 h-4 ${themeStyles.accentText} shrink-0`} />
            <div className="min-w-0">
              <h3 className={`text-xs font-bold ${themeStyles.accentText}`}>{t.istighfarSchedTitle}</h3>
              <p className={`text-[10px] ${themeStyles.textSecondary} leading-relaxed`}>
                {t.istighfarSchedDesc}
              </p>
            </div>
          </div>

          <button
            onClick={() =>
              updateIstighfarConfig((prev) => ({ ...prev, enabled: !prev.enabled }))
            }
            className={`w-11 h-6 rounded-full transition-colors relative p-1 shrink-0 ${
              istighfarConfig.enabled ? themeStyles.progressBarBg : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform ${
                istighfarConfig.enabled ? 'translate-x-0' : '-translate-x-5'
              }`}
            />
          </button>
        </div>

        {/* Browser Notification API Permission Bar */}
        <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl p-2.5 flex items-center justify-between gap-2 flex-wrap`}>
          <div className="flex items-center gap-1.5 text-[11px] min-w-0">
            <ShieldCheck
              className={`w-4 h-4 shrink-0 ${
                notifPermission === 'granted'
                  ? 'text-emerald-400'
                  : notifPermission === 'denied'
                  ? 'text-rose-400'
                  : 'text-amber-400'
              }`}
            />
            <span className={`${themeStyles.textPrimary} font-semibold truncate`}>
              {notifPermission === 'granted'
                ? t.notifPermGranted
                : notifPermission === 'denied'
                ? t.notifPermDenied
                : notifPermission === 'unsupported'
                ? t.notifPermUnsupported
                : t.notifPermDefault}
            </span>
          </div>

          {notifPermission === 'default' && (
            <button
              onClick={handleRequestNotifPermission}
              className={`px-2.5 py-1.5 rounded-lg ${themeStyles.accentBg} text-[10px] font-bold shrink-0`}
            >
              {t.enableBrowserNotifBtn}
            </button>
          )}
        </div>

        {/* Next Scheduled Reminder Indicator */}
        {nextReminderInfo && (
          <div className={`${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} rounded-xl px-3 py-2 flex items-center justify-between gap-2 text-[11px]`}>
            <div className="flex items-center gap-1.5 font-bold">
              <Clock className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
              <span className={themeStyles.accentText}>{t.nextReminderLabel}</span>
              <span dir="ltr" className={themeStyles.textPrimary}>
                {nextReminderInfo.slot.time}
              </span>
            </div>
            <span className={`text-[10px] ${themeStyles.textSecondary} truncate max-w-[160px]`}>
              {nextReminderInfo.slot.dhikr}
            </span>
          </div>
        )}

        {/* Add New Specific Time Slot */}
        <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl p-3 space-y-2`}>
          <span className={`text-[11px] font-semibold ${themeStyles.textSecondary} block`}>
            {t.addReminderTimeLabel}
          </span>
          <div className="flex items-center gap-2">
            <input
              type="time"
              dir="ltr"
              value={newReminderTime}
              onChange={(e) => setNewReminderTime(e.target.value)}
              className={`${themeStyles.cardBg} ${themeStyles.textPrimary} border ${themeStyles.accentBorder} rounded-xl px-2.5 py-2 text-xs font-bold focus:outline-none`}
            />
            <select
              value={newReminderDhikr}
              onChange={(e) => setNewReminderDhikr(e.target.value)}
              className={`flex-1 min-w-0 ${themeStyles.cardBg} ${themeStyles.accentText} border ${themeStyles.border} rounded-xl px-2.5 py-2 text-xs font-semibold focus:outline-none`}
            >
              {DEFAULT_DHIKR_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>
          <button
            onClick={handleAddReminderSlot}
            className={`w-full py-2 rounded-xl ${themeStyles.accentBg} text-xs font-bold flex items-center justify-center gap-1.5 transition-all`}
          >
            <Plus className="w-4 h-4" />
            <span>{t.addReminderBtn}</span>
          </button>
        </div>

        {/* Scheduled Times List */}
        <div className="space-y-1.5">
          <span className={`text-[11px] font-semibold ${themeStyles.textSecondary} block`}>
            {t.scheduledTimesTitle} ({istighfarConfig.scheduledSlots.filter((s) => s.enabled).length}/
            {istighfarConfig.scheduledSlots.length})
          </span>

          {istighfarConfig.scheduledSlots.length === 0 ? (
            <p className={`text-xs ${themeStyles.textSecondary} text-center py-2`}>
              {t.noScheduledTimes}
            </p>
          ) : (
            <div className="space-y-1.5 max-h-52 overflow-y-auto pr-0.5">
              {istighfarConfig.scheduledSlots.map((slot) => (
                <div
                  key={slot.id}
                  className={`flex items-center justify-between gap-2 p-2.5 rounded-xl border transition-all ${
                    slot.enabled
                      ? `${themeStyles.subSurfaceBg} ${themeStyles.accentBorder}`
                      : `${themeStyles.subSurfaceBg} ${themeStyles.border} opacity-60`
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <span
                      dir="ltr"
                      className={`px-2 py-1 rounded-lg text-xs font-extrabold ${
                        slot.enabled ? themeStyles.accentSoftBg : themeStyles.cardBg
                      } ${themeStyles.accentText} border ${themeStyles.border} shrink-0`}
                    >
                      {slot.time}
                    </span>
                    <span className={`text-xs font-amiri ${themeStyles.textPrimary} truncate`}>
                      {slot.dhikr}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() =>
                        updateIstighfarConfig((prev) => ({
                          ...prev,
                          scheduledSlots: prev.scheduledSlots.map((s) =>
                            s.id === slot.id ? { ...s, enabled: !s.enabled } : s
                          ),
                        }))
                      }
                      className={`w-9 h-5 rounded-full transition-colors relative p-0.5 ${
                        slot.enabled ? themeStyles.progressBarBg : 'bg-slate-700'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white transition-transform ${
                          slot.enabled ? 'translate-x-0' : '-translate-x-4'
                        }`}
                      />
                    </button>
                    <button
                      onClick={() =>
                        updateIstighfarConfig((prev) => ({
                          ...prev,
                          scheduledSlots: prev.scheduledSlots.filter((s) => s.id !== slot.id),
                        }))
                      }
                      className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/15 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Periodic Interval Option synced with AdhkarTab */}
        <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl p-3 space-y-2`}>
          <div className="flex items-center justify-between gap-2">
            <span className={`text-[11px] font-bold ${themeStyles.textPrimary}`}>
              {t.periodicReminderLabel}
            </span>
            <button
              onClick={async () => {
                unlockReminderAudio();
                const nextEnabled = !istighfarConfig.intervalEnabled;
                if (nextEnabled) {
                  if (notifPermission === 'default') {
                    const perm = await requestNotificationPermission();
                    setNotifPermission(perm);
                  }
                  scheduleNextInterval(istighfarConfig.intervalMinutes);
                } else {
                  setNextIntervalFireAt(null);
                }
                updateIstighfarConfig((prev) => ({
                  ...prev,
                  enabled: true,
                  intervalEnabled: nextEnabled,
                }));
              }}
              className={`w-10 h-5 rounded-full transition-colors relative p-0.5 shrink-0 ${
                istighfarConfig.intervalEnabled ? themeStyles.progressBarBg : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  istighfarConfig.intervalEnabled ? 'translate-x-0' : '-translate-x-5'
                }`}
              />
            </button>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {[5, 15, 30, 60].map((mins) => (
              <button
                key={mins}
                onClick={async () => {
                  unlockReminderAudio();
                  if (notifPermission === 'default') {
                    const perm = await requestNotificationPermission();
                    setNotifPermission(perm);
                  }
                  scheduleNextInterval(mins);
                  updateIstighfarConfig((prev) => ({
                    ...prev,
                    enabled: true,
                    intervalMinutes: mins,
                    intervalEnabled: true,
                  }));
                }}
                className={`py-1.5 rounded-lg text-[11px] font-bold border transition-all ${
                  istighfarConfig.intervalMinutes === mins && istighfarConfig.intervalEnabled
                    ? `${themeStyles.accentBg} ${themeStyles.accentBorder}`
                    : `${themeStyles.cardBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                }`}
              >
                {t.everyMinutesLabel} {mins}د
              </button>
            ))}
          </div>
        </div>

        {/* Test Notification Button */}
        <button
          onClick={handleTestNotification}
          className={`w-full py-2.5 rounded-xl border ${themeStyles.accentBorder} ${themeStyles.accentSoftBg} ${themeStyles.accentText} text-xs font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all`}
        >
          <BellRing className="w-4 h-4" />
          <span>{testNotifFeedback ? `${t.testNotifSent} ✓` : t.testNotifBtn}</span>
        </button>
      </div>

      {/* App Info & Credits + Dua */}
      <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
        <h3 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5 border-b ${themeStyles.border} pb-2`}>
          <Info className="w-4 h-4" />
          <span>{t.appInfoTitle}</span>
        </h3>

        <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.accentBorder} rounded-2xl p-3.5 space-y-2.5 text-center`}>
          <div className={`w-14 h-14 mx-auto rounded-2xl overflow-hidden border ${themeStyles.accentBorder} shadow-md`}>
            <img
              src="/pwa-192x192.png"
              alt={t.appName}
              className="w-full h-full object-cover"
            />
          </div>
          <p className={`text-xs font-bold ${themeStyles.accentText}`}>{t.preparedBy}</p>

          <div className="flex items-center justify-center gap-1.5 text-xs">
            <Phone className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
            <span className={themeStyles.textSecondary}>{t.phoneLabel}</span>
            <a
              href="tel:+201021115587"
              dir="ltr"
              className={`font-bold ${themeStyles.textPrimary} underline`}
            >
              +201021115587
            </a>
          </div>

          <div className={`${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} rounded-xl p-3 space-y-1`} dir="rtl">
            <div className={`flex items-center justify-center gap-1 text-[11px] font-bold ${themeStyles.accentText}`}>
              <Heart className="w-3.5 h-3.5" />
              <span>{t.duaTitle}</span>
            </div>
            <p className={`text-[11px] leading-relaxed ${themeStyles.textPrimary}`}>
              اللهم اغفر لعبدك الفقير إليك ممدوح إدريس صديق ولوالديه، وارحمهما كما ربياه صغيراً، واجعل هذا العمل خالصاً لوجهك الكريم وصدقةً جاريةً له ولوالديه، وبارك له في عمره وأهله، واجمعهم في الفردوس الأعلى من الجنة.
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAboutModal(true)}
          className={`w-full flex items-center justify-between p-2.5 rounded-xl ${themeStyles.subSurfaceBg} hover:opacity-90 border ${themeStyles.border} text-xs transition-colors`}
        >
          <span className={`${themeStyles.textPrimary} font-semibold`}>{t.aboutBtn}</span>
          <span className={`${themeStyles.accentText} font-amiri`}>v3.6</span>
        </button>
      </div>

      {/* About Modal */}
      {showAboutModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div className={`${themeStyles.cardBg} border ${themeStyles.accentBorder} w-full max-w-sm rounded-2xl p-5 shadow-2xl space-y-4 animate-in fade-in zoom-in-95`}>
            <div className={`flex items-center justify-between border-b ${themeStyles.border} pb-3`}>
              <div className="flex items-center gap-2.5">
                <div className={`w-9 h-9 rounded-xl overflow-hidden border ${themeStyles.accentBorder} shadow-sm shrink-0`}>
                  <img
                    src="/pwa-192x192.png"
                    alt={t.appName}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className={`font-bold text-sm ${themeStyles.accentText} font-amiri`}>{t.appName}</h3>
              </div>
              <button
                onClick={() => setShowAboutModal(false)}
                className={`${themeStyles.textSecondary} text-sm font-bold px-2 py-1 ${themeStyles.subSurfaceBg} rounded-lg border ${themeStyles.border}`}
              >
                ✕
              </button>
            </div>
            <p className={`text-xs ${themeStyles.textPrimary} leading-relaxed`}>
              {t.appTagline}
            </p>
            <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl p-3 space-y-2 text-center`}>
              <p className={`text-xs font-bold ${themeStyles.accentText}`}>{t.preparedBy}</p>
              <p className={`text-xs ${themeStyles.textPrimary}`}>
                {t.phoneLabel}{' '}
                <a href="tel:+201021115587" dir="ltr" className="font-bold underline">
                  +201021115587
                </a>
              </p>
              <p className={`text-[11px] ${themeStyles.textSecondary} leading-relaxed pt-1 border-t ${themeStyles.border}`} dir="rtl">
                نسألكم الدعاء له ولوالديه بالمغفرة والرحمة والبركة، وأن يتقبل الله هذا العمل صدقة جارية خالصة لوجهه الكريم.
              </p>
            </div>
            <div className={`text-[10px] ${themeStyles.textSecondary} text-center pt-1`}>
              © 2026 {t.appName}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
