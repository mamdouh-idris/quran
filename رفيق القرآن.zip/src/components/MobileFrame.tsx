import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  BookOpen,
  Mic,
  Clock,
  Heart,
  Radio,
  Settings,
  PhoneIncoming,
  PhoneOff,
  BellRing,
  Volume2,
  Square,
  X,
  MapPin,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { AppSettings, Surah, Reciter, RadioStation, Dhkar, IstighfarScheduleConfig } from '../types';
import { muezzinsList, Muezzin } from '../data/quranData';
import { ThemeStyles } from '../utils/theme';
import { Translations } from '../utils/i18n';
import { MushafTab } from './tabs/MushafTab';
import { TasmieTab } from './tabs/TasmieTab';
import { PrayerTimesTab } from './tabs/PrayerTimesTab';
import { AdhkarTab } from './tabs/AdhkarTab';
import { RadioTab } from './tabs/RadioTab';
import { SettingsTab } from './tabs/SettingsTab';
import { SmartPauseProvider, useSmartPause } from '../context/SmartPauseContext';
import {
  dispatchOSSystemNotification,
  formatCurrentDateKey,
  formatCurrentHHMM,
  getLastFiredMap,
  getNextIntervalFireAt,
  getNotificationPermissionState,
  ISTIGHFAR_INAPP_ALERT_EVENT,
  ISTIGHFAR_SCHEDULE_UPDATED_EVENT,
  loadIstighfarSchedule,
  markSlotFired,
  NotificationPermissionState,
  requestNotificationPermission,
  scheduleNextInterval,
  sendIstighfarNotification,
  setNextIntervalFireAt,
  unlockReminderAudio,
} from '../utils/istighfarScheduler';
import {
  ADHAN_CONTROL_EVENT,
  ADHAN_STATE_EVENT,
  AdhanStateDetail,
  cacheMuezzinAudio,
  findDuePrayer,
  loadPrayerPrefs,
  markAdhanFired,
  ObligatoryPrayerKey,
  PRAYER_PREFS_UPDATED_EVENT,
  PrayerAdhanPrefs,
  resolvePlayableAdhanUrl,
  savePrayerPrefs,
} from '../utils/adhanScheduler';
import { calculatePrayerSchedule, CITIES_LIST, getCityLocalDate } from '../utils/prayerMath';

const FIRST_RUN_PERMS_KEY = 'rafiq_first_run_perms_done_v1';

interface MobileFrameProps {
  surahs: Surah[];
  reciters: Reciter[];
  radioStations: RadioStation[];
  adhkar: Dhkar[];
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  themeStyles: ThemeStyles;
  t: Translations;
}

const MobileAppShellContent: React.FC<MobileFrameProps> = ({
  surahs,
  reciters,
  radioStations,
  adhkar,
  settings,
  setSettings,
  themeStyles,
  t,
}) => {
  const [activeTab, setActiveTab] = useState<
    'mushaf' | 'tasmie' | 'prayer' | 'adhkar' | 'radio' | 'settings'
  >('mushaf');
  const [istighfarConfig, setIstighfarConfig] = useState<IstighfarScheduleConfig>(() =>
    loadIstighfarSchedule()
  );
  const [prayerPrefs, setPrayerPrefs] = useState<PrayerAdhanPrefs>(() => loadPrayerPrefs());
  const [istighfarBanner, setIstighfarBanner] = useState<{ title: string; body: string } | null>(
    null
  );
  const [adhanState, setAdhanState] = useState<AdhanStateDetail>({
    isPlaying: false,
    usedBackup: false,
  });

  // First-launch permissions prompt state
  const [showFirstRunPerms, setShowFirstRunPerms] = useState<boolean>(() => {
    try {
      return localStorage.getItem(FIRST_RUN_PERMS_KEY) !== '1';
    } catch {
      return false;
    }
  });
  const [permNotif, setPermNotif] = useState<NotificationPermissionState>(() =>
    getNotificationPermissionState()
  );
  const [permGps, setPermGps] = useState<'pending' | 'granted' | 'denied'>('pending');
  const [permMic, setPermMic] = useState<'pending' | 'granted' | 'denied'>('pending');
  const [isRequestingPerms, setIsRequestingPerms] = useState<boolean>(false);

  const adhanAudioRef = useRef<HTMLAudioElement | null>(null);
  const adhanPlayingRef = useRef<boolean>(false);
  const adhanUsedBackupRef = useRef<boolean>(false);
  const shortAdhanTimerRef = useRef<number | null>(null);
  const chimeTimeoutRef = useRef<number | null>(null);
  const audioUnlockedRef = useRef<boolean>(false);
  const preloadedBlobUrlsRef = useRef<Record<string, string>>({});
  const activeObjectUrlRef = useRef<string | null>(null);
  const activeMuezzinRef = useRef<Muezzin>(
    muezzinsList.find((m) => m.id === settings.muezzinId) || muezzinsList[0]
  );

  activeMuezzinRef.current =
    muezzinsList.find((m) => m.id === settings.muezzinId) || muezzinsList[0];

  const {
    smartPauseEnabled,
    activeInterruption,
    pausedBySmartPause,
    endInterruption,
    registerAudioController,
    notifyAudioStarted,
    notifyAudioStopped,
  } = useSmartPause();

  const emitAdhanState = useCallback((next: AdhanStateDetail) => {
    adhanPlayingRef.current = next.isPlaying;
    adhanUsedBackupRef.current = next.usedBackup;
    setAdhanState(next);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(ADHAN_STATE_EVENT, { detail: next }));
    }
  }, []);

  const clearAdhanTimers = useCallback(() => {
    if (shortAdhanTimerRef.current !== null) {
      window.clearTimeout(shortAdhanTimerRef.current);
      shortAdhanTimerRef.current = null;
    }
    if (chimeTimeoutRef.current !== null) {
      window.clearTimeout(chimeTimeoutRef.current);
      chimeTimeoutRef.current = null;
    }
  }, []);

  const revokeActiveAdhanBlob = useCallback(() => {
    if (activeObjectUrlRef.current) {
      URL.revokeObjectURL(activeObjectUrlRef.current);
      activeObjectUrlRef.current = null;
    }
  }, []);

  const stopAdhanPlayback = useCallback(() => {
    clearAdhanTimers();
    if (adhanAudioRef.current) {
      adhanAudioRef.current.pause();
      adhanAudioRef.current.currentTime = 0;
    }
    revokeActiveAdhanBlob();
    emitAdhanState({ isPlaying: false, usedBackup: false });
    notifyAudioStopped('adhan');
  }, [clearAdhanTimers, emitAdhanState, notifyAudioStopped, revokeActiveAdhanBlob]);

  const playSyntheticAdhanFallback = useCallback(
    (prayerLabel?: string, muezzinName?: string) => {
      try {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          const now = ctx.currentTime;
          // Gentle two-note takbeer chime cadence when audio stream is blocked/offline
          const pattern = [
            { freq: 392, start: 0, dur: 0.45 },
            { freq: 440, start: 0.5, dur: 0.55 },
            { freq: 392, start: 1.25, dur: 0.45 },
            { freq: 440, start: 1.8, dur: 0.7 },
          ];
          pattern.forEach((n) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(n.freq, now + n.start);
            gain.gain.setValueAtTime(0.001, now + n.start);
            gain.gain.exponentialRampToValueAtTime(0.28, now + n.start + 0.06);
            gain.gain.exponentialRampToValueAtTime(0.001, now + n.start + n.dur);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now + n.start);
            osc.stop(now + n.start + n.dur + 0.04);
          });
          setTimeout(() => {
            ctx.close().catch(() => {});
          }, 3000);
        }
      } catch {
        // ignore WebAudio fallback restriction
      }

      emitAdhanState({
        isPlaying: true,
        usedBackup: true,
        activePrayerName: prayerLabel,
        muezzinName,
      });

      chimeTimeoutRef.current = window.setTimeout(() => {
        stopAdhanPlayback();
      }, 4500);
    },
    [emitAdhanState, stopAdhanPlayback]
  );

  const warmCacheAndBlobForMuezzin = useCallback((muezzin: Muezzin) => {
    if (!muezzin?.audioUrl) return;
    cacheMuezzinAudio(muezzin)
      .then(async () => {
        if (!preloadedBlobUrlsRef.current[muezzin.audioUrl]) {
          const resolved = await resolvePlayableAdhanUrl(muezzin.audioUrl);
          if (resolved.isObjectUrl) {
            preloadedBlobUrlsRef.current[muezzin.audioUrl] = resolved.src;
          }
        }
        if (muezzin.backupUrl && !preloadedBlobUrlsRef.current[muezzin.backupUrl]) {
          const resolvedBackup = await resolvePlayableAdhanUrl(muezzin.backupUrl);
          if (resolvedBackup.isObjectUrl) {
            preloadedBlobUrlsRef.current[muezzin.backupUrl] = resolvedBackup.src;
          }
        }
      })
      .catch(() => {});
  }, []);

  const startAdhanPlayback = useCallback(
    (muezzin: Muezzin, prayerLabel?: string) => {
      const audioEl = adhanAudioRef.current;
      if (!audioEl) return;

      clearAdhanTimers();
      revokeActiveAdhanBlob();
      notifyAudioStarted('adhan');
      emitAdhanState({
        isPlaying: true,
        usedBackup: false,
        activePrayerName: prayerLabel,
        muezzinName: muezzin.name,
      });

      // Immediately save Adhan MP3 to offline CacheStorage when listened to or tested
      warmCacheAndBlobForMuezzin(muezzin);

      if ('mediaSession' in navigator) {
        try {
          navigator.mediaSession.metadata = new MediaMetadata({
            title: prayerLabel ? `أذان ${prayerLabel}` : 'الأذان',
            artist: muezzin.name,
            album: 'رفيق القرآن',
            artwork: [{ src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' }],
          });
          navigator.mediaSession.setActionHandler('stop', stopAdhanPlayback);
          navigator.mediaSession.setActionHandler('pause', stopAdhanPlayback);
        } catch {
          // ignore mediaSession errors
        }
      }

      const playWithOfflineFallback = () => {
        const cachedBlob = preloadedBlobUrlsRef.current[muezzin.audioUrl];
        audioEl.muted = false;
        audioEl.src = cachedBlob || muezzin.audioUrl;
        audioEl.currentTime = 0;

        audioEl.play().catch(async () => {
          // Try explicit CacheStorage Blob if not preloaded synchronously
          const resolvedPrimary = await resolvePlayableAdhanUrl(muezzin.audioUrl);
          if (resolvedPrimary.isObjectUrl) {
            activeObjectUrlRef.current = resolvedPrimary.src;
            audioEl.src = resolvedPrimary.src;
            try {
              await audioEl.play();
              return;
            } catch {
              // continue to backup URL
            }
          }

          if (muezzin.backupUrl) {
            emitAdhanState({
              isPlaying: true,
              usedBackup: true,
              activePrayerName: prayerLabel,
              muezzinName: muezzin.name,
            });
            const resolvedBackup = await resolvePlayableAdhanUrl(muezzin.backupUrl);
            if (resolvedBackup.isObjectUrl) {
              activeObjectUrlRef.current = resolvedBackup.src;
            }
            audioEl.src =
              preloadedBlobUrlsRef.current[muezzin.backupUrl] || resolvedBackup.src;
            audioEl.play().catch(() => {
              playSyntheticAdhanFallback(prayerLabel, muezzin.name);
            });
          } else {
            playSyntheticAdhanFallback(prayerLabel, muezzin.name);
          }
        });
      };

      playWithOfflineFallback();

      if (settings.shortAdhan) {
        shortAdhanTimerRef.current = window.setTimeout(() => {
          stopAdhanPlayback();
        }, 22000);
      }
    },
    [
      clearAdhanTimers,
      emitAdhanState,
      notifyAudioStarted,
      playSyntheticAdhanFallback,
      revokeActiveAdhanBlob,
      settings.shortAdhan,
      stopAdhanPlayback,
      warmCacheAndBlobForMuezzin,
    ]
  );

  // Unlock WebAudio & pre-cache active Muezzin MP3 on user gesture for reliable automatic Adhan
  useEffect(() => {
    const unlockAllAudio = () => {
      unlockReminderAudio();
      if (audioUnlockedRef.current) return;
      audioUnlockedRef.current = true;
      const audioEl = adhanAudioRef.current;
      const muezzin = activeMuezzinRef.current;
      if (audioEl && !adhanPlayingRef.current) {
        try {
          audioEl.muted = true;
          audioEl.src = preloadedBlobUrlsRef.current[muezzin.audioUrl] || muezzin.audioUrl;
          const playPromise = audioEl.play();
          if (playPromise && typeof playPromise.then === 'function') {
            playPromise
              .then(() => {
                audioEl.pause();
                audioEl.currentTime = 0;
                audioEl.muted = false;
              })
              .catch(() => {
                audioEl.muted = false;
              });
          }
        } catch {
          audioEl.muted = false;
        }
      }
      warmCacheAndBlobForMuezzin(muezzin);
    };

    window.addEventListener('pointerdown', unlockAllAudio, { passive: true });
    return () => window.removeEventListener('pointerdown', unlockAllAudio);
  }, [warmCacheAndBlobForMuezzin]);

  // Pre-cache newly chosen Muezzin audio so Adhan is automatically stored offline
  useEffect(() => {
    const muezzin = muezzinsList.find((m) => m.id === settings.muezzinId) || muezzinsList[0];
    if (muezzin) {
      warmCacheAndBlobForMuezzin(muezzin);
    }
  }, [settings.muezzinId, warmCacheAndBlobForMuezzin]);

  // Revoke cached ObjectURLs on unmount
  useEffect(() => {
    return () => {
      Object.values(preloadedBlobUrlsRef.current).forEach((u) => {
        if (typeof u === 'string') URL.revokeObjectURL(u);
      });
      revokeActiveAdhanBlob();
    };
  }, [revokeActiveAdhanBlob]);

  // Register Adhan controller with Smart Pause
  useEffect(() => {
    return registerAudioController('adhan', {
      pause: () => {
        adhanAudioRef.current?.pause();
        emitAdhanState({ isPlaying: false, usedBackup: adhanUsedBackupRef.current });
      },
      resume: () => {
        if (!adhanAudioRef.current) return;
        notifyAudioStarted('adhan');
        emitAdhanState({
          isPlaying: true,
          usedBackup: adhanUsedBackupRef.current,
          muezzinName: activeMuezzinRef.current.name,
        });
        adhanAudioRef.current.play().catch(() => {
          playSyntheticAdhanFallback(undefined, activeMuezzinRef.current.name);
        });
      },
      isPlaying: () => adhanPlayingRef.current,
    });
  }, [emitAdhanState, notifyAudioStarted, playSyntheticAdhanFallback, registerAudioController]);

  // Listen for manual Adhan controls from PrayerTimesTab & Service Worker notification click
  useEffect(() => {
    const onAdhanControl = (e: Event) => {
      const detail = (e as CustomEvent<{ action: string; muezzinId?: string }>).detail;
      if (!detail) return;
      if (detail.action === 'stop') {
        stopAdhanPlayback();
      } else if (detail.action === 'play-test') {
        if (adhanPlayingRef.current) {
          stopAdhanPlayback();
        } else {
          const target =
            muezzinsList.find((m) => m.id === (detail.muezzinId || settings.muezzinId)) ||
            muezzinsList[0];
          startAdhanPlayback(target);
        }
      } else if (detail.action === 'switch-muezzin' && adhanPlayingRef.current) {
        const nextM = muezzinsList.find((m) => m.id === detail.muezzinId) || muezzinsList[0];
        startAdhanPlayback(nextM, adhanState.activePrayerName);
      }
    };

    const onSwMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'STOP_ADHAN') {
        stopAdhanPlayback();
      }
    };

    window.addEventListener(ADHAN_CONTROL_EVENT, onAdhanControl);
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', onSwMessage);
    }
    return () => {
      window.removeEventListener(ADHAN_CONTROL_EVENT, onAdhanControl);
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.removeEventListener('message', onSwMessage);
      }
    };
  }, [adhanState.activePrayerName, settings.muezzinId, startAdhanPlayback, stopAdhanPlayback]);

  // Real device orientation flip-to-mute when Adhan is calling
  useEffect(() => {
    if (!settings.flipMuteEnabled || !adhanState.isPlaying) return;
    const onOrientation = (e: DeviceOrientationEvent) => {
      if (typeof e.beta === 'number' && Math.abs(e.beta) > 150) {
        stopAdhanPlayback();
      }
    };
    window.addEventListener('deviceorientation', onOrientation);
    return () => window.removeEventListener('deviceorientation', onOrientation);
  }, [adhanState.isPlaying, settings.flipMuteEnabled, stopAdhanPlayback]);

  // Keep Istighfar schedule & Prayer prefs synced across tabs
  useEffect(() => {
    const onScheduleUpdated = (e: Event) => {
      const detail = (e as CustomEvent<IstighfarScheduleConfig>).detail;
      setIstighfarConfig(detail || loadIstighfarSchedule());
    };
    const onPrayerPrefsUpdated = (e: Event) => {
      const detail = (e as CustomEvent<PrayerAdhanPrefs>).detail;
      setPrayerPrefs(detail || loadPrayerPrefs());
    };
    window.addEventListener(ISTIGHFAR_SCHEDULE_UPDATED_EVENT, onScheduleUpdated);
    window.addEventListener(PRAYER_PREFS_UPDATED_EVENT, onPrayerPrefsUpdated);
    return () => {
      window.removeEventListener(ISTIGHFAR_SCHEDULE_UPDATED_EVENT, onScheduleUpdated);
      window.removeEventListener(PRAYER_PREFS_UPDATED_EVENT, onPrayerPrefsUpdated);
    };
  }, []);

  // Listen for Notification API / in-app Istighfar alerts
  useEffect(() => {
    let hideTimeout: ReturnType<typeof setTimeout> | null = null;
    const onAlert = (e: Event) => {
      const detail = (e as CustomEvent<{ title: string; body: string }>).detail;
      if (!detail) return;
      setIstighfarBanner({ title: detail.title, body: detail.body });
      if (hideTimeout) clearTimeout(hideTimeout);
      hideTimeout = setTimeout(() => setIstighfarBanner(null), 9000);
    };
    window.addEventListener(ISTIGHFAR_INAPP_ALERT_EVENT, onAlert);
    return () => {
      window.removeEventListener(ISTIGHFAR_INAPP_ALERT_EVENT, onAlert);
      if (hideTimeout) clearTimeout(hideTimeout);
    };
  }, []);

  // Automatic Prayer-Time Adhan Checker (works across ALL tabs + wakes on visibilitychange)
  useEffect(() => {
    if (!prayerPrefs.autoAdhanEnabled) return;

    const checkPrayerTimes = () => {
      const now = new Date();
      const city = CITIES_LIST.find((c) => c.id === prayerPrefs.cityId) || CITIES_LIST[0];
      const lat = prayerPrefs.gpsCoords ? prayerPrefs.gpsCoords.lat : city.lat;
      const lng = prayerPrefs.gpsCoords ? prayerPrefs.gpsCoords.lng : city.lng;
      const tzOffset = prayerPrefs.gpsCoords
        ? -now.getTimezoneOffset() / 60
        : city.tzOffset;

      const cityNow = getCityLocalDate(now, tzOffset);
      const dateKey = formatCurrentDateKey(cityNow);
      const schedule = calculatePrayerSchedule(
        cityNow,
        lat,
        lng,
        tzOffset,
        prayerPrefs.timeOffsetMinutes,
        settings.language
      );

      const duePrayer = findDuePrayer(schedule, cityNow, dateKey, prayerPrefs.enabledPrayers, 120);
      if (!duePrayer) return;

      markAdhanFired(dateKey, duePrayer.key as ObligatoryPrayerKey);
      const muezzin =
        muezzinsList.find((m) => m.id === settings.muezzinId) || muezzinsList[0];
      const prayerTitle =
        settings.language === 'ar' || settings.language === 'ur'
          ? `صلاة ${duePrayer.arabicName}`
          : duePrayer.englishName;

      dispatchOSSystemNotification(
        `حان الآن وقت ${prayerTitle}`,
        `${duePrayer.formattedTime} · ${muezzin.name}`,
        `adhan-${dateKey}-${duePrayer.key}`,
        {
          requireInteraction: true,
          vibrate: [400, 150, 400, 150, 400],
          actions: [{ action: 'stop-adhan', title: 'إيقاف الأذان' }],
        }
      ).catch(() => {});

      startAdhanPlayback(muezzin, prayerTitle);
    };

    checkPrayerTimes();
    const timer = window.setInterval(checkPrayerTimes, 5000);
    const onWake = () => {
      if (document.visibilityState === 'visible') {
        checkPrayerTimes();
      }
    };
    document.addEventListener('visibilitychange', onWake);
    window.addEventListener('focus', checkPrayerTimes);

    return () => {
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onWake);
      window.removeEventListener('focus', checkPrayerTimes);
    };
  }, [prayerPrefs, settings.language, settings.muezzinId, startAdhanPlayback]);

  // Unified Istighfar Exact Slots + Persistent Timestamp Interval Watcher
  useEffect(() => {
    if (!istighfarConfig.enabled) return;

    if (istighfarConfig.intervalEnabled) {
      const existingNext = getNextIntervalFireAt();
      if (!existingNext) {
        scheduleNextInterval(istighfarConfig.intervalMinutes);
      }
    } else {
      setNextIntervalFireAt(null);
    }

    const checkReminders = () => {
      const now = new Date();
      const dateKey = formatCurrentDateKey(now);
      const hhmm = formatCurrentHHMM(now);
      const dateMinuteKey = `${dateKey}_${hhmm}`;
      const firedMap = getLastFiredMap();

      for (const slot of istighfarConfig.scheduledSlots) {
        if (!slot.enabled || slot.time !== hhmm) continue;
        if (firedMap[slot.id] === dateMinuteKey) continue;
        markSlotFired(slot.id, dateMinuteKey);
        sendIstighfarNotification(
          t.adhkarTabTimer,
          slot.dhikr,
          `istighfar-${slot.id}-${dateMinuteKey}`
        );
      }

      if (istighfarConfig.intervalEnabled) {
        const nextAt = getNextIntervalFireAt();
        if (nextAt && Date.now() >= nextAt) {
          scheduleNextInterval(istighfarConfig.intervalMinutes);
          sendIstighfarNotification(
            t.adhkarTabTimer,
            istighfarConfig.intervalDhikr,
            `istighfar-interval-${Date.now()}`
          );
        }
      }
    };

    checkReminders();
    const checker = window.setInterval(checkReminders, 5000);
    const onWake = () => {
      if (document.visibilityState === 'visible') {
        checkReminders();
      }
    };
    document.addEventListener('visibilitychange', onWake);
    window.addEventListener('focus', checkReminders);

    return () => {
      window.clearInterval(checker);
      document.removeEventListener('visibilitychange', onWake);
      window.removeEventListener('focus', checkReminders);
    };
  }, [istighfarConfig, t.adhkarTabTimer]);

  const navItems: Array<{
    id: 'mushaf' | 'tasmie' | 'prayer' | 'adhkar' | 'radio' | 'settings';
    label: string;
    icon: React.ReactNode;
  }> = [
    { id: 'mushaf', label: t.navMushaf, icon: <BookOpen className="w-5 h-5" /> },
    { id: 'tasmie', label: t.navTasmie, icon: <Mic className="w-5 h-5" /> },
    { id: 'prayer', label: t.navPrayer, icon: <Clock className="w-5 h-5" /> },
    { id: 'adhkar', label: t.navAdhkar, icon: <Heart className="w-5 h-5" /> },
    { id: 'radio', label: t.navRadio, icon: <Radio className="w-5 h-5" /> },
    { id: 'settings', label: t.navSettings, icon: <Settings className="w-5 h-5" /> },
  ];

  const closeFirstRunModal = () => {
    try {
      localStorage.setItem(FIRST_RUN_PERMS_KEY, '1');
    } catch {
      // ignore storage errors
    }
    setShowFirstRunPerms(false);
  };

  const requestAllInitialPermissions = async () => {
    if (isRequestingPerms) return;
    setIsRequestingPerms(true);
    unlockReminderAudio();
    warmCacheAndBlobForMuezzin(activeMuezzinRef.current);

    try {
      // 1. Notifications permission
      if (getNotificationPermissionState() === 'default') {
        const res = await requestNotificationPermission();
        setPermNotif(res);
      } else {
        setPermNotif(getNotificationPermissionState());
      }

      // 2. Geolocation permission
      if ('geolocation' in navigator) {
        await new Promise<void>((resolve) => {
          navigator.geolocation.getCurrentPosition(
            (pos) => {
              const latest = loadPrayerPrefs();
              savePrayerPrefs({
                ...latest,
                gpsCoords: { lat: pos.coords.latitude, lng: pos.coords.longitude },
              });
              setPermGps('granted');
              resolve();
            },
            () => {
              setPermGps('denied');
              resolve();
            },
            { enableHighAccuracy: true, timeout: 7000 }
          );
        });
      }

      // 3. Microphone permission
      if (navigator.mediaDevices?.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          stream.getTracks().forEach((tr) => tr.stop());
          setPermMic('granted');
        } catch {
          setPermMic('denied');
        }
      }
    } finally {
      setIsRequestingPerms(false);
      closeFirstRunModal();
    }
  };

  return (
    <div className="flex-1 min-h-0 w-full flex flex-col items-center justify-center md:px-4 md:py-3">
      <audio
        ref={adhanAudioRef}
        preload="auto"
        onEnded={stopAdhanPlayback}
        onError={async () => {
          if (!adhanPlayingRef.current) return;
          const muezzin = activeMuezzinRef.current;
          if (!adhanUsedBackupRef.current && muezzin.backupUrl && adhanAudioRef.current) {
            emitAdhanState({
              isPlaying: true,
              usedBackup: true,
              activePrayerName: adhanState.activePrayerName,
              muezzinName: muezzin.name,
            });
            const resolvedBackup = await resolvePlayableAdhanUrl(muezzin.backupUrl);
            if (resolvedBackup.isObjectUrl) {
              activeObjectUrlRef.current = resolvedBackup.src;
            }
            adhanAudioRef.current.src =
              preloadedBlobUrlsRef.current[muezzin.backupUrl] || resolvedBackup.src;
            adhanAudioRef.current.play().catch(() => {
              playSyntheticAdhanFallback(adhanState.activePrayerName, muezzin.name);
            });
            return;
          }
          playSyntheticAdhanFallback(adhanState.activePrayerName, muezzin.name);
        }}
      />

      {/* Full-screen edge-to-edge on mobile; centered wide container on desktop */}
      <div
        className={`${themeStyles.phoneBg} w-full h-full md:max-w-3xl lg:max-w-4xl md:rounded-3xl md:border ${themeStyles.border} md:shadow-2xl flex flex-col overflow-hidden relative transition-colors duration-300`}
      >
        {/* First-Launch Permissions Modal */}
        {showFirstRunPerms && (
          <div className="absolute inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <div
              className={`${themeStyles.surfaceBg} border ${themeStyles.accentBorder} rounded-3xl p-5 w-full max-w-sm shadow-2xl space-y-4`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className={`w-10 h-10 rounded-2xl ${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} flex items-center justify-center shrink-0`}>
                    <ShieldCheck className={`w-5 h-5 ${themeStyles.accentText}`} />
                  </div>
                  <div>
                    <h3 className={`text-sm font-bold ${themeStyles.textPrimary}`}>
                      تفعيل أذونات التطبيق
                    </h3>
                    <p className={`text-[11px] ${themeStyles.textSecondary}`}>
                      لتشغيل الأذان والتنبيهات والتسميع بدقة
                    </p>
                  </div>
                </div>
                <button
                  onClick={closeFirstRunModal}
                  className={`p-1.5 rounded-xl ${themeStyles.cardBg} ${themeStyles.textSecondary} border ${themeStyles.border}`}
                  aria-label="إغلاق"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2">
                <div className={`${themeStyles.cardBg} border ${themeStyles.border} rounded-2xl p-3 flex items-center justify-between gap-2`}>
                  <div className="flex items-center gap-2.5 min-w-0">
                    <BellRing className={`w-4 h-4 shrink-0 ${themeStyles.accentText}`} />
                    <div className="min-w-0">
                      <span className={`text-xs font-bold block ${themeStyles.textPrimary}`}>
                        الإشعارات والتنبيهات
                      </span>
                      <span className={`text-[10px] ${themeStyles.textSecondary}`}>
                        لرفع الأذان ومؤقت الاستغفار
                      </span>
                    </div>
                  </div>
                  <span className={`text-[10px] font-bold shrink-0 ${permNotif === 'granted' ? 'text-emerald-400' : themeStyles.accentText}`}>
                    {permNotif === 'granted' ? 'مُفعّل ✓' : 'مطلوب'}
                  </span>
                </div>

                <div className={`${themeStyles.cardBg} border ${themeStyles.border} rounded-2xl p-3 flex items-center justify-between gap-2`}>
                  <div className="flex items-center gap-2.5 min-w-0">
                    <MapPin className={`w-4 h-4 shrink-0 ${themeStyles.accentText}`} />
                    <div className="min-w-0">
                      <span className={`text-xs font-bold block ${themeStyles.textPrimary}`}>
                        الموقع الجغرافي (GPS)
                      </span>
                      <span className={`text-[10px] ${themeStyles.textSecondary}`}>
                        لحساب مواقيت الصلاة والقبلة
                      </span>
                    </div>
                  </div>
                  <span className={`text-[10px] font-bold shrink-0 ${permGps === 'granted' ? 'text-emerald-400' : themeStyles.accentText}`}>
                    {permGps === 'granted' ? 'مُفعّل ✓' : 'مطلوب'}
                  </span>
                </div>

                <div className={`${themeStyles.cardBg} border ${themeStyles.border} rounded-2xl p-3 flex items-center justify-between gap-2`}>
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Mic className={`w-4 h-4 shrink-0 ${themeStyles.accentText}`} />
                    <div className="min-w-0">
                      <span className={`text-xs font-bold block ${themeStyles.textPrimary}`}>
                        الميكروفون
                      </span>
                      <span className={`text-[10px] ${themeStyles.textSecondary}`}>
                        لتسميع الآيات بالصوت
                      </span>
                    </div>
                  </div>
                  <span className={`text-[10px] font-bold shrink-0 ${permMic === 'granted' ? 'text-emerald-400' : themeStyles.accentText}`}>
                    {permMic === 'granted' ? 'مُفعّل ✓' : 'مطلوب'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={requestAllInitialPermissions}
                  disabled={isRequestingPerms}
                  className={`flex-1 py-2.5 px-3 rounded-2xl ${themeStyles.accentBg} text-xs font-bold shadow-lg flex items-center justify-center gap-1.5`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isRequestingPerms ? 'جاري التفعيل...' : 'سماح وتفعيل الأذونات'}</span>
                </button>
                <button
                  onClick={closeFirstRunModal}
                  className={`py-2.5 px-3 rounded-2xl ${themeStyles.cardBg} ${themeStyles.textSecondary} border ${themeStyles.border} text-xs font-semibold`}
                >
                  لاحقاً
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Active Adhan Call Banner */}
        {adhanState.isPlaying && !activeInterruption && (
          <div
            className={`absolute top-3 left-3 right-3 z-50 ${themeStyles.surfaceBg} backdrop-blur-md border ${themeStyles.accentBorder} rounded-2xl p-3.5 shadow-2xl flex items-center justify-between gap-2.5`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className={`w-10 h-10 rounded-xl ${themeStyles.accentBg} flex items-center justify-center shrink-0`}>
                <Volume2 className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <h4 className={`text-xs font-bold ${themeStyles.accentText} truncate`}>
                  {adhanState.activePrayerName
                    ? `حان الآن وقت ${adhanState.activePrayerName}`
                    : 'الأذان يرفع الآن'}
                </h4>
                <p className={`text-[11px] ${themeStyles.textPrimary} truncate`}>
                  {adhanState.muezzinName || activeMuezzinRef.current.name}
                </p>
              </div>
            </div>
            <button
              onClick={stopAdhanPlayback}
              className="px-3 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-1.5 shrink-0 shadow-md"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>إيقاف</span>
            </button>
          </div>
        )}

        {/* System Call / Alert Interruption Overlay */}
        {activeInterruption && (
          <div
            className={`absolute top-3 left-3 right-3 z-50 ${themeStyles.surfaceBg} backdrop-blur-md border ${themeStyles.accentBorder} rounded-2xl p-3.5 shadow-2xl animate-in slide-in-from-top-4`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                    activeInterruption.type === 'call'
                      ? `${themeStyles.accentSoftBg} animate-pulse`
                      : 'bg-amber-500/20 text-amber-400'
                  }`}
                >
                  {activeInterruption.type === 'call' ? (
                    <PhoneIncoming className="w-5 h-5" />
                  ) : (
                    <BellRing className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <h4 className={`text-xs font-bold ${themeStyles.textPrimary}`}>{activeInterruption.title}</h4>
                  <p className={`text-[10px] ${themeStyles.textSecondary} mt-0.5`}>{activeInterruption.subtitle}</p>
                </div>
              </div>

              <button
                onClick={endInterruption}
                className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-colors shrink-0 ${
                  activeInterruption.type === 'call'
                    ? 'bg-red-600 hover:bg-red-500 text-white'
                    : `${themeStyles.cardBg} ${themeStyles.textPrimary} border ${themeStyles.border}`
                }`}
              >
                {activeInterruption.type === 'call' ? (
                  <>
                    <PhoneOff className="w-3.5 h-3.5" />
                    <span>{t.endCall}</span>
                  </>
                ) : (
                  <X className="w-3.5 h-3.5" />
                )}
              </button>
            </div>

            <div className={`mt-2.5 pt-2 border-t ${themeStyles.border} text-[10px] flex items-center justify-between`}>
              <span className={pausedBySmartPause ? 'text-amber-400 font-semibold' : themeStyles.textSecondary}>
                {pausedBySmartPause
                  ? 'التوقف الذكي: تم إيقاف الصوت تلقائياً وسيُستأنف بعد الانتهاء'
                  : smartPauseEnabled
                  ? 'التوقف الذكي مفعّل'
                  : 'التوقف الذكي معطّل'}
              </span>
            </div>
          </div>
        )}

        {/* Scheduled Istighfar Reminder Banner */}
        {istighfarBanner && !activeInterruption && !adhanState.isPlaying && (
          <div
            className={`absolute top-3 left-3 right-3 z-50 ${themeStyles.surfaceBg} backdrop-blur-md border ${themeStyles.accentBorder} rounded-2xl p-3.5 shadow-2xl animate-in slide-in-from-top-4 flex items-start justify-between gap-2.5`}
          >
            <div className="flex items-start gap-2.5 min-w-0">
              <div className={`w-9 h-9 rounded-xl ${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} flex items-center justify-center shrink-0`}>
                <BellRing className={`w-4 h-4 ${themeStyles.accentText}`} />
              </div>
              <div className="min-w-0">
                <h4 className={`text-xs font-bold ${themeStyles.accentText}`}>{istighfarBanner.title}</h4>
                <p className={`text-xs font-amiri ${themeStyles.textPrimary} mt-0.5 leading-relaxed`}>
                  {istighfarBanner.body}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIstighfarBanner(null)}
              className={`p-1.5 rounded-lg ${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} border ${themeStyles.border} shrink-0`}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Full-Height App Content Area */}
        <div className={`flex-1 min-h-0 overflow-hidden ${themeStyles.phoneBg} flex flex-col relative transition-colors duration-300`}>
          <div className={activeTab === 'mushaf' ? 'flex-1 flex flex-col min-h-0' : 'hidden'}>
            <MushafTab surahs={surahs} reciters={reciters} settings={settings} themeStyles={themeStyles} />
          </div>
          <div className={activeTab === 'tasmie' ? 'flex-1 flex flex-col min-h-0' : 'hidden'}>
            <TasmieTab surahs={surahs} settings={settings} themeStyles={themeStyles} t={t} />
          </div>
          <div className={activeTab === 'prayer' ? 'flex-1 flex flex-col min-h-0' : 'hidden'}>
            <PrayerTimesTab settings={settings} setSettings={setSettings} themeStyles={themeStyles} t={t} />
          </div>
          <div className={activeTab === 'adhkar' ? 'flex-1 flex flex-col min-h-0' : 'hidden'}>
            <AdhkarTab adhkarList={adhkar} settings={settings} themeStyles={themeStyles} t={t} />
          </div>
          <div className={activeTab === 'radio' ? 'flex-1 flex flex-col min-h-0' : 'hidden'}>
            <RadioTab radioStations={radioStations} themeStyles={themeStyles} t={t} />
          </div>
          <div className={activeTab === 'settings' ? 'flex-1 flex flex-col min-h-0' : 'hidden'}>
            <SettingsTab settings={settings} setSettings={setSettings} reciters={reciters} surahs={surahs} themeStyles={themeStyles} t={t} />
          </div>
        </div>

        {/* Native Bottom Tab Navigation Bar */}
        <nav
          aria-label="التنقل الرئيسي"
          className={`${themeStyles.surfaceBg} border-t ${themeStyles.border} px-1 pt-1 pb-[max(0.35rem,env(safe-area-inset-bottom))] grid grid-cols-6 items-center shrink-0 z-30 backdrop-blur-md transition-colors duration-300`}
        >
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`min-h-[48px] flex flex-col items-center justify-center gap-0.5 rounded-xl px-1 py-1 transition-colors ${
                  isActive
                    ? `${themeStyles.accentText} font-bold`
                    : `${themeStyles.textSecondary} hover:opacity-85`
                }`}
              >
                <div
                  className={`px-2.5 py-0.5 rounded-full transition-colors ${
                    isActive ? themeStyles.accentSoftBg : 'bg-transparent'
                  }`}
                >
                  {item.icon}
                </div>
                <span className="text-[10px] font-cairo whitespace-nowrap truncate max-w-full">
                  {item.label}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};

export const MobileFrame: React.FC<MobileFrameProps> = (props) => {
  return (
    <SmartPauseProvider smartPauseEnabled={props.settings.smartPauseEnabled}>
      <MobileAppShellContent {...props} />
    </SmartPauseProvider>
  );
};
