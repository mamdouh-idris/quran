import React, { useEffect, useMemo, useRef, useState } from 'react';
import DeviceOrientationPkg, {
  DeviceOrientationProps,
  DeviceOrientationState,
} from 'react-device-orientation';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Compass,
  HelpCircle,
  Locate,
  RotateCw,
  ShieldCheck,
  SlidersHorizontal,
  Vibrate,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { AppLanguage } from '../types';
import { ThemeStyles } from '../utils/theme';
import { Translations } from '../utils/i18n';
import { calculateQiblaInfo } from '../utils/prayerMath';
import {
  Vec3,
  advanceUnwrappedRotation,
  assessMagneticField,
  assessTiltLevel,
  circularLowPassFilter,
  computeTiltCompensatedHeading,
  estimateMagneticDeclination,
  getScreenOrientationOffset,
  normalizeAngle360,
  playQiblaAlignChime,
  quaternionToCompassHeading,
  shortestAngleDiff,
  triggerQiblaHaptic,
  unlockQiblaAudio,
} from '../utils/qiblaSensor';
import { QiblaMapOverlay } from './QiblaMapOverlay';

const FallbackDeviceOrientation: React.FC<DeviceOrientationProps> = ({ children }) => {
  const [orientation, setOrientation] = useState<DeviceOrientationState>({
    absolute: false,
    alpha: null,
    beta: null,
    gamma: null,
  });

  useEffect(() => {
    const handler = (event: DeviceOrientationEvent) => {
      setOrientation({
        absolute: event.absolute,
        alpha: event.alpha,
        beta: event.beta,
        gamma: event.gamma,
      });
    };
    window.addEventListener('deviceorientation', handler, true);
    return () => window.removeEventListener('deviceorientation', handler, true);
  }, []);

  return <>{children(orientation)}</>;
};

const unwrapDeviceOrientation = (mod: unknown): React.ComponentType<DeviceOrientationProps> => {
  if (typeof mod === 'function') return mod as React.ComponentType<DeviceOrientationProps>;
  if (mod && typeof mod === 'object') {
    const first = (mod as { default?: unknown }).default;
    if (typeof first === 'function') return first as React.ComponentType<DeviceOrientationProps>;
    if (first && typeof first === 'object') {
      const second = (first as { default?: unknown }).default;
      if (typeof second === 'function') return second as React.ComponentType<DeviceOrientationProps>;
    }
  }
  return FallbackDeviceOrientation;
};

const SafeDeviceOrientation = unwrapDeviceOrientation(DeviceOrientationPkg);

export type CalibrationAlgorithm = 'standard' | 'gyro' | 'magnetic';
export type DialSkin = 'classic' | 'royal' | 'ottoman';
export type GeoPermissionState = 'prompt' | 'granted' | 'denied' | 'unsupported';
export type SensorSourceType =
  | 'manual'
  | 'orientation'
  | 'absolute_orientation'
  | 'magnetometer'
  | 'fusion_3d';

const MANUAL_OFFSET_STORAGE_KEY = 'rafiq_qibla_manual_offset';
const ALERT_PREFS_STORAGE_KEY = 'rafiq_qibla_alert_prefs';

interface QiblaAlertPrefs {
  vibration: boolean;
  sound: boolean;
}

function loadAlertPrefs(): QiblaAlertPrefs {
  try {
    const raw = localStorage.getItem(ALERT_PREFS_STORAGE_KEY);
    if (!raw) return { vibration: true, sound: true };
    const parsed = JSON.parse(raw) as Partial<QiblaAlertPrefs>;
    return {
      vibration: typeof parsed.vibration === 'boolean' ? parsed.vibration : true,
      sound: typeof parsed.sound === 'boolean' ? parsed.sound : true,
    };
  } catch {
    return { vibration: true, sound: true };
  }
}

interface QiblaCompassProps {
  lat: number;
  lng: number;
  locationLabel: string;
  locationStatus: string;
  isLocating: boolean;
  onRequestGps: () => void;
  onBackToSchedule: () => void;
  language?: AppLanguage;
  themeStyles: ThemeStyles;
  t: Translations;
}

const DIAL_SKINS: Array<{
  id: DialSkin;
  label: string;
  outerRing: string;
  faceBg: string;
  tickColor: string;
  accentColor: string;
  textColor: string;
}> = [
  {
    id: 'classic',
    label: 'ذهبي كلاسيكي',
    outerRing: '#d4a024',
    faceBg: '#fdf8ec',
    tickColor: '#8b6f35',
    accentColor: '#16a34a',
    textColor: '#423315',
  },
  {
    id: 'royal',
    label: 'أزرق ملكي',
    outerRing: '#2563eb',
    faceBg: '#0f2347',
    tickColor: '#93c5fd',
    accentColor: '#facc15',
    textColor: '#eff6ff',
  },
  {
    id: 'ottoman',
    label: 'عثماني قرمزي',
    outerRing: '#b91c1c',
    faceBg: '#3b0d14',
    tickColor: '#fca5a5',
    accentColor: '#fbbf24',
    textColor: '#fef2f2',
  },
];

interface GenericSensorLike {
  x?: number;
  y?: number;
  z?: number;
  quaternion?: [number, number, number, number];
  start: () => void;
  stop: () => void;
  addEventListener: (type: string, listener: EventListener) => void;
  removeEventListener: (type: string, listener: EventListener) => void;
}

export const QiblaCompass: React.FC<QiblaCompassProps> = ({
  lat,
  lng,
  locationLabel,
  locationStatus,
  isLocating,
  onRequestGps,
  onBackToSchedule,
  language = 'ar',
  themeStyles,
  t,
}) => {
  const [dialSkin, setDialSkin] = useState<DialSkin>('classic');
  const [showFixModal, setShowFixModal] = useState(false);

  // Calibration & fine-tuning state
  const [calibrationCount, setCalibrationCount] = useState<number>(0);
  const [calibrationAlgorithm, setCalibrationAlgorithm] =
    useState<CalibrationAlgorithm>('standard');
  const [calibrationOffset, setCalibrationOffset] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(MANUAL_OFFSET_STORAGE_KEY);
      const parsed = saved ? Number(saved) : 0;
      return Number.isFinite(parsed) ? Math.max(-30, Math.min(30, parsed)) : 0;
    } catch {
      return 0;
    }
  });
  const [isCalibratingPulse, setIsCalibratingPulse] = useState(false);

  // Qibla alignment alert preferences (vibration + audio chime)
  const [alertPrefs, setAlertPrefs] = useState<QiblaAlertPrefs>(() => loadAlertPrefs());
  const [lockFlashActive, setLockFlashActive] = useState(false);

  // Geolocation permission tracking
  const [geoPermission, setGeoPermission] = useState<GeoPermissionState>('prompt');

  // Hardware sensor states
  const [magnetometerVector, setMagnetometerVector] = useState<Vec3 | null>(null);
  const [accelVector, setAccelVector] = useState<Vec3 | null>(null);
  const [fusionQuaternionHeading, setFusionQuaternionHeading] = useState<number | null>(null);
  const [osCompassHeading, setOsCompassHeading] = useState<number | null>(null);
  const [osOrientationIsAbsolute, setOsOrientationIsAbsolute] = useState<boolean>(false);
  const [liveTilt, setLiveTilt] = useState<{ beta: number | null; gamma: number | null }>({
    beta: null,
    gamma: null,
  });

  const [manualHeading, setManualHeading] = useState<number>(0);
  const [filteredHeading, setFilteredHeading] = useState<number>(0);
  const [visualDialRotation, setVisualDialRotation] = useState<number>(0);
  const [sensorSource, setSensorSource] = useState<SensorSourceType>('manual');
  const [sensorPermissionGranted, setSensorPermissionGranted] = useState<boolean>(false);
  const [screenAngle, setScreenAngle] = useState<number>(() => getScreenOrientationOffset());

  const accelRef = useRef<Vec3 | null>(null);
  const liveTiltRef = useRef<{ beta: number | null; gamma: number | null }>({
    beta: null,
    gamma: null,
  });
  const filteredHeadingRef = useRef<number>(0);
  const visualDialRotationRef = useRef<number>(0);
  const dialDragRef = useRef<{ dragging: boolean; startAngle: number; startHeading: number }>({
    dragging: false,
    startAngle: 0,
    startHeading: 0,
  });
  const dialBoxRef = useRef<HTMLDivElement | null>(null);
  const lastAlertTimestampRef = useRef<number>(0);
  const wasAlignedRef = useRef<boolean>(false);

  const qiblaInfo = useMemo(() => calculateQiblaInfo(lat, lng), [lat, lng]);
  const magneticDeclination = useMemo(() => estimateMagneticDeclination(lat, lng), [lat, lng]);

  // Persist user fine-tuning offset and alert preferences
  useEffect(() => {
    try {
      localStorage.setItem(MANUAL_OFFSET_STORAGE_KEY, String(calibrationOffset));
    } catch {
      // ignore storage quota errors
    }
  }, [calibrationOffset]);

  useEffect(() => {
    try {
      localStorage.setItem(ALERT_PREFS_STORAGE_KEY, JSON.stringify(alertPrefs));
    } catch {
      // ignore storage quota errors
    }
  }, [alertPrefs]);

  // Track screen orientation changes (0, 90, 180, 270 deg)
  useEffect(() => {
    const updateAngle = () => setScreenAngle(getScreenOrientationOffset());
    window.addEventListener('orientationchange', updateAngle);
    window.screen?.orientation?.addEventListener?.('change', updateAngle);
    return () => {
      window.removeEventListener('orientationchange', updateAngle);
      window.screen?.orientation?.removeEventListener?.('change', updateAngle);
    };
  }, []);

  // Monitor Geolocation permission state
  useEffect(() => {
    if (!('geolocation' in navigator)) {
      setGeoPermission('unsupported');
      return;
    }
    if ('permissions' in navigator && typeof navigator.permissions.query === 'function') {
      let statusObj: PermissionStatus | null = null;
      const updatePerm = () => {
        if (statusObj) {
          setGeoPermission(statusObj.state as GeoPermissionState);
        }
      };
      navigator.permissions
        .query({ name: 'geolocation' })
        .then((status) => {
          statusObj = status;
          setGeoPermission(status.state as GeoPermissionState);
          status.addEventListener('change', updatePerm);
        })
        .catch(() => {
          // Permissions API unavailable for geolocation
        });

      return () => {
        if (statusObj) {
          statusObj.removeEventListener('change', updatePerm);
        }
      };
    }
  }, []);

  // Multi-sensor initialization:
  // 1) AbsoluteOrientationSensor (3D fused tilt-compensated quaternion)
  // 2) Accelerometer + Magnetometer (3D cross-product tilt compensation)
  // 3) iOS webkitCompassHeading / Android deviceorientationabsolute / deviceorientation
  useEffect(() => {
    let absSensor: GenericSensorLike | null = null;
    let accelSensor: GenericSensorLike | null = null;
    let magSensor: GenericSensorLike | null = null;

    const win = window as unknown as {
      AbsoluteOrientationSensor?: new (opts?: { frequency?: number; referenceFrame?: string }) => GenericSensorLike;
      Accelerometer?: new (opts?: { frequency?: number }) => GenericSensorLike;
      Magnetometer?: new (opts?: { frequency?: number }) => GenericSensorLike;
    };

    if (typeof win.AbsoluteOrientationSensor === 'function') {
      try {
        absSensor = new win.AbsoluteOrientationSensor({ frequency: 30, referenceFrame: 'device' });
        const handleAbsReading = () => {
          if (absSensor?.quaternion && absSensor.quaternion.length === 4) {
            const q = absSensor.quaternion;
            const heading = quaternionToCompassHeading(q);
            setFusionQuaternionHeading(heading);
            setSensorSource('fusion_3d');
          }
        };
        absSensor.addEventListener('reading', handleAbsReading);
        absSensor.addEventListener('error', () => {
          // Falls back cleanly to Magnetometer or DeviceOrientation
        });
        absSensor.start();
      } catch {
        // Blocked or unsupported; continue with fallback sensors
      }
    }

    if (typeof win.Accelerometer === 'function') {
      try {
        accelSensor = new win.Accelerometer({ frequency: 30 });
        const handleAccelReading = () => {
          if (
            accelSensor &&
            typeof accelSensor.x === 'number' &&
            typeof accelSensor.y === 'number' &&
            typeof accelSensor.z === 'number'
          ) {
            const vec = { x: accelSensor.x, y: accelSensor.y, z: accelSensor.z };
            accelRef.current = vec;
            setAccelVector(vec);
          }
        };
        accelSensor.addEventListener('reading', handleAccelReading);
        accelSensor.addEventListener('error', () => {});
        accelSensor.start();
      } catch {
        // Ignore if unavailable
      }
    }

    if (typeof win.Magnetometer === 'function') {
      try {
        magSensor = new win.Magnetometer({ frequency: 25 });
        const handleMagReading = () => {
          if (
            magSensor &&
            typeof magSensor.x === 'number' &&
            typeof magSensor.y === 'number' &&
            typeof magSensor.z === 'number'
          ) {
            const vec = { x: magSensor.x, y: magSensor.y, z: magSensor.z };
            setMagnetometerVector(vec);
            setSensorSource((prev) => (prev === 'fusion_3d' ? prev : 'magnetometer'));
          }
        };
        magSensor.addEventListener('reading', handleMagReading);
        magSensor.addEventListener('error', () => {});
        magSensor.start();
      } catch {
        // Sensor blocked or requires user gesture; fallback continues via DeviceOrientation
      }
    }

    const handleDeviceOrientation = (event: Event) => {
      const evt = event as DeviceOrientationEvent & { webkitCompassHeading?: number };
      const beta = typeof evt.beta === 'number' && !Number.isNaN(evt.beta) ? evt.beta : null;
      const gamma = typeof evt.gamma === 'number' && !Number.isNaN(evt.gamma) ? evt.gamma : null;

      if (beta !== null || gamma !== null) {
        liveTiltRef.current = { beta, gamma };
        setLiveTilt({ beta, gamma });
      }

      if (typeof evt.webkitCompassHeading === 'number' && !Number.isNaN(evt.webkitCompassHeading)) {
        setOsCompassHeading(normalizeAngle360(evt.webkitCompassHeading));
        setOsOrientationIsAbsolute(true);
        setSensorSource((prev) =>
          prev === 'fusion_3d' || prev === 'magnetometer' ? prev : 'absolute_orientation'
        );
        return;
      }

      if (typeof evt.alpha === 'number' && !Number.isNaN(evt.alpha)) {
        const isAllZeroGhost = evt.alpha === 0 && (beta ?? 0) === 0 && (gamma ?? 0) === 0;
        if (isAllZeroGhost) return;

        const heading = normalizeAngle360(360 - evt.alpha);
        if (event.type === 'deviceorientationabsolute' || evt.absolute) {
          setOsCompassHeading(heading);
          setOsOrientationIsAbsolute(true);
          setSensorSource((prev) =>
            prev === 'fusion_3d' || prev === 'magnetometer' ? prev : 'absolute_orientation'
          );
        } else {
          setOsCompassHeading(heading);
          setOsOrientationIsAbsolute(false);
          setSensorSource((prev) => (prev === 'manual' ? 'orientation' : prev));
        }
      }
    };

    window.addEventListener('deviceorientationabsolute', handleDeviceOrientation, true);
    window.addEventListener('deviceorientation', handleDeviceOrientation, true);

    return () => {
      [absSensor, accelSensor, magSensor].forEach((sensor) => {
        if (sensor) {
          try {
            sensor.stop();
          } catch {
            // ignore
          }
        }
      });
      window.removeEventListener('deviceorientationabsolute', handleDeviceOrientation, true);
      window.removeEventListener('deviceorientation', handleDeviceOrientation, true);
    };
  }, []);

  // Compute tilt-compensated magnetic heading from latest Magnetometer + Accelerometer / beta-gamma
  const magneticTiltHeading = useMemo(() => {
    if (!magnetometerVector) return null;
    const magBearing = computeTiltCompensatedHeading(
      magnetometerVector,
      accelVector,
      liveTilt.beta,
      liveTilt.gamma
    );
    // Apply True North geomagnetic declination adjustment
    return normalizeAngle360(magBearing + magneticDeclination);
  }, [magnetometerVector, accelVector, liveTilt.beta, liveTilt.gamma, magneticDeclination]);

  // Select best available sensor reading according to algorithm & priority
  const targetRawHeading = useMemo(() => {
    if (sensorSource === 'manual') {
      return manualHeading;
    }

    let baseHeading: number | null = null;

    if (calibrationAlgorithm === 'magnetic') {
      baseHeading =
        magneticTiltHeading ??
        fusionQuaternionHeading ??
        (osCompassHeading !== null
          ? normalizeAngle360(osCompassHeading + (osOrientationIsAbsolute ? 0 : magneticDeclination))
          : null);
    } else {
      baseHeading =
        fusionQuaternionHeading ??
        (osOrientationIsAbsolute ? osCompassHeading : null) ??
        magneticTiltHeading ??
        osCompassHeading;
    }

    if (baseHeading === null) {
      return manualHeading;
    }

    return normalizeAngle360(baseHeading + screenAngle);
  }, [
    sensorSource,
    manualHeading,
    calibrationAlgorithm,
    magneticTiltHeading,
    fusionQuaternionHeading,
    osCompassHeading,
    osOrientationIsAbsolute,
    magneticDeclination,
    screenAngle,
  ]);

  // Apply circular low-pass smoothing and continuous 360°-unwrapped CSS dial rotation cleanly inside useEffect
  useEffect(() => {
    const withOffset = normalizeAngle360(targetRawHeading + calibrationOffset);

    if (sensorSource === 'manual') {
      filteredHeadingRef.current = withOffset;
      setFilteredHeading(withOffset);
      const nextVisual = advanceUnwrappedRotation(visualDialRotationRef.current, -withOffset);
      visualDialRotationRef.current = nextVisual;
      setVisualDialRotation(nextVisual);
      return;
    }

    const alpha =
      calibrationAlgorithm === 'gyro' ? 0.16 : calibrationAlgorithm === 'magnetic' ? 0.25 : 0.35;

    const smoothed = circularLowPassFilter(filteredHeadingRef.current, withOffset, alpha);
    filteredHeadingRef.current = smoothed;
    setFilteredHeading(smoothed);

    const nextVisual = advanceUnwrappedRotation(visualDialRotationRef.current, -smoothed);
    visualDialRotationRef.current = nextVisual;
    setVisualDialRotation(nextVisual);
  }, [targetRawHeading, calibrationOffset, calibrationAlgorithm, sensorSource]);

  const effectiveHeading = filteredHeading;
  const deltaToQibla = shortestAngleDiff(qiblaInfo.bearing, effectiveHeading);
  const absDeltaToQibla = Math.abs(deltaToQibla);
  const isFacingQibla = absDeltaToQibla <= 5;

  // Sensor-driven haptic vibration + audio chime on entering Qibla alignment
  // Uses hysteresis (enter <= 5°, exit > 8°) and cooldown (1800ms) to prevent jitter chatter.
  useEffect(() => {
    let flashTimer: number | undefined;

    if (absDeltaToQibla <= 5 && !wasAlignedRef.current) {
      wasAlignedRef.current = true;
      const now = Date.now();
      if (now - lastAlertTimestampRef.current >= 1800) {
        lastAlertTimestampRef.current = now;
        if (alertPrefs.vibration) {
          triggerQiblaHaptic();
        }
        if (alertPrefs.sound) {
          playQiblaAlignChime();
        }
        setLockFlashActive(true);
        flashTimer = window.setTimeout(() => setLockFlashActive(false), 1100);
      }
    } else if (absDeltaToQibla > 8) {
      wasAlignedRef.current = false;
    }

    return () => {
      if (flashTimer !== undefined) {
        window.clearTimeout(flashTimer);
      }
    };
  }, [absDeltaToQibla, alertPrefs.vibration, alertPrefs.sound]);

  const toggleVibrationAlert = () => {
    unlockQiblaAudio();
    setAlertPrefs((prev) => {
      const next = !prev.vibration;
      if (next) triggerQiblaHaptic();
      return { ...prev, vibration: next };
    });
  };

  const toggleSoundAlert = () => {
    unlockQiblaAudio();
    setAlertPrefs((prev) => {
      const next = !prev.sound;
      if (next) playQiblaAlignChime();
      return { ...prev, sound: next };
    });
  };

  // Request GPS geolocation + iOS Motion/Orientation permissions + unlock audio context
  const enableSensorsAndGps = async () => {
    unlockQiblaAudio();
    onRequestGps();

    try {
      const devOrient = DeviceOrientationEvent as unknown as {
        requestPermission?: () => Promise<'granted' | 'denied'>;
      };
      const devMotion = DeviceMotionEvent as unknown as {
        requestPermission?: () => Promise<'granted' | 'denied'>;
      };
      let granted = true;
      if (typeof devOrient?.requestPermission === 'function') {
        const res = await devOrient.requestPermission();
        granted = granted && res === 'granted';
      }
      if (typeof devMotion?.requestPermission === 'function') {
        const res = await devMotion.requestPermission();
        granted = granted && res === 'granted';
      }
      setSensorPermissionGranted(granted);
    } catch {
      // Ignore on browsers that do not implement requestPermission
    }
  };

  // Interactive pointer drag on compass dial (for desktop & manual inspection)
  const getPointerAngle = (clientX: number, clientY: number): number => {
    if (!dialBoxRef.current) return 0;
    const rect = dialBoxRef.current.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    return (Math.atan2(clientY - cy, clientX - cx) * 180) / Math.PI;
  };

  const handleDialPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    unlockQiblaAudio();
    dialDragRef.current = {
      dragging: true,
      startAngle: getPointerAngle(e.clientX, e.clientY),
      startHeading: effectiveHeading,
    };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handleDialPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dialDragRef.current.dragging) return;
    const currentAngle = getPointerAngle(e.clientX, e.clientY);
    const delta = currentAngle - dialDragRef.current.startAngle;
    const nextHeading = normalizeAngle360(dialDragRef.current.startHeading - delta);
    setSensorSource('manual');
    setManualHeading(normalizeAngle360(nextHeading - calibrationOffset));
  };

  const handleDialPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dialDragRef.current.dragging) {
      dialDragRef.current.dragging = false;
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    }
  };

  const handleCalibrateStep = () => {
    setCalibrationCount((prev) => prev + 1);
    setIsCalibratingPulse(true);
    // Reset smoothing lock to immediate current raw sensor reading to flush lag
    const snap = normalizeAngle360(targetRawHeading + calibrationOffset);
    filteredHeadingRef.current = snap;
    setFilteredHeading(snap);
    const nextVisual = advanceUnwrappedRotation(visualDialRotationRef.current, -snap);
    visualDialRotationRef.current = nextVisual;
    setVisualDialRotation(nextVisual);

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(20);
      } catch {
        // ignore
      }
    }
    setTimeout(() => setIsCalibratingPulse(false), 650);
  };

  const handleRecalibrateReset = () => {
    setCalibrationCount(0);
    setCalibrationOffset(0);
    setCalibrationAlgorithm('standard');
    setManualHeading(0);
    if (fusionQuaternionHeading !== null) {
      setSensorSource('fusion_3d');
    } else if (osOrientationIsAbsolute) {
      setSensorSource('absolute_orientation');
    } else if (magnetometerVector !== null) {
      setSensorSource('magnetometer');
    }
  };

  const activeSkin = DIAL_SKINS.find((s) => s.id === dialSkin) || DIAL_SKINS[0];
  const magneticField = useMemo(() => assessMagneticField(magnetometerVector), [magnetometerVector]);
  const tiltStatus = useMemo(
    () => assessTiltLevel(liveTilt.beta, liveTilt.gamma),
    [liveTilt.beta, liveTilt.gamma]
  );

  const sensorSourceLabel = useMemo(() => {
    switch (sensorSource) {
      case 'fusion_3d':
        return 'مستشعر مدمج 3D (AbsoluteOrientation)';
      case 'absolute_orientation':
        return 'البوصلة المطلقة (True North)';
      case 'magnetometer':
        return 'مغناطيسي مصحح الميل';
      case 'orientation':
        return 'مستشعر الاتجاه (نسبي)';
      default:
        return t.manualRotateHint;
    }
  }, [sensorSource, t.manualRotateHint]);

  return (
    <SafeDeviceOrientation>
      {({ alpha, beta, gamma }) => {
        // Sync passive react-device-orientation stream only if user isn't dragging manually
        const hasFallbackStream =
          typeof alpha === 'number' &&
          !Number.isNaN(alpha) &&
          !(alpha === 0 && (beta ?? 0) === 0 && (gamma ?? 0) === 0);

        return (
          <div className="flex flex-col space-y-3">
            {/* Top Bar */}
            <div className="flex items-center justify-between px-1">
              <button
                onClick={onBackToSchedule}
                className={`min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl ${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} border ${themeStyles.border} hover:opacity-80 transition-opacity`}
                title={t.prayerScheduleTab}
              >
                <ChevronRight className="w-5 h-5" />
              </button>

              <h2 className={`text-base font-bold font-amiri ${themeStyles.accentText}`}>
                {t.qiblaTitle}
              </h2>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setShowFixModal(true)}
                  className={`min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} hover:opacity-80 transition-opacity`}
                  title={t.fixQiblaTitle}
                  aria-label={t.fixQiblaTitle}
                >
                  <HelpCircle className="w-4 h-4" />
                </button>
                <button
                  onClick={enableSensorsAndGps}
                  disabled={isLocating}
                  className={`min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl ${themeStyles.accentBg} shadow-sm transition-opacity`}
                  title={t.enableGps}
                  aria-label={t.enableGps}
                >
                  <Locate className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>

            {/* Geolocation Permission Banner (when prompt or denied) */}
            {geoPermission !== 'granted' && (
              <div
                className={`${themeStyles.cardBg} border ${
                  geoPermission === 'denied' ? 'border-amber-500/50' : themeStyles.accentBorder
                } rounded-2xl p-3 flex items-center justify-between gap-2 text-xs`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  {geoPermission === 'denied' ? (
                    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                  ) : (
                    <ShieldCheck className={`w-4 h-4 ${themeStyles.accentText} shrink-0`} />
                  )}
                  <span className={`${themeStyles.textPrimary} truncate`}>
                    {geoPermission === 'denied'
                      ? 'إذن الموقع مرفوض؛ يتم الحساب بالمدينة المختارة'
                      : 'فعّل إذن الموقع GPS ومستشعر الاتجاه لدقة القبلة'}
                  </span>
                </div>
                <button
                  onClick={enableSensorsAndGps}
                  disabled={isLocating}
                  className={`px-3 py-1.5 rounded-xl text-[11px] font-bold shrink-0 ${themeStyles.accentBg}`}
                >
                  {isLocating ? '...' : t.enableGps}
                </button>
              </div>
            )}

            {/* Magnetic Interference Warning (if nearby metal/speaker distorts readings) */}
            {magneticField.quality === 'interference' && (
              <div className="bg-amber-500/10 border border-amber-500/40 rounded-2xl px-3 py-2 flex items-center justify-between gap-2 text-[11px] text-amber-500">
                <div className="flex items-center gap-2 min-w-0">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span className="truncate font-semibold">
                    تشويش مغناطيسي ({magneticField.magnitudeUt} µT) — حرك الهاتف بشكل ∞ لمعايرة الحساس
                  </span>
                </div>
                <button
                  onClick={() => setShowFixModal(true)}
                  className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold shrink-0"
                >
                  معايرة
                </button>
              </div>
            )}

            {/* Interactive Google Maps Qibla Line-of-Sight Overlay */}
            <QiblaMapOverlay
              lat={lat}
              lng={lng}
              locationLabel={locationLabel}
              effectiveHeading={effectiveHeading}
              qiblaBearing={qiblaInfo.bearing}
              distanceKm={qiblaInfo.distanceKm}
              isFacingQibla={isFacingQibla}
              isLocating={isLocating}
              onRequestGps={enableSensorsAndGps}
              language={language}
              themeStyles={themeStyles}
              t={t}
            />

            {/* Compass Dial Theme Selector, Alert Toggles & Sensor Processor Button */}
            <div className="flex items-center justify-between gap-2 px-1">
              <div
                className={`flex items-center gap-1.5 ${themeStyles.subSurfaceBg} p-1.5 rounded-2xl border ${themeStyles.border}`}
              >
                {DIAL_SKINS.map((skin) => {
                  const active = dialSkin === skin.id;
                  return (
                    <button
                      key={skin.id}
                      onClick={() => setDialSkin(skin.id)}
                      title={skin.label}
                      aria-label={skin.label}
                      className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-transform ${
                        active
                          ? 'scale-110 ring-2 ring-emerald-500 shadow-md'
                          : 'opacity-75 hover:opacity-100'
                      }`}
                      style={{
                        backgroundColor: skin.faceBg,
                        borderColor: skin.outerRing,
                      }}
                    >
                      <div
                        className="w-3.5 h-3.5 rounded-full border"
                        style={{ borderColor: skin.accentColor, backgroundColor: skin.outerRing }}
                      />
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={toggleVibrationAlert}
                  title={alertPrefs.vibration ? 'إيقاف الاهتزاز عند القبلة' : 'تفعيل الاهتزاز عند القبلة'}
                  aria-label="تبديل الاهتزاز عند القبلة"
                  className={`min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border transition-all ${
                    alertPrefs.vibration
                      ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-500'
                      : `${themeStyles.subSurfaceBg} ${themeStyles.border} ${themeStyles.textSecondary} opacity-65`
                  }`}
                >
                  <Vibrate className="w-4 h-4" />
                </button>

                <button
                  onClick={toggleSoundAlert}
                  title={alertPrefs.sound ? 'إيقاف النغمة عند القبلة' : 'تفعيل النغمة عند القبلة'}
                  aria-label="تبديل النغمة عند القبلة"
                  className={`min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border transition-all ${
                    alertPrefs.sound
                      ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-500'
                      : `${themeStyles.subSurfaceBg} ${themeStyles.border} ${themeStyles.textSecondary} opacity-65`
                  }`}
                >
                  {alertPrefs.sound ? (
                    <Volume2 className="w-4 h-4" />
                  ) : (
                    <VolumeX className="w-4 h-4" />
                  )}
                </button>

                <button
                  onClick={() => setShowFixModal(true)}
                  className={`min-h-[38px] px-2.5 py-2 rounded-xl text-[11px] font-bold flex items-center gap-1 ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} hover:opacity-90 transition-opacity`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>معايرة</span>
                </button>
              </div>
            </div>

            {/* Main Working Rotating Qibla Compass */}
            <div
              className={`${themeStyles.cardBg} rounded-3xl border ${themeStyles.border} p-4 flex flex-col items-center space-y-3 shadow-sm`}
            >
              {/* Bearing & Live Leveling Indicator Row */}
              <div className="w-full flex items-center justify-between gap-2 px-1">
                {/* Spirit Level Bubble */}
                <div
                  className={`flex items-center gap-1.5 px-2 py-1 rounded-xl border text-[10px] font-semibold ${
                    tiltStatus.isLevel
                      ? 'border-emerald-500/35 bg-emerald-500/10 text-emerald-500'
                      : 'border-amber-500/35 bg-amber-500/10 text-amber-500'
                  }`}
                  title="ميزان الاستواء: ثبّت الهاتف أفقياً لدقة أكبر"
                >
                  <div className="relative w-5 h-5 rounded-full border border-current/40 flex items-center justify-center overflow-hidden">
                    <div
                      className="w-2 h-2 rounded-full bg-current transition-transform duration-100"
                      style={{
                        transform: `translate(${tiltStatus.bubbleX * 5}px, ${tiltStatus.bubbleY * 5}px)`,
                      }}
                    />
                  </div>
                  <span className="tabular-nums">
                    {tiltStatus.isLevel ? 'مستوٍ' : `ميل ${tiltStatus.tiltDeg}°`}
                  </span>
                </div>

                {/* Alignment Status */}
                {isFacingQibla ? (
                  <div className="flex items-center gap-1 text-xs font-bold text-emerald-500">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{t.facingQiblaNow}</span>
                  </div>
                ) : (
                  <div className={`text-xs font-semibold ${themeStyles.textSecondary} tabular-nums`}>
                    {t.qiblaTitle}:{' '}
                    <span className={`font-bold ${themeStyles.accentText}`}>{qiblaInfo.bearing}°</span>
                    <span className="mx-1">·</span>
                    <span>{Math.round(effectiveHeading)}°</span>
                  </div>
                )}

                {/* Declination Badge */}
                <div
                  className={`px-2 py-1 rounded-xl ${themeStyles.subSurfaceBg} border ${themeStyles.border} text-[10px] ${themeStyles.textSecondary} tabular-nums`}
                  title="الإنحراف المغناطيسي المحسوب آلياً لموقعك"
                >
                  {magneticDeclination >= 0 ? `+${magneticDeclination}` : magneticDeclination}°
                </div>
              </div>

              {/* Alignment Pointer */}
              <div
                className={`w-0 h-0 border-l-[8px] border-r-[8px] border-t-[12px] border-l-transparent border-r-transparent transition-colors ${
                  isFacingQibla ? 'border-t-emerald-500 scale-125' : 'border-t-amber-500'
                }`}
              />

              {/* Smooth Unwrapped Rotating Dial */}
              <div
                ref={dialBoxRef}
                onPointerDown={handleDialPointerDown}
                onPointerMove={handleDialPointerMove}
                onPointerUp={handleDialPointerUp}
                onPointerCancel={handleDialPointerUp}
                className={`relative w-60 h-60 rounded-full flex items-center justify-center cursor-grab active:cursor-grabbing select-none touch-none transition-all duration-200 ${
                  lockFlashActive
                    ? 'ring-4 ring-emerald-400 scale-[1.02] shadow-2xl shadow-emerald-500/40'
                    : isFacingQibla
                    ? 'ring-4 ring-emerald-500/50 shadow-xl shadow-emerald-500/20'
                    : isCalibratingPulse
                    ? 'ring-4 ring-amber-400/60 shadow-lg'
                    : 'shadow-lg'
                }`}
                style={{
                  background: activeSkin.outerRing,
                  padding: '10px',
                }}
              >
                <div
                  className="w-full h-full rounded-full relative flex items-center justify-center transition-transform duration-100 ease-out will-change-transform"
                  style={{
                    transform: `rotate(${visualDialRotation}deg)`,
                    backgroundColor: activeSkin.faceBg,
                  }}
                >
                  <svg viewBox="0 0 220 220" className="w-full h-full">
                    <circle
                      cx="110"
                      cy="110"
                      r="105"
                      fill="none"
                      stroke={activeSkin.outerRing}
                      strokeWidth="2"
                      opacity="0.45"
                    />
                    <circle
                      cx="110"
                      cy="110"
                      r="76"
                      fill="none"
                      stroke={activeSkin.outerRing}
                      strokeWidth="1.2"
                      strokeDasharray="3 3"
                      opacity="0.5"
                    />
                    <circle
                      cx="110"
                      cy="110"
                      r="50"
                      fill="none"
                      stroke={activeSkin.accentColor}
                      strokeWidth="1"
                      opacity="0.35"
                    />

                    {Array.from({ length: 72 }).map((_, i) => {
                      const deg = i * 5;
                      const isMajor = deg % 30 === 0;
                      const isMid = deg % 15 === 0 && !isMajor;
                      const len = isMajor ? 10 : isMid ? 6.5 : 3.5;
                      return (
                        <line
                          key={deg}
                          x1="110"
                          y1="5"
                          x2="110"
                          y2={5 + len}
                          stroke={deg === 0 ? '#dc2626' : activeSkin.tickColor}
                          strokeWidth={isMajor ? '2' : '1'}
                          transform={`rotate(${deg} 110 110)`}
                        />
                      );
                    })}

                    <text x="110" y="29" textAnchor="middle" fill="#dc2626" fontSize="13" fontWeight="bold">
                      N
                    </text>
                    <text x="193" y="114" textAnchor="middle" fill={activeSkin.textColor} fontSize="11" fontWeight="bold">
                      E
                    </text>
                    <text x="110" y="200" textAnchor="middle" fill={activeSkin.textColor} fontSize="11" fontWeight="bold">
                      S
                    </text>
                    <text x="27" y="114" textAnchor="middle" fill={activeSkin.textColor} fontSize="11" fontWeight="bold">
                      W
                    </text>

                    <g transform={`rotate(${qiblaInfo.bearing} 110 110)`}>
                      <line
                        x1="110"
                        y1="110"
                        x2="110"
                        y2="34"
                        stroke={isFacingQibla ? '#16a34a' : activeSkin.accentColor}
                        strokeWidth="3.5"
                        strokeLinecap="round"
                      />
                      <line
                        x1="110"
                        y1="110"
                        x2="110"
                        y2="146"
                        stroke={activeSkin.tickColor}
                        strokeWidth="2"
                        opacity="0.55"
                        strokeLinecap="round"
                      />
                      <polygon
                        points="110,18 103,35 117,35"
                        fill={isFacingQibla ? '#16a34a' : activeSkin.accentColor}
                      />
                      <g transform="translate(99, 44)">
                        <rect width="22" height="22" rx="3" fill="#18181b" stroke="#facc15" strokeWidth="1.5" />
                        <line x1="2" y1="7" x2="20" y2="7" stroke="#facc15" strokeWidth="2.5" />
                      </g>
                    </g>

                    <circle cx="110" cy="110" r="8" fill={activeSkin.outerRing} />
                    <circle cx="110" cy="110" r="3.5" fill="#ffffff" />
                  </svg>
                </div>
              </div>

              {/* Manual Rotation Slider & Active Sensor Readout */}
              <div className="w-full space-y-1 pt-1">
                <div className={`flex items-center justify-between text-[11px] ${themeStyles.textSecondary}`}>
                  <span className="flex items-center gap-1 min-w-0">
                    <Compass className={`w-3.5 h-3.5 shrink-0 ${themeStyles.accentText}`} />
                    <span className="truncate">{sensorSourceLabel}</span>
                  </span>
                  <span className="font-bold tabular-nums shrink-0">
                    {Math.round(effectiveHeading)}°
                    {calibrationOffset !== 0 && (
                      <span className="text-[10px] opacity-75">
                        {' '}
                        ({calibrationOffset > 0 ? `+${calibrationOffset}` : calibrationOffset}°)
                      </span>
                    )}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="359"
                  step="1"
                  value={Math.round(effectiveHeading)}
                  onChange={(e) => {
                    unlockQiblaAudio();
                    const v = Number(e.target.value);
                    setSensorSource('manual');
                    setManualHeading(normalizeAngle360(v - calibrationOffset));
                  }}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              {/* Sensor Diagnostics Footer */}
              <div className={`text-[10px] text-center ${themeStyles.textSecondary} tabular-nums flex flex-wrap items-center justify-center gap-x-2 gap-y-0.5`}>
                {sensorPermissionGranted && <span>تم تفعيل أذونات الحساسات ·</span>}
                {magneticField.magnitudeUt !== null && (
                  <span>المجال: {magneticField.magnitudeUt} µT ·</span>
                )}
                {hasFallbackStream && sensorSource === 'manual' && (
                  <button
                    onClick={() => setSensorSource('orientation')}
                    className={`${themeStyles.accentText} underline font-semibold`}
                  >
                    استئناف المستشعر الحي
                  </button>
                )}
                <span>{locationStatus}</span>
              </div>
            </div>

            {/* Calibration & Sensor Processor Modal Sheet ("معالجة مستشعر القبلة") */}
            {showFixModal && (
              <div className="absolute inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-end justify-center">
                <div
                  className={`w-full max-h-[85%] overflow-y-auto ${themeStyles.cardBg} border-t ${themeStyles.border} rounded-t-3xl p-5 shadow-2xl space-y-4`}
                >
                  <div className="w-10 h-1 bg-slate-400/40 rounded-full mx-auto sm:hidden" />

                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => setShowFixModal(false)}
                      className={`min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl ${themeStyles.subSurfaceBg} ${themeStyles.textSecondary}`}
                      aria-label="إغلاق"
                    >
                      <X className="w-5 h-5" />
                    </button>
                    <h3 className={`text-base font-bold ${themeStyles.textPrimary}`}>
                      {t.fixQiblaTitle}
                    </h3>
                    <div className="w-10" />
                  </div>

                  {/* Live Sensor Health Telemetry */}
                  <div className={`${themeStyles.subSurfaceBg} rounded-2xl p-3 border ${themeStyles.border} space-y-2 text-xs`}>
                    <div className="flex items-center justify-between">
                      <span className={`font-bold flex items-center gap-1.5 ${themeStyles.textPrimary}`}>
                        <Activity className={`w-4 h-4 ${themeStyles.accentText}`} />
                        <span>حالة المستشعر الحي</span>
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          sensorSource === 'manual'
                            ? 'bg-slate-500/20 text-slate-400'
                            : 'bg-emerald-500/15 text-emerald-500'
                        }`}
                      >
                        {sensorSource === 'manual' ? 'وضع يدوي' : 'مستشعر متصل'}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center pt-1 tabular-nums">
                      <div className={`${themeStyles.cardBg} rounded-xl p-2 border ${themeStyles.border}`}>
                        <div className={`text-[10px] ${themeStyles.textSecondary}`}>الانحراف</div>
                        <div className={`font-bold ${themeStyles.textPrimary}`}>
                          {magneticDeclination >= 0 ? `+${magneticDeclination}` : magneticDeclination}°
                        </div>
                      </div>
                      <div className={`${themeStyles.cardBg} rounded-xl p-2 border ${themeStyles.border}`}>
                        <div className={`text-[10px] ${themeStyles.textSecondary}`}>المجال</div>
                        <div
                          className={`font-bold ${
                            magneticField.quality === 'interference'
                              ? 'text-amber-500'
                              : themeStyles.textPrimary
                          }`}
                        >
                          {magneticField.magnitudeUt !== null ? `${magneticField.magnitudeUt} µT` : 'غير متاح'}
                        </div>
                      </div>
                      <div className={`${themeStyles.cardBg} rounded-xl p-2 border ${themeStyles.border}`}>
                        <div className={`text-[10px] ${themeStyles.textSecondary}`}>الميل</div>
                        <div
                          className={`font-bold ${
                            tiltStatus.isLevel ? 'text-emerald-500' : 'text-amber-500'
                          }`}
                        >
                          {tiltStatus.tiltDeg}°
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Step 1: Figure-8 Calibration & Filter Flush */}
                  <div className="flex items-center justify-between text-xs pt-1">
                    <span className={`font-semibold ${themeStyles.textPrimary}`}>{t.calibratePrompt}</span>
                    <button
                      onClick={handleRecalibrateReset}
                      className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold hover:opacity-80"
                    >
                      <RotateCw className="w-3.5 h-3.5" />
                      <span>{t.recalibrateBtn}</span>
                    </button>
                  </div>

                  <button
                    onClick={handleCalibrateStep}
                    className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-[0.99] text-white font-bold text-sm shadow-lg transition-all tabular-nums"
                  >
                    {t.calibrateBtn} ({calibrationCount})
                  </button>

                  {/* Step 2: Sensor Processing Mode */}
                  <div className="space-y-2 pt-1">
                    <span className={`text-xs font-semibold block ${themeStyles.textPrimary}`}>
                      {t.chooseCalibrationType}
                    </span>

                    <div className="grid grid-cols-3 gap-2">
                      {(
                        [
                          { id: 'standard', label: t.algoStandard },
                          { id: 'gyro', label: t.algoGyro },
                          { id: 'magnetic', label: t.algoMagnetic },
                        ] as const
                      ).map((algo) => {
                        const selected = calibrationAlgorithm === algo.id;
                        return (
                          <button
                            key={algo.id}
                            onClick={() => setCalibrationAlgorithm(algo.id)}
                            className={`py-3 px-2 rounded-xl text-xs font-bold border text-center transition-all min-h-[52px] flex items-center justify-center ${
                              selected
                                ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 shadow-sm'
                                : `${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                            }`}
                          >
                            {algo.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Step 3: Persistent Fine-Tune Offset (-30° to +30°) */}
                  <div className={`${themeStyles.subSurfaceBg} rounded-2xl p-3 border ${themeStyles.border} space-y-2`}>
                    <div className="flex items-center justify-between text-xs">
                      <span className={`font-semibold ${themeStyles.textPrimary}`}>
                        ضبط إزاحة البوصلة الدقيق
                      </span>
                      <span className={`font-bold tabular-nums ${themeStyles.accentText}`}>
                        {calibrationOffset > 0 ? `+${calibrationOffset}` : calibrationOffset}°
                      </span>
                    </div>
                    <input
                      type="range"
                      min="-30"
                      max="30"
                      step="1"
                      value={calibrationOffset}
                      onChange={(e) => setCalibrationOffset(Number(e.target.value))}
                      className="w-full accent-emerald-600 cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      }}
    </SafeDeviceOrientation>
  );
};
