import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  Database,
  FileText,
  HardDrive,
  RefreshCw,
  Search,
  Trash2,
  Volume2,
  AlertTriangle,
} from 'lucide-react';
import { AppLanguage, Reciter, Surah } from '../types';
import { ThemeStyles } from '../utils/theme';
import { getDirection, Translations } from '../utils/i18n';
import {
  clearAllOfflineAudio,
  clearEntireAppCache,
  deleteCachedSurahText,
  deleteMultipleOfflineSurahs,
  deleteOfflineSurah,
  formatBytes,
  getStorageSummary,
  initializeStorageIfNeeded,
  STORAGE_UPDATED_EVENT,
  StorageSummary,
} from '../utils/storageManager';

interface StorageManagerScreenProps {
  onBack: () => void;
  surahs: Surah[];
  reciters: Reciter[];
  language: AppLanguage;
  themeStyles: ThemeStyles;
  t: Translations;
}

export const StorageManagerScreen: React.FC<StorageManagerScreenProps> = ({
  onBack,
  surahs,
  reciters,
  language,
  themeStyles,
  t,
}) => {
  const isRtl = getDirection(language) === 'rtl';
  const [summary, setSummary] = useState<StorageSummary | null>(null);
  const [selectedSurahNums, setSelectedSurahNums] = useState<number[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isBusy, setIsBusy] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [freedFeedbackBytes, setFreedFeedbackBytes] = useState<number | null>(null);

  const surahLookup = useMemo(() => {
    const map = new Map<number, Surah>();
    surahs.forEach((s) => map.set(s.number, s));
    return map;
  }, [surahs]);

  const refreshSummary = useCallback(async () => {
    initializeStorageIfNeeded(reciters[0]);
    const next = await getStorageSummary();
    setSummary(next);
    setSelectedSurahNums((prev) =>
      prev.filter((num) => next.offlineAudio.some((item) => item.surahNumber === num))
    );
  }, [reciters]);

  useEffect(() => {
    refreshSummary();
    const handler = () => {
      refreshSummary();
    };
    window.addEventListener(STORAGE_UPDATED_EVENT, handler);
    return () => window.removeEventListener(STORAGE_UPDATED_EVENT, handler);
  }, [refreshSummary]);

  const filteredOfflineAudio = useMemo(() => {
    if (!summary) return [];
    const q = searchQuery.trim().toLowerCase();
    if (!q) return summary.offlineAudio;
    return summary.offlineAudio.filter((item) => {
      const s = surahLookup.get(item.surahNumber);
      const nameMatch = s
        ? s.name.toLowerCase().includes(q) || s.englishName.toLowerCase().includes(q)
        : false;
      const numMatch = String(item.surahNumber) === q;
      const reciterMatch = item.reciterName.toLowerCase().includes(q);
      return nameMatch || numMatch || reciterMatch;
    });
  }, [summary, searchQuery, surahLookup]);

  const toggleSelectSurah = (surahNumber: number) => {
    setSelectedSurahNums((prev) =>
      prev.includes(surahNumber)
        ? prev.filter((n) => n !== surahNumber)
        : [...prev, surahNumber]
    );
  };

  const handleToggleSelectAll = () => {
    if (!summary) return;
    if (selectedSurahNums.length === filteredOfflineAudio.length && filteredOfflineAudio.length > 0) {
      setSelectedSurahNums([]);
    } else {
      setSelectedSurahNums(filteredOfflineAudio.map((item) => item.surahNumber));
    }
  };

  const handleDeleteSingleSurah = async (surahNumber: number) => {
    setIsBusy(true);
    const freed = await deleteOfflineSurah(surahNumber);
    setFreedFeedbackBytes(freed);
    await refreshSummary();
    setIsBusy(false);
  };

  const handleDeleteSelected = async () => {
    if (selectedSurahNums.length === 0) return;
    setIsBusy(true);
    const freed = await deleteMultipleOfflineSurahs(selectedSurahNums);
    setSelectedSurahNums([]);
    setFreedFeedbackBytes(freed);
    await refreshSummary();
    setIsBusy(false);
  };

  const handleClearAudioOnly = async () => {
    setIsBusy(true);
    const freed = await clearAllOfflineAudio();
    setSelectedSurahNums([]);
    setFreedFeedbackBytes(freed);
    await refreshSummary();
    setIsBusy(false);
  };

  const handleDeleteCachedText = async (surahNumber: number) => {
    setIsBusy(true);
    const freed = deleteCachedSurahText(surahNumber);
    setFreedFeedbackBytes(freed);
    await refreshSummary();
    setIsBusy(false);
  };

  const handleClearEntireCache = async () => {
    setIsBusy(true);
    setShowClearConfirm(false);
    const freed = await clearEntireAppCache();
    setSelectedSurahNums([]);
    setFreedFeedbackBytes(freed);
    await refreshSummary();
    setIsBusy(false);
  };

  const audioPercent =
    summary && summary.totalAppBytes > 0
      ? Math.round((summary.audioBytes / summary.totalAppBytes) * 100)
      : 0;
  const textAndRadioBytes = summary
    ? summary.textCacheBytes + summary.radioCacheBytes + summary.otherAppCacheBytes
    : 0;
  const textPercent =
    summary && summary.totalAppBytes > 0 ? Math.max(0, 100 - audioPercent) : 0;

  const deviceFreeBytes =
    summary &&
    summary.deviceQuotaBytes !== null &&
    summary.deviceUsedBytes !== null
      ? Math.max(0, summary.deviceQuotaBytes - summary.deviceUsedBytes)
      : null;

  return (
    <div
      className={`flex flex-col h-full ${themeStyles.phoneBg} font-cairo overflow-y-auto transition-colors duration-300 relative`}
    >
      {/* Top Sticky Header */}
      <div
        className={`sticky top-0 z-20 ${themeStyles.surfaceBg} border-b ${themeStyles.border} px-4 py-3 flex items-center justify-between gap-2 backdrop-blur-md`}
      >
        <button
          onClick={onBack}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl ${themeStyles.subSurfaceBg} border ${themeStyles.border} ${themeStyles.textPrimary} text-xs font-bold hover:opacity-90 transition-opacity`}
        >
          {isRtl ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
          <span>{t.storageBackBtn}</span>
        </button>

        <div className="flex items-center gap-1.5">
          <HardDrive className={`w-4 h-4 ${themeStyles.accentText}`} />
          <h2 className={`text-sm font-bold ${themeStyles.textPrimary}`}>{t.storageTitle}</h2>
        </div>

        <button
          onClick={refreshSummary}
          disabled={isBusy}
          aria-label="Refresh storage stats"
          className={`p-2 rounded-xl ${themeStyles.subSurfaceBg} border ${themeStyles.border} ${themeStyles.textSecondary} hover:opacity-90`}
        >
          <RefreshCw className={`w-4 h-4 ${isBusy ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Freed Space Feedback Banner */}
        {freedFeedbackBytes !== null && (
          <div
            className={`${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} rounded-2xl p-3 flex items-center justify-between gap-2 text-xs`}
          >
            <div className="flex items-center gap-2 font-bold">
              <CheckCircle2 className={`w-4 h-4 ${themeStyles.accentText} shrink-0`} />
              <span>
                {t.storageFreedBanner} {formatBytes(freedFeedbackBytes, language)}
              </span>
            </div>
            <button
              onClick={() => setFreedFeedbackBytes(null)}
              className="text-[11px] opacity-75 hover:opacity-100 px-1.5"
            >
              ✕
            </button>
          </div>
        )}

        {/* Storage Breakdown Card */}
        <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
          <div className="flex items-center justify-between gap-2">
            <div>
              <span className={`text-[11px] ${themeStyles.textSecondary} block`}>
                {t.storageTotalUsed}
              </span>
              <span className={`text-xl font-extrabold ${themeStyles.accentText}`}>
                {summary ? formatBytes(summary.totalAppBytes, language) : '...'}
              </span>
            </div>

            {deviceFreeBytes !== null && (
              <div className="text-end">
                <span className={`text-[10px] ${themeStyles.textSecondary} block`}>
                  {t.storageAvailableDevice}
                </span>
                <span className={`text-xs font-bold ${themeStyles.textPrimary}`}>
                  {formatBytes(deviceFreeBytes, language)}
                </span>
              </div>
            )}
          </div>

          {/* Segmented Storage Bar */}
          <div
            className={`w-full h-3 rounded-full ${themeStyles.subSurfaceBg} border ${themeStyles.border} overflow-hidden flex`}
          >
            {summary && summary.totalAppBytes > 0 ? (
              <>
                {audioPercent > 0 && (
                  <div
                    className={`${themeStyles.progressBarBg} h-full transition-all duration-300`}
                    style={{ width: `${audioPercent}%` }}
                  />
                )}
                {textPercent > 0 && (
                  <div
                    className="bg-amber-500 h-full transition-all duration-300"
                    style={{ width: `${textPercent}%` }}
                  />
                )}
              </>
            ) : (
              <div className="w-0 h-full" />
            )}
          </div>

          {/* Legend Rows */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl p-2.5 space-y-0.5`}>
              <div className="flex items-center gap-1.5 text-[11px] font-bold">
                <span className={`w-2.5 h-2.5 rounded-sm ${themeStyles.progressBarBg} shrink-0`} />
                <span className={themeStyles.textPrimary}>{t.storageOfflineAudioLabel}</span>
              </div>
              <div className="flex items-center justify-between text-[11px] pt-0.5">
                <span className={themeStyles.textSecondary}>
                  {summary ? `${summary.offlineAudio.length} ${t.storageSurahsCount}` : '—'}
                </span>
                <span className={`font-bold ${themeStyles.accentText}`}>
                  {summary ? formatBytes(summary.audioBytes, language) : '0'}
                </span>
              </div>
            </div>

            <div className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl p-2.5 space-y-0.5`}>
              <div className="flex items-center gap-1.5 text-[11px] font-bold">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 shrink-0" />
                <span className={themeStyles.textPrimary}>{t.storageTextCacheLabel}</span>
              </div>
              <div className="flex items-center justify-between text-[11px] pt-0.5">
                <span className={themeStyles.textSecondary}>
                  {summary ? `${summary.cachedSurahTexts.length}` : '0'}
                </span>
                <span className="font-bold text-amber-400">
                  {formatBytes(textAndRadioBytes, language)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Downloaded Surahs Section */}
        <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
          <div className="flex items-center justify-between gap-2 border-b pb-2.5 border-inherit">
            <h3 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5`}>
              <Volume2 className="w-4 h-4 shrink-0" />
              <span>
                {t.storageDownloadedSurahsTitle} ({summary?.offlineAudio.length ?? 0})
              </span>
            </h3>

            {summary && summary.offlineAudio.length > 0 && (
              <button
                onClick={handleToggleSelectAll}
                className={`text-[11px] font-bold ${themeStyles.accentText} hover:underline`}
              >
                {selectedSurahNums.length === filteredOfflineAudio.length &&
                filteredOfflineAudio.length > 0
                  ? t.storageClearSelection
                  : t.storageSelectAll}
              </button>
            )}
          </div>

          {/* Search input when 4+ surahs downloaded */}
          {summary && summary.offlineAudio.length >= 4 && (
            <div className="relative">
              <Search
                className={`w-3.5 h-3.5 ${themeStyles.textSecondary} absolute top-1/2 -translate-y-1/2 ${
                  isRtl ? 'right-3' : 'left-3'
                }`}
              />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.storageSearchPlaceholder}
                className={`w-full ${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl py-2 ${
                  isRtl ? 'pr-9 pl-3' : 'pl-9 pr-3'
                } text-xs ${themeStyles.textPrimary} focus:outline-none`}
              />
            </div>
          )}

          {/* Selection Action Bar */}
          {selectedSurahNums.length > 0 && (
            <div
              className={`flex items-center justify-between gap-2 p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40`}
            >
              <span className="text-xs font-bold text-rose-400">
                {selectedSurahNums.length}
              </span>
              <button
                onClick={handleDeleteSelected}
                disabled={isBusy}
                className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t.storageDeleteSelected}</span>
              </button>
            </div>
          )}

          {/* Offline Surahs List */}
          {!summary || filteredOfflineAudio.length === 0 ? (
            <div
              className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl p-5 text-center space-y-1.5`}
            >
              <Volume2 className={`w-7 h-7 mx-auto ${themeStyles.textSecondary} opacity-50`} />
              <p className={`text-xs ${themeStyles.textSecondary}`}>
                {t.storageNoDownloadedSurahs}
              </p>
            </div>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto pr-0.5">
              {filteredOfflineAudio.map((item) => {
                const surah = surahLookup.get(item.surahNumber);
                const isSelected = selectedSurahNums.includes(item.surahNumber);
                return (
                  <div
                    key={`${item.surahNumber}-${item.reciterId}`}
                    className={`flex items-center justify-between gap-2.5 p-2.5 rounded-xl border transition-all ${
                      isSelected
                        ? `${themeStyles.accentSoftBg} ${themeStyles.accentBorder}`
                        : `${themeStyles.subSurfaceBg} ${themeStyles.border}`
                    }`}
                  >
                    <button
                      onClick={() => toggleSelectSurah(item.surahNumber)}
                      className="flex items-center gap-2.5 flex-1 min-w-0 text-start"
                    >
                      <span
                        className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
                          isSelected
                            ? `${themeStyles.accentBg} border-transparent`
                            : `${themeStyles.cardBg} ${themeStyles.border}`
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                      </span>

                      <span
                        className={`w-7 h-7 rounded-lg ${themeStyles.cardBg} border ${themeStyles.border} flex items-center justify-center text-[11px] font-bold ${themeStyles.accentText} shrink-0`}
                      >
                        {item.surahNumber}
                      </span>

                      <div className="min-w-0 flex-1">
                        <p className={`text-xs font-bold ${themeStyles.textPrimary} truncate font-amiri`}>
                          {surah ? surah.name : `#${item.surahNumber}`}
                        </p>
                        <p className={`text-[10px] ${themeStyles.textSecondary} truncate`}>
                          {item.reciterName}
                        </p>
                      </div>
                    </button>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`text-[11px] font-bold ${themeStyles.accentText}`}>
                        {formatBytes(item.sizeBytes, language)}
                      </span>
                      <button
                        onClick={() => handleDeleteSingleSurah(item.surahNumber)}
                        disabled={isBusy}
                        aria-label={`Delete ${surah ? surah.name : item.surahNumber}`}
                        className="p-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {summary && summary.offlineAudio.length > 1 && (
            <button
              onClick={handleClearAudioOnly}
              disabled={isBusy}
              className={`w-full py-2 rounded-xl border border-rose-500/40 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t.storageClearAudioOnly}</span>
            </button>
          )}
        </div>

        {/* Cached Surah Texts & Radio Cache Section */}
        <div className={`${themeStyles.cardBg} border ${themeStyles.border} p-4 rounded-2xl space-y-3`}>
          <h3 className={`text-xs font-bold ${themeStyles.accentText} flex items-center gap-1.5 border-b ${themeStyles.border} pb-2`}>
            <Database className="w-4 h-4 shrink-0" />
            <span>
              {t.storageCachedTextsTitle} ({summary?.cachedSurahTexts.length ?? 0})
            </span>
          </h3>

          {!summary || (summary.cachedSurahTexts.length === 0 && summary.radioCacheBytes === 0) ? (
            <p className={`text-xs ${themeStyles.textSecondary} text-center py-2`}>
              {t.storageNoCachedTexts}
            </p>
          ) : (
            <div className="space-y-1.5 max-h-44 overflow-y-auto pr-0.5">
              {summary.cachedSurahTexts.map((txt) => {
                const surah = surahLookup.get(txt.surahNumber);
                return (
                  <div
                    key={txt.key}
                    className={`flex items-center justify-between gap-2 px-3 py-2 rounded-xl ${themeStyles.subSurfaceBg} border ${themeStyles.border}`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <FileText className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span className={`text-xs font-semibold ${themeStyles.textPrimary} truncate font-amiri`}>
                        {surah ? surah.name : `Surah ${txt.surahNumber}`}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`text-[10px] ${themeStyles.textSecondary}`}>
                        {formatBytes(txt.sizeBytes, language)}
                      </span>
                      <button
                        onClick={() => handleDeleteCachedText(txt.surahNumber)}
                        disabled={isBusy}
                        className="p-1 rounded-md text-rose-400 hover:bg-rose-500/15 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}

              {summary.radioCacheBytes > 0 && (
                <div
                  className={`flex items-center justify-between gap-2 px-3 py-2 rounded-xl ${themeStyles.subSurfaceBg} border ${themeStyles.border}`}
                >
                  <span className={`text-xs font-semibold ${themeStyles.textPrimary}`}>
                    {t.radioTitle}
                  </span>
                  <span className={`text-[10px] ${themeStyles.textSecondary}`}>
                    {formatBytes(summary.radioCacheBytes, language)}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Clear Entire Cache Action */}
        <button
          onClick={() => setShowClearConfirm(true)}
          disabled={isBusy || !summary || summary.totalAppBytes === 0}
          className="w-full py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 disabled:opacity-45 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all"
        >
          <Trash2 className="w-4 h-4" />
          <span>{t.storageClearAllCacheBtn}</span>
        </button>
      </div>

      {/* Clear Cache Confirmation Modal */}
      {showClearConfirm && (
        <div className="absolute inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div
            className={`${themeStyles.cardBg} border border-rose-500/40 w-full max-w-sm rounded-2xl p-5 shadow-2xl space-y-4`}
          >
            <div className="flex items-center gap-2.5 text-rose-400">
              <div className="w-9 h-9 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-sm">{t.storageClearConfirmTitle}</h3>
            </div>

            <p className={`text-xs ${themeStyles.textSecondary} leading-relaxed`}>
              {t.storageClearConfirmDesc}
            </p>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleClearEntireCache}
                disabled={isBusy}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors"
              >
                {t.storageConfirmYes}
              </button>
              <button
                onClick={() => setShowClearConfirm(false)}
                className={`flex-1 py-2.5 rounded-xl ${themeStyles.subSurfaceBg} border ${themeStyles.border} ${themeStyles.textPrimary} text-xs font-bold transition-colors`}
              >
                {t.storageCancel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
