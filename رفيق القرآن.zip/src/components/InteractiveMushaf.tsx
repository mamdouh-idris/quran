import React from 'react';
import { Ayah, AppSettings, Surah } from '../types';
import { ThemeStyles } from '../utils/theme';
import { Translations } from '../utils/i18n';
import {
  Info,
  Repeat,
  Repeat1,
  Layers,
  ChevronRight,
  ChevronLeft,
  CheckSquare,
  Play,
  Pause,
  X,
} from 'lucide-react';

export type RepeatMode = 'none' | 'surah' | 'ayahs';

interface SurahPageGroup {
  mushafPageNumber: number;
  ayahs: Ayah[];
}

interface InteractiveMushafProps {
  selectedSurah: Surah;
  activeAyahs: Ayah[];
  pageAyahs: Ayah[];
  currentPageData: SurahPageGroup;
  safePageIndex: number;
  totalPages: number;
  readingProgress: number;
  isLoadingSurahText: boolean;
  isAnimatingPage: boolean;
  flipDirection: 'next' | 'prev';
  isAtFirstPageOfQuran: boolean;
  isAtLastPageOfQuran: boolean;
  settings: AppSettings;
  themeStyles: ThemeStyles;
  t: Translations;
  activeFontClass: string;
  activeFontSizeClass: string;
  scrollContainerRef: React.RefObject<HTMLDivElement | null>;

  // Selection & Repeat state
  isSelectionMode: boolean;
  setIsSelectionMode: React.Dispatch<React.SetStateAction<boolean>>;
  repeatMode: RepeatMode;
  onSelectRepeatMode: (mode: RepeatMode) => void;
  showRepeatPanel: boolean;
  setShowRepeatPanel: React.Dispatch<React.SetStateAction<boolean>>;
  repeatRangeStart: number;
  repeatRangeEnd: number;
  setRepeatRangeStart: React.Dispatch<React.SetStateAction<number>>;
  setRepeatRangeEnd: React.Dispatch<React.SetStateAction<number>>;
  repeatLimit: number;
  setRepeatLimit: React.Dispatch<React.SetStateAction<number>>;
  currentCycle: number;
  setCurrentCycle: React.Dispatch<React.SetStateAction<number>>;
  currentPlayingAyah: number;
  setCurrentPlayingAyah: React.Dispatch<React.SetStateAction<number>>;
  isContinuingAfterRepeat: boolean;
  isPlayingAudio: boolean;
  onStartRangePlayback: (startAyah?: number) => void;
  onTogglePlayAudio: () => void;

  // Tafsir state
  showTafsirPanel: boolean;
  setShowTafsirPanel: React.Dispatch<React.SetStateAction<boolean>>;
  selectedAyahForTafsir: number;
  onAyahClick: (ayahNumber: number) => void;

  // Navigation
  onNextPage: () => void;
  onPrevPage: () => void;
}

export const InteractiveMushaf: React.FC<InteractiveMushafProps> = ({
  selectedSurah,
  activeAyahs,
  pageAyahs,
  currentPageData,
  safePageIndex,
  totalPages,
  readingProgress,
  isLoadingSurahText,
  isAnimatingPage,
  flipDirection,
  isAtFirstPageOfQuran,
  isAtLastPageOfQuran,
  settings,
  themeStyles,
  t,
  activeFontClass,
  activeFontSizeClass,
  scrollContainerRef,
  isSelectionMode,
  setIsSelectionMode,
  repeatMode,
  onSelectRepeatMode,
  showRepeatPanel,
  setShowRepeatPanel,
  repeatRangeStart,
  repeatRangeEnd,
  setRepeatRangeStart,
  setRepeatRangeEnd,
  repeatLimit,
  setRepeatLimit,
  currentCycle,
  setCurrentCycle,
  currentPlayingAyah,
  setCurrentPlayingAyah,
  isContinuingAfterRepeat,
  isPlayingAudio,
  onStartRangePlayback,
  onTogglePlayAudio,
  showTafsirPanel,
  setShowTafsirPanel,
  selectedAyahForTafsir,
  onAyahClick,
  onNextPage,
  onPrevPage,
}) => {
  const rangeMin = Math.min(repeatRangeStart, repeatRangeEnd);
  const rangeMax = Math.max(repeatRangeStart, repeatRangeEnd);
  const hasSelectedRange = repeatMode === 'ayahs' || isSelectionMode;

  const totalAyahCount = Math.max(selectedSurah.numberOfAyahs, activeAyahs.length);
  const ayahNumberOptions = Array.from({ length: totalAyahCount }, (_, i) => i + 1);

  const toggleBottomRepeat = () => {
    setShowRepeatPanel((prev) => {
      const next = !prev;
      if (next) setShowTafsirPanel(false);
      return next;
    });
  };

  const toggleBottomTafsir = () => {
    setShowTafsirPanel((prev) => {
      const next = !prev;
      if (next) setShowRepeatPanel(false);
      return next;
    });
  };

  const toggleSelectionMode = () => {
    setIsSelectionMode((prev) => {
      const next = !prev;
      if (next) {
        onSelectRepeatMode('ayahs');
        setShowRepeatPanel(true);
        setShowTafsirPanel(false);
      }
      return next;
    });
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
      {/* Scrollable Mushaf Page Content — Surah header stays 100% clear & unobstructed */}
      <div
        ref={scrollContainerRef}
        className={`flex-1 px-4 pt-3 pb-4 overflow-y-auto flex flex-col justify-between space-y-4 text-center select-text relative transition-all duration-250 origin-right ${
          isAnimatingPage
            ? flipDirection === 'next'
              ? '-rotate-y-12 translate-x-4 scale-95 opacity-30'
              : 'rotate-y-12 -translate-x-4 scale-95 opacity-30'
            : 'rotate-y-0 translate-x-0 scale-100 opacity-100'
        }`}
      >
        <div className="space-y-4">
          {/* Unobstructed Surah Banner & Current Page Header */}
          <div className={`py-3 px-3 border-y rounded-2xl ${themeStyles.cardBg} ${themeStyles.border}`}>
            <h2 className={`text-xl ${activeFontClass} font-bold ${themeStyles.accentText}`}>
              {selectedSurah.name}
            </h2>
            <p className={`text-[11px] ${themeStyles.textSecondary} mt-0.5 tabular-nums`}>
              {selectedSurah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'} · {selectedSurah.numberOfAyahs} آية · {t.pageOf} {safePageIndex + 1} / {totalPages}
              {totalPages > 1 ? ` (ص ${currentPageData.mushafPageNumber})` : ''}
            </p>
            <div className="flex items-center justify-center gap-3 mt-1 text-[10px]">
              <span className={themeStyles.accentText}>نسبة الإنجاز في السورة: {readingProgress}%</span>
              {isLoadingSurahText && (
                <span className={themeStyles.textSecondary}>جاري تحميل صفحات السورة...</span>
              )}
            </div>
          </div>

          {/* Interactive Selection Banner inside page (only subtle inline strip when actively selecting) */}
          {isSelectionMode && (
            <div
              className={`px-3 py-2 rounded-xl border ${themeStyles.accentSoftBg} ${themeStyles.accentBorder} flex items-center justify-between gap-2 text-[11px]`}
            >
              <span className={`font-semibold ${themeStyles.textPrimary}`}>
                تحديد الآيات: {rangeMin === rangeMax ? `الآية ${rangeMin}` : `من آية ${rangeMin} إلى ${rangeMax}`}
              </span>
              <button
                onClick={() => (isPlayingAudio ? onTogglePlayAudio() : onStartRangePlayback(rangeMin))}
                className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 ${themeStyles.accentBg}`}
              >
                {isPlayingAudio ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                <span>{isPlayingAudio ? t.stop : 'تكرار المحدد'}</span>
              </button>
            </div>
          )}

          {/* Bismillah only on the first page of Surahs 2..8 and 10..114 */}
          {safePageIndex === 0 && selectedSurah.number !== 1 && selectedSurah.number !== 9 && (
            <div className={`${activeFontClass} text-xl py-1 ${themeStyles.accentText}`}>
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </div>
          )}

          {/* Current Page Ayahs */}
          <div
            dir="rtl"
            className={`leading-loose ${activeFontClass} ${activeFontSizeClass} ${themeStyles.mushafText} text-justify px-2 py-2`}
          >
            {pageAyahs.map((ayah) => {
              const isInRepeatRange =
                hasSelectedRange && ayah.number >= rangeMin && ayah.number <= rangeMax;
              const isCurrentlyPlayingThisAyah =
                (repeatMode === 'ayahs' || isContinuingAfterRepeat) &&
                isPlayingAudio &&
                currentPlayingAyah === ayah.number;
              const isSelectedSingle = selectedAyahForTafsir === ayah.number;

              return (
                <span
                  key={ayah.number}
                  onClick={() => onAyahClick(ayah.number)}
                  title="اضغط لتحديد الآية للتكرار أو التفسير"
                  className={`inline rounded-lg px-1 py-0.5 transition-colors cursor-pointer ${
                    isCurrentlyPlayingThisAyah
                      ? `${themeStyles.accentSoftBg} ring-2 ${themeStyles.accentRing}`
                      : isInRepeatRange || isSelectedSingle
                      ? `${themeStyles.accentSoftBg} border-b-2 ${themeStyles.accentBorder}`
                      : 'hover:opacity-85'
                  }`}
                >
                  <span>{ayah.text}</span>
                  <span
                    className={`inline-flex items-center justify-center w-7 h-7 mx-1 text-xs font-cairo border rounded-full shadow-sm ${
                      isInRepeatRange || isSelectedSingle
                        ? `${themeStyles.accentBg} ${themeStyles.accentBorder}`
                        : `${themeStyles.cardBg} ${themeStyles.accentBorder} ${themeStyles.accentText}`
                    }`}
                  >
                    {ayah.number}
                  </span>
                </span>
              );
            })}
          </div>
        </div>

        {/* Page Navigation Row */}
        {settings.navigationMode === 'buttons' ? (
          <div className={`flex items-center justify-between pt-3 pb-1 border-t ${themeStyles.border}`}>
            <button
              onClick={onPrevPage}
              disabled={isAtFirstPageOfQuran}
              className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                isAtFirstPageOfQuran
                  ? `opacity-40 cursor-not-allowed ${themeStyles.cardBg} ${themeStyles.textSecondary}`
                  : `${themeStyles.accentBg} shadow-md`
              }`}
            >
              <ChevronRight className="w-4 h-4" />
              <span>{t.prevPage}</span>
            </button>

            <span className={`text-xs ${themeStyles.textSecondary} font-cairo tabular-nums`}>
              {t.pageOf} {safePageIndex + 1} / {totalPages}
            </span>

            <button
              onClick={onNextPage}
              disabled={isAtLastPageOfQuran}
              className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                isAtLastPageOfQuran
                  ? `opacity-40 cursor-not-allowed ${themeStyles.cardBg} ${themeStyles.textSecondary}`
                  : `${themeStyles.accentBg} shadow-md`
              }`}
            >
              <span>{t.nextPage}</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className={`text-center py-2 text-[11px] ${themeStyles.textSecondary} border-t ${themeStyles.border} space-y-0.5`}>
            <div className={`font-bold ${themeStyles.accentText} tabular-nums`}>
              {t.pageOf} {safePageIndex + 1} / {totalPages}
            </div>
            <div>
              💡 اسحب من اليسار لليمين للصفحة التالية، ومن اليمين لليسار للسابقة
            </div>
          </div>
        )}
      </div>

      {/* Bottom Docked Expandable Panels (Repeat / Tafsir) — Positioned at Bottom so Surah Title is NEVER Obscured */}
      {showRepeatPanel && (
        <div
          className={`border-t ${themeStyles.surfaceBg} ${themeStyles.border} px-3 py-2.5 space-y-2 text-xs transition-colors duration-300 shadow-inner`}
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <Repeat className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
              <span className={`font-bold ${themeStyles.accentText}`}>التكرار وتحديد الآيات:</span>
            </div>

            <div className="flex items-center gap-1">
              {[
                { id: 'none', label: 'بدون' },
                { id: 'ayahs', label: 'آيات محددة' },
                { id: 'surah', label: 'السورة كاملة' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => onSelectRepeatMode(opt.id as RepeatMode)}
                  className={`px-2 py-1 rounded-lg text-[11px] font-bold border transition-all ${
                    repeatMode === opt.id
                      ? `${themeStyles.accentBg} ${themeStyles.accentBorder}`
                      : `${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                  }`}
                >
                  {opt.label}
                </button>
              ))}
              <button
                onClick={() => setShowRepeatPanel(false)}
                className={`p-1 rounded-lg ${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} border ${themeStyles.border}`}
                aria-label="إغلاق"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {repeatMode === 'ayahs' && (
            <div className={`p-2.5 rounded-xl border ${themeStyles.subSurfaceBg} ${themeStyles.border} space-y-2`}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <span className={`text-[11px] ${themeStyles.textSecondary}`}>من:</span>
                  <select
                    value={rangeMin}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setRepeatRangeStart(val);
                      if (val > rangeMax) setRepeatRangeEnd(val);
                      setCurrentPlayingAyah(val);
                      setCurrentCycle(1);
                    }}
                    className={`border ${themeStyles.cardBg} ${themeStyles.textPrimary} ${themeStyles.border} rounded-lg px-2 py-0.5 text-xs font-bold`}
                  >
                    {ayahNumberOptions.map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>

                  <span className={`text-[11px] ${themeStyles.textSecondary}`}>إلى:</span>
                  <select
                    value={rangeMax}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setRepeatRangeEnd(val);
                      if (val < rangeMin) setRepeatRangeStart(val);
                      setCurrentCycle(1);
                    }}
                    className={`border ${themeStyles.cardBg} ${themeStyles.textPrimary} ${themeStyles.border} rounded-lg px-2 py-0.5 text-xs font-bold`}
                  >
                    {ayahNumberOptions.map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-1">
                  <span className={`text-[11px] ${themeStyles.textSecondary}`}>التكرار:</span>
                  {[3, 5, 7, 0].map((cnt) => (
                    <button
                      key={cnt}
                      onClick={() => {
                        setRepeatLimit(cnt);
                        setCurrentCycle(1);
                      }}
                      className={`px-2 py-0.5 rounded-md text-[11px] font-bold border ${
                        repeatLimit === cnt
                          ? `${themeStyles.accentBg} ${themeStyles.accentBorder}`
                          : `${themeStyles.cardBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                      }`}
                    >
                      {cnt === 0 ? '∞' : cnt}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px]">
                <span className={themeStyles.textSecondary}>
                  اضغط على الآيات لتحديد البداية والنهاية ثم اضغط تشغيل
                </span>
                <span className={`font-bold ${themeStyles.accentText} tabular-nums`}>
                  {isPlayingAudio
                    ? isContinuingAfterRepeat
                      ? `متابعة التلاوة: آية ${currentPlayingAyah}`
                      : `آية ${currentPlayingAyah} · دورة ${currentCycle}${
                          repeatLimit === 0 ? ' / ∞' : ` / ${repeatLimit}`
                        }`
                    : rangeMin === rangeMax
                    ? `محدد: الآية ${rangeMin}`
                    : `محدد: الآيات ${rangeMin}-${rangeMax}`}
                </span>
              </div>
            </div>
          )}

          {repeatMode === 'surah' && (
            <div className={`p-2 rounded-xl border ${themeStyles.subSurfaceBg} ${themeStyles.border} flex items-center justify-between`}>
              <span className={`text-[11px] ${themeStyles.textSecondary} flex items-center gap-1`}>
                <Layers className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
                <span>
                  تكرار {selectedSurah.name} كاملة {isPlayingAudio ? `(الدورة ${currentCycle})` : ''}
                </span>
              </span>
              <div className="flex items-center gap-1">
                {[2, 3, 5, 0].map((cnt) => (
                  <button
                    key={cnt}
                    onClick={() => {
                      setRepeatLimit(cnt);
                      setCurrentCycle(1);
                    }}
                    className={`px-2 py-0.5 rounded-md text-[11px] font-bold border ${
                      repeatLimit === cnt
                        ? `${themeStyles.accentBg} ${themeStyles.accentBorder}`
                        : `${themeStyles.cardBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                    }`}
                  >
                    {cnt === 0 ? '∞' : `${cnt}×`}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Bottom Surah Screen Action Bar: Select Ayahs + Repeat + Open Full Surah Tafsir */}
      <div
        className={`border-t ${themeStyles.cardBg} ${themeStyles.border} px-3 py-2 flex items-center gap-2 shrink-0`}
      >
        <button
          onClick={toggleSelectionMode}
          className={`flex-1 py-2 px-2 rounded-xl border text-[11px] font-bold transition-colors flex items-center justify-center gap-1 ${
            isSelectionMode
              ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow-sm`
              : `${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} ${themeStyles.border}`
          }`}
        >
          <CheckSquare className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">تحديد الآيات</span>
        </button>

        <button
          onClick={toggleBottomRepeat}
          className={`flex-1 py-2 px-2 rounded-xl border text-[11px] font-bold transition-colors flex items-center justify-center gap-1 ${
            repeatMode !== 'none' || showRepeatPanel
              ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow-sm`
              : `${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} ${themeStyles.border}`
          }`}
          title={t.repeatAndMemorize}
        >
          {repeatMode === 'ayahs' ? (
            <Repeat1 className="w-3.5 h-3.5 shrink-0" />
          ) : (
            <Repeat className="w-3.5 h-3.5 shrink-0" />
          )}
          <span className="truncate">
            {repeatMode === 'ayahs'
              ? `${t.repeatAndMemorize} (${rangeMin}-${rangeMax})`
              : t.repeatAndMemorize}
          </span>
        </button>

        <button
          onClick={toggleBottomTafsir}
          className={`flex-1 py-2 px-2 rounded-xl border text-[11px] font-bold transition-colors flex items-center justify-center gap-1 ${
            showTafsirPanel
              ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow-sm`
              : `${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} ${themeStyles.border}`
          }`}
          title="فتح صفحة التفسير الكاملة للسورة"
        >
          <Info className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">
            {selectedAyahForTafsir > 1 ? `تفسير (${selectedAyahForTafsir})` : 'التفسير'}
          </span>
        </button>
      </div>
    </div>
  );
};
