import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  BookOpen,
  Check,
  Columns2,
  Copy,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { AppSettings, Ayah, Reciter, Surah } from '../types';
import { getFontClass, getFontSizeClass, ThemeStyles } from '../utils/theme';
import { useSmartPause } from '../context/SmartPauseContext';
import {
  fetchSurahTafsir,
  getCachedSurahTafsirSync,
  splitTafsirForSpeech,
  TAFSIR_BOOKS,
  TafsirBookId,
} from '../utils/tafsirService';

type AudioTafsirMode = 'ayah-then-tafsir' | 'tafsir-only';
type PlayingPhase = 'idle' | 'ayah' | 'tafsir';

interface SurahTafsirPageProps {
  surahs: Surah[];
  selectedSurah: Surah;
  activeAyahs: Ayah[];
  initialAyahNumber: number;
  selectedReciter: Reciter;
  settings: AppSettings;
  fontSize: number;
  themeStyles: ThemeStyles;
  onChangeSurahIndex: (idx: number) => void;
  onBeforePlayAudio?: () => void;
  onClose: () => void;
}

const pad3 = (n: number) => String(n).padStart(3, '0');

export const SurahTafsirPage: React.FC<SurahTafsirPageProps> = ({
  surahs,
  selectedSurah,
  activeAyahs,
  initialAyahNumber,
  selectedReciter,
  settings,
  fontSize,
  themeStyles,
  onChangeSurahIndex,
  onBeforePlayAudio,
  onClose,
}) => {
  const initialPrimaryBook: TafsirBookId =
    settings.tafsirType === 'saadi'
      ? 'saadi'
      : settings.tafsirType === 'ibnkathir'
      ? 'ibnkathir'
      : 'muyassar';

  const [primaryBook, setPrimaryBook] = useState<TafsirBookId>(initialPrimaryBook);
  const [compareMode, setCompareMode] = useState<boolean>(false);
  const [secondaryBook, setSecondaryBook] = useState<TafsirBookId>('saadi');

  const [primaryMap, setPrimaryMap] = useState<Record<number, string>>(
    () => getCachedSurahTafsirSync(initialPrimaryBook, selectedSurah.number) || {}
  );
  const [secondaryMap, setSecondaryMap] = useState<Record<number, string>>({});
  const [isLoadingPrimary, setIsLoadingPrimary] = useState<boolean>(false);
  const [isLoadingSecondary, setIsLoadingSecondary] = useState<boolean>(false);
  const [savedOffline, setSavedOffline] = useState<boolean>(false);

  const [activeAyahNum, setActiveAyahNum] = useState<number>(initialAyahNumber || 1);
  const [copiedAyahNum, setCopiedAyahNum] = useState<number | null>(null);

  // Audio playback state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playingPhase, setPlayingPhase] = useState<PlayingPhase>('idle');
  const [audioMode, setAudioMode] = useState<AudioTafsirMode>('ayah-then-tafsir');
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [ttsNotice, setTtsNotice] = useState<string | null>(null);

  const ayahAudioRef = useRef<HTMLAudioElement | null>(null);
  const ayahCardRefs = useRef<Record<number, HTMLDivElement | null>>({});
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const playbackSessionRef = useRef<number>(0);
  const isPlayingRef = useRef<boolean>(false);
  const activeAyahRef = useRef<number>(activeAyahNum);
  const audioModeRef = useRef<AudioTafsirMode>(audioMode);
  const speechRateRef = useRef<number>(speechRate);
  const primaryMapRef = useRef<Record<number, string>>(primaryMap);
  const activeAyahsRef = useRef<Ayah[]>(activeAyahs);

  isPlayingRef.current = isPlaying;
  activeAyahRef.current = activeAyahNum;
  audioModeRef.current = audioMode;
  speechRateRef.current = speechRate;
  primaryMapRef.current = primaryMap;
  activeAyahsRef.current = activeAyahs;

  const { registerAudioController, notifyAudioStarted, notifyAudioStopped } = useSmartPause();

  const activeFontClass = getFontClass(settings.fontFamily);
  const ayahFontSizeClass = getFontSizeClass(Math.min(34, Math.max(20, fontSize)));

  // Fetch primary Tafsir for selected Surah + Book
  useEffect(() => {
    let cancelled = false;
    const cachedSync = getCachedSurahTafsirSync(primaryBook, selectedSurah.number);
    if (cachedSync) {
      setPrimaryMap(cachedSync);
      setSavedOffline(true);
      setIsLoadingPrimary(false);
      return;
    }

    setIsLoadingPrimary(true);
    setSavedOffline(false);
    fetchSurahTafsir(primaryBook, selectedSurah.number, activeAyahs)
      .then((res) => {
        if (cancelled) return;
        setPrimaryMap(res.data);
        setSavedOffline(Object.keys(res.data).length > 0);
      })
      .finally(() => {
        if (!cancelled) setIsLoadingPrimary(false);
      });

    return () => {
      cancelled = true;
    };
  }, [primaryBook, selectedSurah.number, activeAyahs]);

  // Fetch secondary comparison Tafsir when compare mode is active
  useEffect(() => {
    if (!compareMode) return;
    let cancelled = false;
    const cachedSync = getCachedSurahTafsirSync(secondaryBook, selectedSurah.number);
    if (cachedSync) {
      setSecondaryMap(cachedSync);
      setIsLoadingSecondary(false);
      return;
    }

    setIsLoadingSecondary(true);
    fetchSurahTafsir(secondaryBook, selectedSurah.number, activeAyahs)
      .then((res) => {
        if (!cancelled) setSecondaryMap(res.data);
      })
      .finally(() => {
        if (!cancelled) setIsLoadingSecondary(false);
      });

    return () => {
      cancelled = true;
    };
  }, [compareMode, secondaryBook, selectedSurah.number, activeAyahs]);

  // Scroll smoothly to target Ayah card
  const scrollToAyahCard = useCallback((ayahNumber: number, behavior: ScrollBehavior = 'smooth') => {
    const el = ayahCardRefs.current[ayahNumber];
    if (el) {
      el.scrollIntoView({ behavior, block: 'center' });
    }
  }, []);

  useEffect(() => {
    const tId = window.setTimeout(() => {
      scrollToAyahCard(initialAyahNumber || 1, 'auto');
    }, 80);
    return () => window.clearTimeout(tId);
  }, [selectedSurah.number, initialAyahNumber, scrollToAyahCard]);

  const stopAllTafsirAudio = useCallback(() => {
    playbackSessionRef.current += 1;
    if (ayahAudioRef.current) {
      ayahAudioRef.current.pause();
      ayahAudioRef.current.currentTime = 0;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore speechSynthesis cancel error
      }
    }
    setIsPlaying(false);
    setPlayingPhase('idle');
    notifyAudioStopped('tafsir');
  }, [notifyAudioStopped]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      playbackSessionRef.current += 1;
      if (ayahAudioRef.current) {
        ayahAudioRef.current.pause();
      }
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
        } catch {
          // ignore
        }
      }
      notifyAudioStopped('tafsir');
    };
  }, [notifyAudioStopped]);

  const pickArabicVoice = (): SpeechSynthesisVoice | null => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices() || [];
    const arabicVoices = voices.filter((v) => v.lang.toLowerCase().startsWith('ar'));
    if (arabicVoices.length === 0) return null;

    const maleKeywords = ['maged', 'tarik', 'hamza', 'zayd', 'fahd', 'naayf', 'majed', 'male', 'ذكر', 'رجل'];
    const femaleKeywords = ['female', 'أنثى', 'laila', 'salma', 'zira', 'hoda', 'mouna', 'amira', 'maryam', 'fatima'];

    const matchedMale = arabicVoices.find((v) => {
      const name = v.name.toLowerCase();
      return maleKeywords.some((kw) => name.includes(kw));
    });
    if (matchedMale) return matchedMale;

    const nonFemale = arabicVoices.find((v) => {
      const name = v.name.toLowerCase();
      return !femaleKeywords.some((kw) => name.includes(kw));
    });
    if (nonFemale) return nonFemale;

    return arabicVoices[0] || null;
  };

  const speakTafsirForAyah = useCallback(
    (ayahNumber: number, sessionId: number) => {
      if (sessionId !== playbackSessionRef.current) return;

      const ayahObj = activeAyahsRef.current.find((a) => a.number === ayahNumber);
      const tafsirText =
        primaryMapRef.current[ayahNumber] ||
        ayahObj?.tafsir?.jalalayn ||
        ayahObj?.tafsir?.saadi ||
        '';

      const advanceToNext = () => {
        if (sessionId !== playbackSessionRef.current) return;
        const idx = activeAyahsRef.current.findIndex((a) => a.number === ayahNumber);
        if (idx !== -1 && idx < activeAyahsRef.current.length - 1) {
          const nextNum = activeAyahsRef.current[idx + 1].number;
          playAyahSequenceRef.current(nextNum);
        } else {
          stopAllTafsirAudio();
        }
      };

      if (!tafsirText) {
        advanceToNext();
        return;
      }

      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        setTtsNotice('القراءة الصوتية للتفسير غير متوفرة في هذا المتصفح، يتم تشغيل تلاوة الآيات.');
        advanceToNext();
        return;
      }

      const chunks = splitTafsirForSpeech(`تفسير الآية ${ayahNumber}: ${tafsirText}`);
      if (chunks.length === 0) {
        advanceToNext();
        return;
      }

      setTtsNotice(null);
      setPlayingPhase('tafsir');

      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }

      const arabicVoice = pickArabicVoice();
      let chunkIdx = 0;

      const speakNextChunk = () => {
        if (sessionId !== playbackSessionRef.current) return;
        if (chunkIdx >= chunks.length) {
          advanceToNext();
          return;
        }

        const utter = new SpeechSynthesisUtterance(chunks[chunkIdx]);
        utter.lang = arabicVoice?.lang || 'ar-SA';
        if (arabicVoice) utter.voice = arabicVoice;
        utter.rate = speechRateRef.current;
        utter.pitch = 1.0;

        utter.onend = () => {
          if (sessionId !== playbackSessionRef.current) return;
          chunkIdx += 1;
          speakNextChunk();
        };

        utter.onerror = () => {
          if (sessionId !== playbackSessionRef.current) return;
          setTtsNotice('تعذر نطق التفسير عبر الصوت في هذا المتصفح.');
          advanceToNext();
        };

        window.speechSynthesis.speak(utter);
      };

      speakNextChunk();
    },
    [stopAllTafsirAudio]
  );

  const playAyahSequence = useCallback(
    (ayahNumber: number) => {
      onBeforePlayAudio?.();
      playbackSessionRef.current += 1;
      const sessionId = playbackSessionRef.current;

      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
        } catch {
          // ignore
        }
      }

      setActiveAyahNum(ayahNumber);
      scrollToAyahCard(ayahNumber, 'smooth');
      setIsPlaying(true);
      notifyAudioStarted('tafsir');

      if (audioModeRef.current === 'tafsir-only') {
        if (ayahAudioRef.current) {
          ayahAudioRef.current.pause();
        }
        speakTafsirForAyah(ayahNumber, sessionId);
        return;
      }

      const audioEl = ayahAudioRef.current;
      if (!audioEl) {
        speakTafsirForAyah(ayahNumber, sessionId);
        return;
      }

      const base =
        selectedReciter.ayahServerUrl || 'https://everyayah.com/data/Alafasy_128kbps/';
      const url = `${base}${pad3(selectedSurah.number)}${pad3(ayahNumber)}.mp3`;

      setPlayingPhase('ayah');
      audioEl.pause();
      audioEl.src = url;
      audioEl.playbackRate = 1;
      audioEl.currentTime = 0;

      audioEl.onended = () => {
        if (sessionId !== playbackSessionRef.current) return;
        speakTafsirForAyah(ayahNumber, sessionId);
      };

      audioEl.onerror = () => {
        if (sessionId !== playbackSessionRef.current) return;
        speakTafsirForAyah(ayahNumber, sessionId);
      };

      audioEl.play().catch(() => {
        if (sessionId !== playbackSessionRef.current) return;
        speakTafsirForAyah(ayahNumber, sessionId);
      });
    },
    [
      notifyAudioStarted,
      onBeforePlayAudio,
      scrollToAyahCard,
      selectedReciter.ayahServerUrl,
      selectedSurah.number,
      speakTafsirForAyah,
    ]
  );

  const playAyahSequenceRef = useRef(playAyahSequence);
  playAyahSequenceRef.current = playAyahSequence;

  // Register with SmartPause context
  useEffect(() => {
    return registerAudioController('tafsir', {
      pause: () => stopAllTafsirAudio(),
      resume: () => playAyahSequenceRef.current(activeAyahRef.current),
      isPlaying: () => isPlayingRef.current,
    });
  }, [registerAudioController, stopAllTafsirAudio]);

  const handleTogglePlay = () => {
    if (isPlaying) {
      stopAllTafsirAudio();
    } else {
      playAyahSequence(activeAyahNum);
    }
  };

  const handleStepAyah = (delta: -1 | 1) => {
    const idx = activeAyahs.findIndex((a) => a.number === activeAyahNum);
    if (idx === -1) return;
    const nextIdx = Math.min(Math.max(0, idx + delta), activeAyahs.length - 1);
    const nextAyahNum = activeAyahs[nextIdx].number;
    if (isPlaying) {
      playAyahSequence(nextAyahNum);
    } else {
      setActiveAyahNum(nextAyahNum);
      scrollToAyahCard(nextAyahNum, 'smooth');
    }
  };

  const cycleSpeechSpeed = () => {
    const speeds = [0.85, 1.0, 1.25];
    const nextIdx = (speeds.indexOf(speechRate) + 1) % speeds.length;
    const nextRate = speeds[nextIdx];
    setSpeechRate(nextRate);
    if (isPlaying && playingPhase === 'tafsir') {
      playAyahSequence(activeAyahNum);
    }
  };

  const copyAyahAndTafsir = (ayah: Ayah) => {
    const bookMeta = TAFSIR_BOOKS.find((b) => b.id === primaryBook) || TAFSIR_BOOKS[0];
    const mainText =
      primaryMap[ayah.number] || ayah.tafsir?.jalalayn || ayah.tafsir?.saadi || '';
    const formatted = `﴿${ayah.text}﴾ [${selectedSurah.name}: ${ayah.number}]\n\n${bookMeta.name}:\n${mainText}`;
    navigator.clipboard?.writeText(formatted).catch(() => {});
    setCopiedAyahNum(ayah.number);
    window.setTimeout(() => {
      setCopiedAyahNum((curr) => (curr === ayah.number ? null : curr));
    }, 1500);
  };

  const primaryBookMeta = useMemo(
    () => TAFSIR_BOOKS.find((b) => b.id === primaryBook) || TAFSIR_BOOKS[0],
    [primaryBook]
  );
  const secondaryBookMeta = useMemo(
    () => TAFSIR_BOOKS.find((b) => b.id === secondaryBook) || TAFSIR_BOOKS[2],
    [secondaryBook]
  );

  return (
    <div
      className={`flex-1 flex flex-col min-h-0 overflow-hidden font-cairo ${themeStyles.phoneBg} transition-colors duration-300`}
    >
      <audio ref={ayahAudioRef} preload="none" />

      {/* Top Sticky Surah Tafsir Header */}
      <div
        className={`${themeStyles.surfaceBg} border-b ${themeStyles.border} px-3 py-2.5 space-y-2.5 shrink-0 z-20 shadow-sm`}
      >
        <div className="flex items-center justify-between gap-2">
          <button
            onClick={() => {
              stopAllTafsirAudio();
              onClose();
            }}
            className={`px-2.5 py-1.5 rounded-xl ${themeStyles.cardBg} ${themeStyles.textPrimary} border ${themeStyles.border} text-xs font-bold flex items-center gap-1.5 shrink-0 hover:opacity-90`}
          >
            <ArrowRight className={`w-4 h-4 ${themeStyles.accentText}`} />
            <span>المصحف</span>
          </button>

          <div className="flex items-center gap-1.5 flex-1 min-w-0">
            <select
              value={selectedSurah.number}
              onChange={(e) => {
                const idx = surahs.findIndex((s) => s.number === Number(e.target.value));
                if (idx !== -1) {
                  stopAllTafsirAudio();
                  setActiveAyahNum(1);
                  onChangeSurahIndex(idx);
                }
              }}
              aria-label="اختيار السورة"
              className={`flex-1 min-w-0 ${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-xl px-2.5 py-1.5 text-xs font-bold focus:outline-none truncate`}
            >
              {surahs.map((s) => (
                <option key={s.number} value={s.number}>
                  {s.number}. {s.name}
                </option>
              ))}
            </select>

            <select
              value={activeAyahNum}
              onChange={(e) => {
                const num = Number(e.target.value);
                setActiveAyahNum(num);
                scrollToAyahCard(num, 'smooth');
                if (isPlaying) playAyahSequence(num);
              }}
              aria-label="الانتقال إلى الآية"
              className={`w-20 ${themeStyles.subSurfaceBg} ${themeStyles.textPrimary} border ${themeStyles.border} rounded-xl px-2 py-1.5 text-xs font-bold tabular-nums focus:outline-none`}
            >
              {activeAyahs.map((a) => (
                <option key={a.number} value={a.number}>
                  آية {a.number}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setCompareMode((prev) => !prev)}
            className={`p-2 rounded-xl border text-xs font-bold flex items-center gap-1 shrink-0 transition-colors ${
              compareMode
                ? `${themeStyles.accentBg} ${themeStyles.accentBorder}`
                : `${themeStyles.cardBg} ${themeStyles.textSecondary} ${themeStyles.border}`
            }`}
            title="مقارنة تفسيرين معاً"
          >
            <Columns2 className="w-4 h-4" />
            <span className="hidden sm:inline">مقارنة</span>
          </button>
        </div>

        {/* Tafsir Books Switcher Strip */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
          {TAFSIR_BOOKS.map((book) => {
            const isSelected = primaryBook === book.id;
            return (
              <button
                key={book.id}
                onClick={() => {
                  setPrimaryBook(book.id);
                  if (isPlaying && playingPhase === 'tafsir') {
                    window.setTimeout(() => playAyahSequenceRef.current(activeAyahRef.current), 150);
                  }
                }}
                className={`px-3 py-1.5 rounded-xl text-[11px] font-bold whitespace-nowrap border transition-all shrink-0 ${
                  isSelected
                    ? `${themeStyles.accentBg} ${themeStyles.accentBorder} shadow-sm`
                    : `${themeStyles.cardBg} ${themeStyles.textSecondary} ${themeStyles.border}`
                }`}
              >
                {book.name}
              </button>
            );
          })}
        </div>

        {/* Comparison Secondary Book Bar + Offline/Loading Status */}
        <div className="flex items-center justify-between gap-2 text-[10px]">
          <div className="flex items-center gap-1.5 min-w-0">
            <BookOpen className={`w-3.5 h-3.5 shrink-0 ${themeStyles.accentText}`} />
            <span className={`${themeStyles.textSecondary} truncate`}>
              {isLoadingPrimary
                ? 'جاري تحميل التفسير...'
                : savedOffline
                ? `${primaryBookMeta.name} · محفوظ بدون إنترنت ✓`
                : primaryBookMeta.description}
            </span>
          </div>

          {compareMode && (
            <div className="flex items-center gap-1 shrink-0">
              <span className={themeStyles.textSecondary}>مع:</span>
              <select
                value={secondaryBook}
                onChange={(e) => setSecondaryBook(e.target.value as TafsirBookId)}
                className={`${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder} rounded-lg px-2 py-0.5 text-[11px] font-bold focus:outline-none`}
              >
                {TAFSIR_BOOKS.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.shortName}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* TTS Unsupported Subtle Notice */}
      {ttsNotice && (
        <div className="bg-amber-500/15 border-b border-amber-500/30 px-3 py-1.5 text-[11px] text-amber-300 flex items-center justify-between gap-2 shrink-0">
          <span className="flex items-center gap-1.5">
            <VolumeX className="w-3.5 h-3.5 shrink-0" />
            <span>{ttsNotice}</span>
          </span>
          <button onClick={() => setTtsNotice(null)} className="text-[10px] underline">
            إخفاء
          </button>
        </div>
      )}

      {/* Surah Ayahs & Tafsir Scrollable Cards */}
      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto px-3 py-3 space-y-3"
      >
        {/* Surah Title Banner */}
        <div
          className={`${themeStyles.accentSoftBg} border ${themeStyles.accentBorder} rounded-2xl p-3 text-center space-y-1`}
        >
          <h2 className={`text-lg font-bold ${activeFontClass} ${themeStyles.accentText}`}>
            {selectedSurah.name} — التفسير والتدبر
          </h2>
          <p className={`text-[11px] ${themeStyles.textSecondary}`}>
            {selectedSurah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'} · {selectedSurah.numberOfAyahs} آية · {primaryBookMeta.name}
          </p>
        </div>

        {activeAyahs.map((ayah) => {
          const isThisActive = activeAyahNum === ayah.number;
          const isThisPlaying = isPlaying && isThisActive;
          const mainTafsir =
            primaryMap[ayah.number] ||
            ayah.tafsir?.jalalayn ||
            ayah.tafsir?.saadi ||
            (isLoadingPrimary ? 'جاري تحميل التفسير...' : 'اضغط للتحديث عند الاتصال بالإنترنت.');
          const secondTafsir = compareMode
            ? secondaryMap[ayah.number] ||
              (isLoadingSecondary ? 'جاري تحميل التفسير المقارن...' : 'التفسير غير متوفر حالياً.')
            : '';

          return (
            <div
              key={ayah.number}
              ref={(el) => {
                ayahCardRefs.current[ayah.number] = el;
              }}
              onClick={() => setActiveAyahNum(ayah.number)}
              className={`rounded-2xl border p-3.5 space-y-3 transition-all ${
                isThisPlaying
                  ? `${themeStyles.accentSoftBg} border-2 ${themeStyles.accentBorder} shadow-lg`
                  : isThisActive
                  ? `${themeStyles.cardBg} ${themeStyles.accentBorder} shadow-md`
                  : `${themeStyles.cardBg} ${themeStyles.border}`
              }`}
            >
              {/* Card Action Row */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-1 rounded-xl text-[11px] font-bold tabular-nums ${
                      isThisPlaying || isThisActive
                        ? themeStyles.accentBg
                        : `${themeStyles.subSurfaceBg} ${themeStyles.accentText} border ${themeStyles.accentBorder}`
                    }`}
                  >
                    الآية {ayah.number}
                  </span>
                  {isThisPlaying && (
                    <span className={`text-[10px] font-bold ${themeStyles.accentText} animate-pulse`}>
                      {playingPhase === 'ayah' ? '🔊 تلاوة الآية...' : '🎙️ قراءة التفسير...'}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (isThisPlaying) {
                        stopAllTafsirAudio();
                      } else {
                        playAyahSequence(ayah.number);
                      }
                    }}
                    className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 border transition-colors ${
                      isThisPlaying
                        ? 'bg-red-600 text-white border-red-500'
                        : `${themeStyles.subSurfaceBg} ${themeStyles.accentText} ${themeStyles.accentBorder}`
                    }`}
                    title="استماع للآية وتفسيرها"
                  >
                    {isThisPlaying ? (
                      <>
                        <Pause className="w-3.5 h-3.5" />
                        <span>إيقاف</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>استماع</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      copyAyahAndTafsir(ayah);
                    }}
                    className={`p-1.5 rounded-xl ${themeStyles.subSurfaceBg} ${themeStyles.textSecondary} border ${themeStyles.border}`}
                    title="نسخ الآية والتفسير"
                    aria-label="نسخ الآية والتفسير"
                  >
                    {copiedAyahNum === ayah.number ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Quranic Ayah Text Box */}
              <div
                dir="rtl"
                className={`${themeStyles.subSurfaceBg} border ${themeStyles.border} rounded-xl px-3.5 py-3 text-right`}
              >
                <p
                  className={`${activeFontClass} ${ayahFontSizeClass} ${themeStyles.mushafText} leading-loose`}
                >
                  {ayah.text}{' '}
                  <span
                    className={`inline-flex items-center justify-center w-6 h-6 mx-1 text-[11px] font-cairo rounded-full border ${themeStyles.cardBg} ${themeStyles.accentBorder} ${themeStyles.accentText}`}
                  >
                    {ayah.number}
                  </span>
                </p>
              </div>

              {/* Primary Tafsir Body */}
              <div dir="rtl" className="space-y-1 text-right">
                <div className="flex items-center gap-1.5 text-[11px] font-bold">
                  <Sparkles className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
                  <span className={themeStyles.accentText}>{primaryBookMeta.name}</span>
                </div>
                <p
                  className={`text-sm ${themeStyles.textPrimary} leading-relaxed whitespace-pre-line font-cairo`}
                >
                  {mainTafsir}
                </p>
              </div>

              {/* Optional Comparison Tafsir Body */}
              {compareMode && (
                <div
                  dir="rtl"
                  className={`pt-2.5 border-t ${themeStyles.border} space-y-1 text-right`}
                >
                  <div className="flex items-center gap-1.5 text-[11px] font-bold">
                    <Columns2 className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
                    <span className={themeStyles.accentText}>{secondaryBookMeta.name}</span>
                  </div>
                  <p
                    className={`text-sm ${themeStyles.textSecondary} leading-relaxed whitespace-pre-line font-cairo`}
                  >
                    {secondTafsir}
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom Docked Audio Tafsir Player Bar */}
      <div
        className={`${themeStyles.surfaceBg} border-t ${themeStyles.border} px-3 py-2.5 space-y-2 shrink-0 z-20 shadow-lg`}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 min-w-0">
            <button
              onClick={() => handleStepAyah(-1)}
              disabled={activeAyahNum <= 1}
              className={`p-2 rounded-xl border ${themeStyles.cardBg} ${themeStyles.textPrimary} ${themeStyles.border} disabled:opacity-40`}
              aria-label="الآية السابقة"
            >
              <SkipForward className="w-4 h-4" />
            </button>

            <button
              onClick={handleTogglePlay}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md ${
                isPlaying
                  ? 'bg-red-600 hover:bg-red-500 text-white'
                  : themeStyles.accentBg
              }`}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? 'إيقاف الصوت' : `تشغيل الآية ${activeAyahNum}`}</span>
            </button>

            <button
              onClick={() => handleStepAyah(1)}
              disabled={activeAyahNum >= activeAyahs.length}
              className={`p-2 rounded-xl border ${themeStyles.cardBg} ${themeStyles.textPrimary} ${themeStyles.border} disabled:opacity-40`}
              aria-label="الآية التالية"
            >
              <SkipBack className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => {
                const nextMode: AudioTafsirMode =
                  audioMode === 'ayah-then-tafsir' ? 'tafsir-only' : 'ayah-then-tafsir';
                setAudioMode(nextMode);
                audioModeRef.current = nextMode;
                if (isPlaying) playAyahSequence(activeAyahNum);
              }}
              className={`px-2.5 py-1.5 rounded-xl border text-[10px] font-bold ${themeStyles.accentSoftBg} ${themeStyles.accentBorder} ${themeStyles.accentText}`}
              title="تبديل وضع الصوت"
            >
              {audioMode === 'ayah-then-tafsir' ? 'تلاوة + تفسير' : 'تفسير فقط'}
            </button>

            <button
              onClick={cycleSpeechSpeed}
              className={`px-2 py-1.5 rounded-xl border text-[10px] font-bold tabular-nums ${themeStyles.cardBg} ${themeStyles.textPrimary} ${themeStyles.border}`}
              title="سرعة قراءة التفسير"
            >
              {speechRate}×
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
