import React from 'react';
import { Moon, Sun, Palette, Globe } from 'lucide-react';
import { AppLanguage, AppSettings } from '../types';
import { ThemeStyles, THEME_OPTIONS } from '../utils/theme';
import { LANGUAGE_OPTIONS, Translations } from '../utils/i18n';

interface NavbarProps {
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  themeStyles: ThemeStyles;
  t: Translations;
}

export const Navbar: React.FC<NavbarProps> = ({
  settings,
  setSettings,
  themeStyles,
  t,
}) => {
  const cycleTheme = () => {
    const idx = THEME_OPTIONS.findIndex((thm) => thm.id === settings.theme);
    const next = THEME_OPTIONS[(idx + 1) % THEME_OPTIONS.length];
    setSettings((prev) => ({ ...prev, theme: next.id, readingMode: false }));
  };

  return (
    <header
      className={`${themeStyles.navBg} backdrop-blur-md border-b ${themeStyles.border} shrink-0 z-50 px-3 sm:px-4 h-12 sm:h-14 pt-[env(safe-area-inset-top)] flex items-center transition-colors duration-300`}
    >
      <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-2 sm:gap-4">
        {/* Zone 1: Brand Icon + Single-line App Title */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl overflow-hidden shadow-sm border ${themeStyles.accentBorder} shrink-0`}
          >
            <img
              src="/pwa-192x192.png"
              alt={t.appName}
              className="w-full h-full object-cover"
            />
          </div>
          <h1
            className={`text-base sm:text-lg font-bold font-amiri ${themeStyles.accentText} tracking-wide whitespace-nowrap truncate`}
          >
            {t.appName}
          </h1>
        </div>

        {/* Zone 2: Quick Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Desktop Language & Theme Controls */}
          <div className="hidden md:flex items-center gap-2">
            <div
              className={`flex items-center gap-1 ${themeStyles.cardBg} border ${themeStyles.border} px-2 py-1 rounded-xl`}
            >
              <Globe className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
              <select
                value={settings.language}
                onChange={(e) =>
                  setSettings((prev) => ({ ...prev, language: e.target.value as AppLanguage }))
                }
                className={`bg-transparent text-xs font-semibold ${themeStyles.textPrimary} focus:outline-none cursor-pointer`}
                aria-label={t.languageSectionTitle}
              >
                {LANGUAGE_OPTIONS.map((lang) => (
                  <option key={lang.id} value={lang.id} className="bg-slate-900 text-slate-100">
                    {lang.nativeName}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={cycleTheme}
              className={`flex items-center gap-1.5 text-xs ${themeStyles.cardBg} ${themeStyles.textPrimary} border ${themeStyles.border} px-3 py-1.5 rounded-xl hover:opacity-90 transition-colors whitespace-nowrap`}
              title={t.themesSectionTitle}
            >
              <Palette className={`w-3.5 h-3.5 ${themeStyles.accentText}`} />
              <span>{THEME_OPTIONS.find((thm) => thm.id === settings.theme)?.name || ''}</span>
            </button>
          </div>

          <button
            onClick={() =>
              setSettings((prev) => ({
                ...prev,
                theme: prev.theme === 'light' ? 'dark' : 'light',
                readingMode: false,
              }))
            }
            className={`min-w-[38px] min-h-[38px] p-2 rounded-xl flex items-center justify-center ${themeStyles.cardBg} ${themeStyles.accentText} border ${themeStyles.border} hover:opacity-90 transition-colors`}
            aria-label={settings.theme === 'light' ? 'الوضع الليلي' : 'الوضع النهاري'}
          >
            {settings.theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};
