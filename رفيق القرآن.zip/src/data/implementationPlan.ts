export interface PlanSection {
  id: string;
  title: string;
  icon: string;
  summary: string;
  content: {
    subtitle: string;
    details: string[];
    technologies?: string[];
    challenges?: { problem: string; solution: string }[];
  }[];
}

export const implementationPlanData: PlanSection[] = [
  {
    id: 'phase-mvp',
    title: '1. مراحل التنفيذ (MVP ثم المراحل المتقدمة)',
    icon: 'Layers',
    summary: 'خطة زمنية مدروسة ومقسمة إلى مراحل لتقليل المخاطر وضمان جودة المنتج النهائي.',
    content: [
      {
        subtitle: 'المرحلة الأولى: النسخة الأولية الأساسية (MVP - الإصدار 1.0)',
        details: [
          'عرض المصحف الشريف نصاً مع التشكيل الكامل وضبط الصفحات والعثماني.',
          'تشغيل تلاوات القراء المشهورين (عبر الإنترنت مع تخزين مؤقت Caching).',
          'مواقيت الصلاة الأساسية حسب الموقع الجغرافي مع منبه الصلاة.',
          'المسبحة الإلكترونية وقسم أذكار حصن المسلم الأساسية.',
          'إذاعة القرآن الكريم (بث مباشر مع إعادة اتصال تلقائية).'
        ],
        technologies: ['React Native / Flutter or Progressive Web App', 'Expo Audio / Howler.js', 'Geolocator API', 'SQLite / Room (Local DB)']
      },
      {
        subtitle: 'المرحلة الثانية: التسميع الذكي والميزات المتقدمة (الإصدار 2.0)',
        details: [
          'إطلاق ميزة "تسميع القرآن الكريم" مع مطابقة الصوت بالنصوص القرآنية واستخراج الأخطاء وإبرازها.',
          'دعم التحميل الكامل للصور الصوتية والسور للاستخدام بدون إنترنت (Offline Mode).',
          'إضافة خيار "التحميل عبر Wi-Fi فقط" ومكتبة تحميلات مخصصة.',
          'تعدد التفاسير (الجلالين، السعدي، ابن كثير) مع التبديل الفوري.'
        ],
        technologies: ['Web Speech API / Whisper STT', 'Levenshtein Distance Algorithm', 'Background Fetch / Workmanager', 'IndexedDB / SQLite']
      },
      {
        subtitle: 'المرحلة الثالثة: الإشعارات الذكية وحساسات الجهاز (الإصدار 3.0)',
        details: [
          'دعم الأذان الكامل في الخلفية مع اختيار أصوات المؤذنين المتعددة.',
          'ميزة "تكبيرتين فقط" للأذان المختصر.',
          'مستشعر قلب الجهاز (DeviceOrientation / Gyroscope) لكتم الأذان تلقائياً عند قلب الهاتف.',
          'بوصلة القبلة التفاعلية بدقة عالية باستخدام الحساسات المغناطيسية.'
        ],
        technologies: ['Background Services (Foreground Service / APNs)', 'DeviceMotion API / Gyroscope', 'Compass.js / Geodesy']
      }
    ]
  },
  {
    id: 'tech-stack',
    title: '2. التقنيات والمكتبات المستخدمة',
    icon: 'Cpu',
    summary: 'اختيار أحدث التقنيات لضمان الأداء العالي، استهلاك منخفض للبطارية، ودعم Offline.',
    content: [
      {
        subtitle: 'الصوتيات والتحميل في الخلفية (Audio & Background)',
        details: [
          'مكتبة expo-av أو react-native-track-player لإدارة التلاوات والبث المباشر في الخلفية بنظام التشغيل.',
          'نظام التخزين المؤقت الملفاتي (File System Cache) لحفظ الملفات الصوتية دون الحاجة لإعادة تحميلها.'
        ],
        technologies: ['react-native-track-player', 'expo-file-system', 'HLS / MP3 streaming']
      },
      {
        subtitle: 'مقارنة نصوص التسميع بالذكاء الاصطناعي (Voice Recognition & STT)',
        details: [
          'تحويل الكلام الصوتي إلى نصوص باستخدام محرك التعرف على الصوت باللغة العربية (Speech-to-Text).',
          'استخدام خوارزمية Levenshtein Distance وخوارزميات مطابقة النصوص القرآنية لاكتشاف أخطاء التشكيل والحفظ وتحديد موضع الخطأ بدقة.'
        ],
        technologies: ['OpenAI Whisper / Web Speech API', 'Custom Fuzzy String Matching', 'Phonetic Arabic Normalization']
      },
      {
        subtitle: 'مواقيت الصلاة ومستشعر قلب الهاتف (Prayer Times & Sensors)',
        details: [
          'مكتبة adhan-js أو prayertimes لحساب المواقيت بدقة بناءً على الإحداثيات الجغرافية وطرق الحساب العالمية.',
          'استخدام حساس الدوران (Gyroscope) ومستشعر التوجيه لاكتشاف وضعية الشاشة المقلوبة وكتم الأذان.'
        ],
        technologies: ['adhan-js', 'expo-sensors (DeviceMotion)', 'Geolocator']
      }
    ]
  },
  {
    id: 'architecture',
    title: '3. هيكل المجلدات وقاعدة البيانات المحلية',
    icon: 'Database',
    summary: 'هيكلة منظمة ونظيفة (Clean Architecture) تضمن التوسع وسهولة الصيانة.',
    content: [
      {
        subtitle: 'هيكل المجلدات المقترح (Project Folder Structure)',
        details: [
          '/src/domain: نماذج البيانات وقواعد الأعمال (Entities, UseCases).',
          '/src/data: المستودعات وربط قواعد البيانات والشبكة (Repositories, Local DB, API).',
          '/src/presentation: واجهات المستخدم والشاشات (Screens: Mushaf, Tasmie, Prayer, Radio, Settings).',
          '/src/services: الخدمات المشتركة (Audio Player, Background Fetch, Notifications, Sensors).'
        ]
      },
      {
        subtitle: 'هيكل قاعدة البيانات المحلية (SQLite / Room)',
        details: [
          'جدول Surahs: لتخزين بيانات السور والفهارس والآيات.',
          'جدول Downloads: لتتبع السور والملفات الصوتية المحملة (Offline status).',
          'جدول Adhkar: لتخزين حصن المسلم والعدادات المفضلة.',
          'جدول TasmieHistory: لحفظ تقارير واختبارات التسميع السابقة والدرجات.'
        ],
        technologies: ['SQLite', 'WatermelonDB / Realm']
      }
    ]
  },
  {
    id: 'challenges',
    title: '4. أبرز التحديات المتوقعة وكيفية حلها',
    icon: 'ShieldCheck',
    summary: 'معالجة التحديات التقنية الأكثر تعقيداً في تطبيقات القرآن والأذان.',
    content: [
      {
        subtitle: 'التحديات والحلول التقنية',
        details: [],
        challenges: [
          {
            problem: 'دقة التسميع الصوتي واختلاف اللهجات في نطق الحروف العربية (الفصحى مقابل التجويد).',
            solution: 'تطبيع النصوص (Text Normalization) بإزالة التشكيل الاختياري أثناء المطابقة، واستخدام نماذج مدربة على الصوت القرآن لتجاهل الفروق الصوتية البسيطة مع التركيز على الأخطاء الجوهرية في الكلمات.'
          },
          {
            problem: 'ثبات إشعارات الأذان وتشغيل الصوت في الخلفية بدقة في أجهزة أندرويد و iOS الحديثة.',
            solution: 'استخدام خدمة Foreground Service في أندرويد و Push Notifications المجدولة محلياً (Local Notifications) مع جدولة مسبقة لليوم الكامل.'
          },
          {
            problem: 'تحديث روابط الإذاعات المباشرة وانقطاع الشبكة المفاجئ.',
            solution: 'تطبيق آلية إعادة المحاولة التلقائية (Exponential Backoff Retry Strategy) والاحتفاظ بقائمة بديلة لروابط البث المتعددة (Fallback Streams).'
          }
        ]
      }
    ]
  }
];
