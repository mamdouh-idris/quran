import { Surah, Reciter, RadioStation, Dhkar } from '../types';

export interface Muezzin {
  id: string;
  name: string;
  location?: string;
  audioUrl: string;
  backupUrl?: string;
}

export const muezzinsList: Muezzin[] = [
  {
    id: 'makkah',
    name: 'أذان الحرم المكي الشريف - الشيخ علي أحمد ملا',
    location: 'مكة المكرمة',
    audioUrl: 'https://cdn.aladhan.com/audio/adhans/a1.mp3',
    backupUrl: 'https://www.islamcan.com/audio/adhan/azan1.mp3',
  },
  {
    id: 'madinah',
    name: 'أذان المسجد النبوي الشريف',
    location: 'المدينة المنورة',
    audioUrl: 'https://cdn.aladhan.com/audio/adhans/a2.mp3',
    backupUrl: 'https://www.islamcan.com/audio/adhan/azan3.mp3',
  },
  {
    id: 'abdulbasit',
    name: 'الشيخ عبد الباسط عبد الصمد - أذان القاهرة',
    location: 'مصر',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan4.mp3',
    backupUrl: 'https://cdn.aladhan.com/audio/adhans/a1.mp3',
  },
  {
    id: 'aqsa',
    name: 'أذان المسجد الأقصى المبارك',
    location: 'القدس الشريف',
    audioUrl: 'https://cdn.aladhan.com/audio/adhans/a3.mp3',
    backupUrl: 'https://www.islamcan.com/audio/adhan/azan5.mp3',
  },
  {
    id: 'afasy',
    name: 'الشيخ مشاري راشد العفاسي',
    location: 'الكويت',
    audioUrl: 'https://cdn.aladhan.com/audio/adhans/a4.mp3',
    backupUrl: 'https://www.islamcan.com/audio/adhan/azan2.mp3',
  },
  {
    id: 'qatami',
    name: 'الشيخ ناصر القطامي',
    location: 'الرياض',
    audioUrl: 'https://cdn.aladhan.com/audio/adhans/a9.mp3',
    backupUrl: 'https://www.islamcan.com/audio/adhan/azan1.mp3',
  },
  {
    id: 'fajr_hijaz',
    name: 'أذان الفجر بنغمة الحجاز - الحرم المكي',
    location: 'مكة المكرمة',
    audioUrl: 'https://cdn.aladhan.com/audio/adhans/a7.mp3',
    backupUrl: 'https://www.islamcan.com/audio/adhan/azan6.mp3',
  },
  {
    id: 'makkah_classic',
    name: 'مؤذن الحرم المكي (التسجيل التراثي)',
    location: 'مكة المكرمة',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan2.mp3',
    backupUrl: 'https://cdn.aladhan.com/audio/adhans/a1.mp3',
  },
  {
    id: 'madinah_classic',
    name: 'مؤذن المسجد النبوي (الشيخ عصام بخاري)',
    location: 'المدينة المنورة',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan3.mp3',
    backupUrl: 'https://cdn.aladhan.com/audio/adhans/a2.mp3',
  },
  {
    id: 'rifat',
    name: 'الشيخ محمد رفعت (الأذان الكلاسيكي)',
    location: 'مصر',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan11.mp3',
    backupUrl: 'https://www.islamcan.com/audio/adhan/azan4.mp3',
  },
  {
    id: 'tokhy',
    name: 'الشيخ عبد المنعم الطوخي - أذان خاشع',
    location: 'مصر',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan19.mp3',
    backupUrl: 'https://www.islamcan.com/audio/adhan/azan8.mp3',
  },
  {
    id: 'fajr_mubarak',
    name: 'أذان الفجر الندي (الصلاة خير من النوم)',
    location: 'نداء الفجر',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan6.mp3',
    backupUrl: 'https://cdn.aladhan.com/audio/adhans/a7.mp3',
  },
  {
    id: 'khashie',
    name: 'أذان مؤثر وهادئ بصوت ندي',
    location: 'تسجيل استوديو',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan8.mp3',
    backupUrl: 'https://cdn.aladhan.com/audio/adhans/a4.mp3',
  },
  {
    id: 'istanbul',
    name: 'أذان إسطنبول - المقام العثماني',
    location: 'تركيا',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan16.mp3',
    backupUrl: 'https://cdn.aladhan.com/audio/adhans/a3.mp3',
  },
  {
    id: 'aqsa_fajr',
    name: 'مؤذن المسجد الأقصى (نداء هادئ)',
    location: 'القدس الشريف',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan5.mp3',
    backupUrl: 'https://cdn.aladhan.com/audio/adhans/a3.mp3',
  },
  {
    id: 'makkah_harmain',
    name: 'أذان مكة المكرمة (صوت جماعي مهيب)',
    location: 'مكة المكرمة',
    audioUrl: 'https://www.islamcan.com/audio/adhan/azan1.mp3',
    backupUrl: 'https://cdn.aladhan.com/audio/adhans/a1.mp3',
  }
];

interface SurahMeta {
  n: number;
  name: string;
  en: string;
  type: 'Meccan' | 'Medinan';
  ayahs: number;
  text: string;
}

const all114SurahsMeta: SurahMeta[] = [
  { n: 1, name: "سُورَةُ ٱلْفَاتِحَةِ", en: "Al-Fatihah", type: "Meccan", ayahs: 7, text: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ۝ الرَّحْمَٰنِ الرَّحِيمِ ۝ مَالِكِ يَوْمِ الدِّينِ ۝ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ۝ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ" },
  { n: 2, name: "سُورَةُ الْبَقَرَةِ", en: "Al-Baqarah", type: "Medinan", ayahs: 286, text: "الم ۝ ذَلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِلْمُتَّقِينَ ۝ الَّذِينَ يُؤْمِنُونَ بِالْغَيْبِ وَيُقِيمُونَ الصَّلَاةَ وَمِمَّا رَزَقْنَاهُمْ يُنْفِقُونَ" },
  { n: 3, name: "سُورَةُ آلِ عِمْرَانَ", en: "Aal-E-Imran", type: "Medinan", ayahs: 200, text: "الم ۝ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۝ نَزَّلَ عَلَيْكَ الْكِتَابَ بِالْحَقِّ مُصَدِّقًا لِمَا بَيْنَ يَدَيْهِ" },
  { n: 4, name: "سُورَةُ النِّسَاءِ", en: "An-Nisa", type: "Medinan", ayahs: 176, text: "يَا أَيُّهَا النَّاسُ اتَّقُوا رَبَّكُمُ الَّذِي خَلَقَكُمْ مِنْ نَفْسٍ وَاحِدَةٍ وَخَلَقَ مِنْهَا زَوْجَهَا وَبَثَّ مِنْهُمَا رِجَالًا كَثِيرًا وَنِسَاءً" },
  { n: 5, name: "سُورَةُ الْمَائِدَةِ", en: "Al-Ma'idah", type: "Medinan", ayahs: 120, text: "يَا أَيُّهَا الَّذِينَ آمَنُوا أَوْفُوا بِالْعُقُودِ ۚ أُحِلَّتْ لَكُمْ بَهِيمَةُ الْأَنْعَامِ إِلَّا مَا يُتْلَىٰ عَلَيْكُمْ" },
  { n: 6, name: "سُورَةُ الْأَنْعَامِ", en: "Al-An'am", type: "Meccan", ayahs: 165, text: "الْحَمْدُ لِلَّهِ الَّذِي خَلَقَ السَّمَاوَاتِ وَالْأَرْضَ وَجَعَلَ الظُّلُمَاتِ وَالنُّورَ" },
  { n: 7, name: "سُورَةُ الْأَعْرَافِ", en: "Al-A'raf", type: "Meccan", ayahs: 206, text: "المص ۝ كِتَابٌ أُنْزِلَ إِلَيْكَ فَلَا يَكُنْ فِي صَدْرِكَ حَرَجٌ مِنْهُ لِتُنْذِرَ بِهِ وَذِكْرَىٰ لِلْمُؤْمِنِينَ" },
  { n: 8, name: "سُورَةُ الْأَنْفَالِ", en: "Al-Anfal", type: "Medinan", ayahs: 75, text: "يَسْأَلُونَكَ عَنِ الْأَنْفَالِ ۖ قُلِ الْأَنْفَالُ لِلَّهِ وَالرَّسُولِ ۖ فَاتَّقُوا اللَّهَ وَأَصْلِحُوا ذَاتَ بَيْنِكُمْ" },
  { n: 9, name: "سُورَةُ التَّوْبَةِ", en: "At-Tawbah", type: "Medinan", ayahs: 129, text: "بَرَاءَةٌ مِنَ اللَّهِ وَرَسُولِهِ إِلَى الَّذِينَ عَاهَدْتُمْ مِنَ الْمُشْرِكِينَ" },
  { n: 10, name: "سُورَةُ يُونُسَ", en: "Yunus", type: "Meccan", ayahs: 109, text: "الر ۚ تِلْكَ آيَاتُ الْكِتَابِ الْحَكِيمِ" },
  { n: 11, name: "سُورَةُ هُودٍ", en: "Hud", type: "Meccan", ayahs: 123, text: "الر ۚ كِتَابٌ أُحْكِمَتْ آيَاتُهُ ثُمَّ فُصِّلَتْ مِنْ لَدُنْ حَكِيمٍ خَبِيرٍ" },
  { n: 12, name: "سُورَةُ يُوسُفَ", en: "Yusuf", type: "Meccan", ayahs: 111, text: "الر ۚ تِلْكَ آيَاتُ الْكِتَابِ الْمُبِينِ ۝ إِنَّا أَنْزَلْنَاهُ قُرْآنًا عَرَبِيًّا لَعَلَّكُمْ تَعْقِلُونَ" },
  { n: 13, name: "سُورَةُ الرَّعْدِ", en: "Ar-Ra'd", type: "Medinan", ayahs: 43, text: "المر ۚ تِلْكَ آيَاتُ الْكِتَابِ ۗ وَالَّذِي أُنْزِلَ إِلَيْكَ مِنْ رَبِّكَ الْحَقُّ" },
  { n: 14, name: "سُورَةُ إِبْرَاهِيمَ", en: "Ibrahim", type: "Meccan", ayahs: 52, text: "الر ۚ كِتَابٌ أَنْزَلْنَاهُ إِلَيْكَ لِتُخْرِجَ النَّاسَ مِنَ الظُّلُمَاتِ إِلَى النُّورِ" },
  { n: 15, name: "سُورَةُ الْحِجْرِ", en: "Al-Hijr", type: "Meccan", ayahs: 99, text: "الر ۚ تِلْكَ آيَاتُ الْكِتَابِ وَقُرْآنٍ مُبِينٍ" },
  { n: 16, name: "سُورَةُ النَّحْلِ", en: "An-Nahl", type: "Meccan", ayahs: 128, text: "أَتَىٰ أَمْرُ اللَّهِ فَلَا تَسْتَعْجِلُوهُ ۚ سُبْحَانَهُ وَتَعَالَىٰ عَمَّا يُشْرِكُونَ" },
  { n: 17, name: "سُورَةُ الْإِسْرَاءِ", en: "Al-Isra", type: "Meccan", ayahs: 111, text: "سُبْحَانَ الَّذِي أَسْرَىٰ بِعَبْدِهِ لَيْلًا مِنَ الْمَسْجِدِ الْحَرَامِ إِلَى الْمَسْجِدِ الْأَقْصَى" },
  { n: 18, name: "سُورَةُ الْكَهْفِ", en: "Al-Kahf", type: "Meccan", ayahs: 110, text: "الْحَمْدُ لِلَّهِ الَّذِي أَنْزَلَ عَلَىٰ عَبْدِهِ الْكِتَابَ وَلَمْ يَجْعَلْ لَهُ عِوَجًا" },
  { n: 19, name: "سُورَةُ مَرْيَمَ", en: "Maryam", type: "Meccan", ayahs: 98, text: "كهيعص ۝ ذِكْرُ رَحْمَتِ رَبِّكَ عَبْدَهُ زَكَرِيَّا" },
  { n: 20, name: "سُورَةُ طه", en: "Ta-Ha", type: "Meccan", ayahs: 135, text: "طه ۝ مَا أَنْزَلْنَا عَلَيْكَ الْقُرْآنَ لِتَشْقَىٰ" },
  { n: 21, name: "سُورَةُ الْأَنْبِيَاءِ", en: "Al-Anbiya", type: "Meccan", ayahs: 112, text: "اقْتَرَبَ لِلنَّاسِ حِسَابُهُمْ وَهُمْ فِي غَفْلَةٍ مُعْرِضُونَ" },
  { n: 22, name: "سُورَةُ الْحَجِّ", en: "Al-Hajj", type: "Medinan", ayahs: 78, text: "يَا أَيُّهَا النَّاسُ اتَّقُوا رَبَّكُمْ ۚ إِنَّ زَلْزَلَةَ السَّاعَةِ شَيْءٌ عَظِيمٌ" },
  { n: 23, name: "سُورَةُ الْمُؤْمِنُونَ", en: "Al-Mu'minun", type: "Meccan", ayahs: 118, text: "قَدْ أَفْلَحَ الْمُؤْمِنُونَ ۝ الَّذِينَ هُمْ فِي صَلَاتِهِمْ خَاشِعُونَ" },
  { n: 24, name: "سُورَةُ النُّورِ", en: "An-Nur", type: "Medinan", ayahs: 64, text: "سُورَةٌ أَنْزَلْنَاهَا وَفَرَضْنَاهَا وَأَنْزَلْنَا فِيهَا آيَاتٍ بَيِّنَاتٍ لَعَلَّكُمْ تَذَكَّرُونَ" },
  { n: 25, name: "سُورَةُ الْفُرْقَانِ", en: "Al-Furqan", type: "Meccan", ayahs: 77, text: "تَبَارَكَ الَّذِي نَزَّلَ الْفُرْقَانَ عَلَىٰ عَبْدِهِ لِيَكُونَ لِلْعَالَمِينَ نَذِيرًا" },
  { n: 26, name: "سُورَةُ الشُّعَرَاءِ", en: "Ash-Shu'ara", type: "Meccan", ayahs: 227, text: "طسم ۝ تِلْكَ آيَاتُ الْكِتَابِ الْمُبِينِ" },
  { n: 27, name: "سُورَةُ النَّمْلِ", en: "An-Naml", type: "Meccan", ayahs: 93, text: "طس ۚ تِلْكَ آيَاتُ الْقُرْآنِ وَكِتَابٍ مُبِينٍ" },
  { n: 28, name: "سُورَةُ الْقَصَصِ", en: "Al-Qasas", type: "Meccan", ayahs: 88, text: "طسم ۝ تِلْكَ آيَاتُ الْكِتَابِ الْمُبِينِ" },
  { n: 29, name: "سُورَةُ الْعَنْكَبُوتِ", en: "Al-Ankabut", type: "Meccan", ayahs: 69, text: "الم ۝ أَحَسِبَ النَّاسُ أَنْ يُتْرَكُوا أَنْ يَقُولُوا آمَنَّا وَهُمْ لَا يُفْتَنُونَ" },
  { n: 30, name: "سُورَةُ الرُّومِ", en: "Ar-Rum", type: "Meccan", ayahs: 60, text: "الم ۝ غُلِبَتِ الرُّومُ ۝ فِي أَدْنَى الْأَرْضِ وَهُمْ مِنْ بَعْدِ غَلَبِهِمْ سَيَغْلِبُونَ" },
  { n: 31, name: "سُورَةُ لُقْمَانَ", en: "Luqman", type: "Meccan", ayahs: 34, text: "الم ۝ تِلْكَ آيَاتُ الْكِتَابِ الْحَكِيمِ" },
  { n: 32, name: "سُورَةُ السَّجْدَةِ", en: "As-Sajdah", type: "Meccan", ayahs: 30, text: "الم ۝ تَنْزِيلُ الْكِتَابِ لَا رَيْبَ فِيهِ مِنْ رَبِّ الْعَالَمِينَ" },
  { n: 33, name: "سُورَةُ الْأَحْزَابِ", en: "Al-Ahzab", type: "Medinan", ayahs: 73, text: "يَا أَيُّهَا النَّبِيُّ اتَّقِ اللَّهَ وَلَا تُطِعِ الْكَافِرِينَ وَالْمُنَافِقِينَ" },
  { n: 34, name: "سُورَةُ سَبَإٍ", en: "Saba", type: "Meccan", ayahs: 54, text: "الْحَمْدُ لِلَّهِ الَّذِي لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ وَلَهُ الْحَمْدُ فِي الْآخِرَةِ" },
  { n: 35, name: "سُورَةُ فَاطِرٍ", en: "Fatir", type: "Meccan", ayahs: 45, text: "الْحَمْدُ لِلَّهِ فَاطِرِ السَّمَاوَاتِ وَالْأَرْضِ جَاعِلِ الْمَلَائِكَةِ رُسُلًا" },
  { n: 36, name: "سُورَةُ يس", en: "Ya-Sin", type: "Meccan", ayahs: 83, text: "يسٓ ۝ وَالْقُرْآنِ الْحَكِيمِ ۝ إِنَّكَ لَمِنَ الْمُرْسَلِينَ ۝ عَلَىٰ صِرَاطٍ مُسْتَقِيمٍ" },
  { n: 37, name: "سُورَةُ الصَّافَّاتِ", en: "As-Saffat", type: "Meccan", ayahs: 182, text: "وَالصَّافَّاتِ صَفًّا ۝ فَالزَّاجِرَاتِ زَجْرًا ۝ فَالتَّالِيَاتِ ذِكْرًا" },
  { n: 38, name: "سُورَةُ ص", en: "Sad", type: "Meccan", ayahs: 88, text: "صٓ ۚ وَالْقُرْآنِ ذِي الذِّكْرِ" },
  { n: 39, name: "سُورَةُ الزُّمَرِ", en: "Az-Zumar", type: "Meccan", ayahs: 75, text: "تَنْزِيلُ الْكِتَابِ مِنَ اللَّهِ الْعَزِيزِ الْحَكِيمِ" },
  { n: 40, name: "سُورَةُ غَافِرٍ", en: "Ghafir", type: "Meccan", ayahs: 85, text: "حم ۝ تَنْزِيلُ الْكِتَابِ مِنَ اللَّهِ الْعَزِيزِ الْعَلِيمِ" },
  { n: 41, name: "سُورَةُ فُصِّلَتْ", en: "Fussilat", type: "Meccan", ayahs: 54, text: "حم ۝ تَنْزِيلٌ مِنَ الرَّحْمَٰنِ الرَّحِيمِ" },
  { n: 42, name: "سُورَةُ الشُّورَىٰ", en: "Ash-Shura", type: "Meccan", ayahs: 53, text: "حم ۝ عسق" },
  { n: 43, name: "سُورَةُ الزُّخْرُفِ", en: "Az-Zukhruf", type: "Meccan", ayahs: 89, text: "حم ۝ وَالْكِتَابِ الْمُبِينِ" },
  { n: 44, name: "سُورَةُ الدُّخَانِ", en: "Ad-Dukhan", type: "Meccan", ayahs: 59, text: "حم ۝ وَالْكِتَابِ الْمُبِينِ" },
  { n: 45, name: "سُورَةُ الْجَاثِيَةِ", en: "Al-Jathiyah", type: "Meccan", ayahs: 37, text: "حم ۝ تَنْزِيلُ الْكِتَابِ مِنَ اللَّهِ الْعَزِيزِ الْحَكِيمِ" },
  { n: 46, name: "سُورَةُ الْأَحْقَافِ", en: "Al-Ahqaf", type: "Meccan", ayahs: 35, text: "حم ۝ تَنْزِيلُ الْكِتَابِ مِنَ اللَّهِ الْعَزِيزِ الْحَكِيمِ" },
  { n: 47, name: "سُورَةُ مُحَمَّدٍ", en: "Muhammad", type: "Medinan", ayahs: 38, text: "الَّذِينَ كَفَرُوا وَصَدُّوا عَنْ سَبِيلِ اللَّهِ أَضَلَّ أَعْمَالَهُمْ" },
  { n: 48, name: "سُورَةُ الْفَتْحِ", en: "Al-Fath", type: "Medinan", ayahs: 29, text: "إِنَّا فَتَحْنَا لَكَ فَتْحًا مُبِينًا" },
  { n: 49, name: "سُورَةُ الْحُجُرَاتِ", en: "Al-Hujurat", type: "Medinan", ayahs: 18, text: "يَا أَيُّهَا الَّذِينَ آمَنُوا لَا تُقَدِّمُوا بَيْنَ يَدَيِ اللَّهِ وَرَسُولِهِ" },
  { n: 50, name: "سُورَةُ ق", en: "Qaf", type: "Meccan", ayahs: 45, text: "قٓ ۚ وَالْقُرْآنِ الْمَجِيدِ" },
  { n: 51, name: "سُورَةُ الذَّارِيَاتِ", en: "Adh-Dhariyat", type: "Meccan", ayahs: 60, text: "وَالذَّارِيَاتِ ذَرْوًا ۝ فَالْحَامِلَاتِ وِقْرًا" },
  { n: 52, name: "سُورَةُ الطُّورِ", en: "At-Tur", type: "Meccan", ayahs: 49, text: "وَالطُّورِ ۝ وَكِتَابٍ مَسْطُورٍ" },
  { n: 53, name: "سُورَةُ النَّجْمِ", en: "An-Najm", type: "Meccan", ayahs: 62, text: "وَالنَّجْمِ إِذَا هَوَىٰ ۝ مَا ضَلَّ صَاحِبُكُمْ وَمَا غَوَىٰ" },
  { n: 54, name: "سُورَةُ الْقَمَرِ", en: "Al-Qamar", type: "Meccan", ayahs: 55, text: "اقْتَرَبَتِ السَّاعَةُ وَانْشَقَّ الْقَمَرُ" },
  { n: 55, name: "سُورَةُ الرَّحْمَٰنِ", en: "Ar-Rahman", type: "Medinan", ayahs: 78, text: "الرَّحْمَٰنُ ۝ عَلَّمَ الْقُرْآنَ ۝ خَلَقَ الْإِنْسَانَ ۝ عَلَّمَهُ الْبَيَانَ" },
  { n: 56, name: "سُورَةُ الْوَاقِعَةِ", en: "Al-Waqi'ah", type: "Meccan", ayahs: 96, text: "إِذَا وَقَعَتِ الْوَاقِعَةُ ۝ لَيْسَ لِوَقْعَتِهَا كَاذِبَةٌ" },
  { n: 57, name: "سُورَةُ الْحَدِيدِ", en: "Al-Hadid", type: "Medinan", ayahs: 29, text: "سَبَّحَ لِلَّهِ مَا فِي السَّمَاوَاتِ وَالْأَرْضِ ۖ وَهُوَ الْعَزِيزُ الْحَكِيمُ" },
  { n: 58, name: "سُورَةُ الْمُجَادِلَةِ", en: "Al-Mujadila", type: "Medinan", ayahs: 22, text: "قَدْ سَمِعَ اللَّهُ قَوْلَ الَّتِي تُجَادِلُكَ فِي زَوْجِهَا وَتَشْتَكِي إِلَى اللَّهِ" },
  { n: 59, name: "سُورَةُ الْحَشْرِ", en: "Al-Hashr", type: "Medinan", ayahs: 24, text: "سَبَّحَ لِلَّهِ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۖ وَهُوَ الْعَزِيزُ الْحَكِيمُ" },
  { n: 60, name: "سُورَةُ الْمُمْتَحَنَةِ", en: "Al-Mumtahanah", type: "Medinan", ayahs: 13, text: "يَا أَيُّهَا الَّذِينَ آمَنُوا لَا تَتَّخِذُوا عَدُوِّي وَعَدُوَّكُمْ أَوْلِيَاءَ" },
  { n: 61, name: "سُورَةُ الصَّفِّ", en: "As-Saf", type: "Medinan", ayahs: 14, text: "سَبَّحَ لِلَّهِ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۖ وَهُوَ الْعَزِيزُ الْحَكِيمُ" },
  { n: 62, name: "سُورَةُ الْجُمُعَةِ", en: "Al-Jumu'ah", type: "Medinan", ayahs: 11, text: "يُسَبِّحُ لِلَّهِ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ الْمَلِكِ الْقُدُّوسِ الْعَزِيزِ الْحَكِيمِ" },
  { n: 63, name: "سُورَةُ الْمُنَافِقُونَ", en: "Al-Munafiqun", type: "Medinan", ayahs: 11, text: "إِذَا جَاءَكَ الْمُنَافِقُونَ قَالُوا نَشْهَدُ إِنَّكَ لَرَسُولُ اللَّهِ" },
  { n: 64, name: "سُورَةُ التَّغَابُنِ", en: "At-Taghabun", type: "Medinan", ayahs: 18, text: "يُسَبِّحُ لِلَّهِ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۖ لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ" },
  { n: 65, name: "سُورَةُ الطَّلَاقِ", en: "At-Talaq", type: "Medinan", ayahs: 12, text: "يَا أَيُّهَا النَّبِيُّ إِذَا طَلَّقْتُمُ النِّسَاءَ فَطَلِّقُوهُنَّ لِعِدَّتِهِنَّ" },
  { n: 66, name: "سُورَةُ التَّحْرِيمِ", en: "At-Tahrim", type: "Medinan", ayahs: 12, text: "يَا أَيُّهَا النَّبِيُّ لِمَ تُحَرِّمُ مَا أَحَلَّ اللَّهُ لَكَ" },
  { n: 67, name: "سُورَةُ الْمُلْكِ", en: "Al-Mulk", type: "Meccan", ayahs: 30, text: "تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ ۝ الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا" },
  { n: 68, name: "سُورَةُ الْقَلَمِ", en: "Al-Qalam", type: "Meccan", ayahs: 52, text: "نٓ ۚ وَالْقَلَمِ وَمَا يَسْطُرُونَ" },
  { n: 69, name: "سُورَةُ الْحَاقَّةِ", en: "Al-Haqqah", type: "Meccan", ayahs: 52, text: "الْحَاقَّةُ ۝ مَا الْحَاقَّةُ ۝ وَمَا أَدْرَاكَ مَا الْحَاقَّةُ" },
  { n: 70, name: "سُورَةُ الْمَعَارِجِ", en: "Al-Ma'arij", type: "Meccan", ayahs: 44, text: "سَأَلَ سَائِلٌ بِعَذَابٍ وَاقِعٍ" },
  { n: 71, name: "سُورَةُ نُوحٍ", en: "Nuh", type: "Meccan", ayahs: 28, text: "إِنَّا أَرْسَلْنَا نُوحًا إِلَىٰ قَوْمِهِ أَنْ أَنْذِرْ قَوْمَكَ مِنْ قَبْلِ أَنْ يَأْتِيَهُمْ عَذَابٌ أَلِيمٌ" },
  { n: 72, name: "سُورَةُ الْجِنِّ", en: "Al-Jinn", type: "Meccan", ayahs: 28, text: "قُلْ أُوحِيَ إِلَيَّ أَنَّهُ اسْتَمَعَ نَفَرٌ مِنَ الْجِنِّ فَقَالُوا إِنَّا سَمِعْنَا قُرْآنًا عَجَبًا" },
  { n: 73, name: "سُورَةُ الْمُزَّمِّلِ", en: "Al-Muzzammil", type: "Meccan", ayahs: 20, text: "يَا أَيُّهَا الْمُزَّمِّلُ ۝ قُمِ اللَّيْلَ إِلَّا قَلِيلًا" },
  { n: 74, name: "سُورَةُ الْمُدَّثِّرِ", en: "Al-Muddaththir", type: "Meccan", ayahs: 56, text: "يَا أَيُّهَا الْمُدَّثِّرُ ۝ قُمْ فَأَنْذِرْ" },
  { n: 75, name: "سُورَةُ الْقِيَامَةِ", en: "Al-Qiyamah", type: "Meccan", ayahs: 40, text: "لَا أُقْسِمُ بِيَوْمِ الْقِيَامَةِ" },
  { n: 76, name: "سُورَةُ الْإِنْسَانِ", en: "Al-Insan", type: "Medinan", ayahs: 31, text: "هَلْ أَتَىٰ عَلَى الْإِنْسَانِ حِينٌ مِنَ الدَّهْرِ لَمْ يَكُنْ شَيْئًا مَذْكُورًا" },
  { n: 77, name: "سُورَةُ الْمُرْسَلَاتِ", en: "Al-Mursalat", type: "Meccan", ayahs: 50, text: "وَالْمُرْسَلَاتِ عُرْفًا ۝ فَالْعَاصِفَاتِ عَصْفًا" },
  { n: 78, name: "سُورَةُ النَّبَإِ", en: "An-Naba", type: "Meccan", ayahs: 40, text: "عَمَّ يَتَسَاءَلُونَ ۝ عَنِ النَّبَإِ الْعَظِيمِ" },
  { n: 79, name: "سُورَةُ النَّازِعَاتِ", en: "An-Nazi'at", type: "Meccan", ayahs: 46, text: "وَالنَّازِعَاتِ غَرْقًا ۝ وَالنَّاشِطَاتِ نَشْطًا" },
  { n: 80, name: "سُورَةُ عَبَسَ", en: "Abasa", type: "Meccan", ayahs: 42, text: "عَبَسَ وَتَوَلَّىٰ ۝ أَنْ جَاءَهُ الْأَعْمَىٰ" },
  { n: 81, name: "سُورَةُ التَّكْوِيرِ", en: "At-Takwir", type: "Meccan", ayahs: 29, text: "إِذَا الشَّمْسُ كُوِّرَتْ ۝ وَإِذَا النُّجُومُ انْكَدَرَتْ" },
  { n: 82, name: "سُورَةُ الْإِنْفِطَارِ", en: "Al-Infitar", type: "Meccan", ayahs: 19, text: "إِذَا السَّمَاءُ انْفَطَرَتْ ۝ وَإِذَا الْكَوَاكِبُ انْتَثَرَتْ" },
  { n: 83, name: "سُورَةُ الْمُطَفِّفِينَ", en: "Al-Mutaffifin", type: "Meccan", ayahs: 36, text: "وَيْلٌ لِلْمُطَفِّفِينَ ۝ الَّذِينَ إِذَا اكْتَالُوا عَلَى النَّاسِ يَسْتَوْفُونَ" },
  { n: 84, name: "سُورَةُ الْإِنْشِقَاقِ", en: "Al-Inshiqaq", type: "Meccan", ayahs: 25, text: "إِذَا السَّمَاءُ انْشَقَّتْ ۝ وَأَذِنَتْ لِرَبِّهَا وَحُقَّتْ" },
  { n: 85, name: "سُورَةُ الْبُرُوجِ", en: "Al-Buruj", type: "Meccan", ayahs: 22, text: "وَالسَّمَاءِ ذَاتِ الْبُرُوجِ ۝ وَالْيَوْمِ الْمَوْعُودِ" },
  { n: 86, name: "سُورَةُ الطَّارِقِ", en: "At-Tariq", type: "Meccan", ayahs: 17, text: "وَالسَّمَاءِ وَالطَّارِقِ ۝ وَمَا أَدْرَاكَ مَا الطَّارِقُ" },
  { n: 87, name: "سُورَةُ الْأَعْلَى", en: "Al-A'la", type: "Meccan", ayahs: 19, text: "سَبِّحِ اسْمَ رَبِّكَ الْأَعْلَى ۝ الَّذِي خَلَقَ فَسَوَّىٰ" },
  { n: 88, name: "سُورَةُ الْغَاشِيَةِ", en: "Al-Ghashiyah", type: "Meccan", ayahs: 26, text: "هَلْ أَتَاكَ حَدِيثُ الْغَاشِيَةِ" },
  { n: 89, name: "سُورَةُ الْفَجْرِ", en: "Al-Fajr", type: "Meccan", ayahs: 30, text: "وَالْفَجْرِ ۝ وَلَيَالٍ عَشْرٍ" },
  { n: 90, name: "سُورَةُ الْبَلَدِ", en: "Al-Balad", type: "Meccan", ayahs: 20, text: "لَا أُقْسِمُ بِهَٰذَا الْبَلَدِ" },
  { n: 91, name: "سُورَةُ الشَّمْسِ", en: "Ash-Shams", type: "Meccan", ayahs: 15, text: "وَالشَّمْسِ وَضُحَاهَا ۝ وَالْقَمَرِ إِذَا تَلَاهَا" },
  { n: 92, name: "سُورَةُ اللَّيْلِ", en: "Al-Layl", type: "Meccan", ayahs: 21, text: "وَاللَّيْلِ إِذَا يَغْشَىٰ ۝ وَالنَّهَارِ إِذَا تَجَلَّىٰ" },
  { n: 93, name: "سُورَةُ الضُّحَىٰ", en: "Ad-Duha", type: "Meccan", ayahs: 11, text: "وَالضُّحَىٰ ۝ وَاللَّيْلِ إِذَا سَجَىٰ ۝ مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ" },
  { n: 94, name: "سُورَةُ الشَّرْحِ", en: "Ash-Sharh", type: "Meccan", ayahs: 8, text: "أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ ۝ وَوَضَعْنَا عَنْكَ وِزْرَكَ" },
  { n: 95, name: "سُورَةُ التِّينِ", en: "At-Tin", type: "Meccan", ayahs: 8, text: "وَالتِّينِ وَالزَّيْتُونِ ۝ وَطُورِ سِينِينَ" },
  { n: 96, name: "سُورَةُ الْعَلَقِ", en: "Al-Alaq", type: "Meccan", ayahs: 19, text: "اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ ۝ خَلَقَ الْإِنْسَانَ مِنْ عَلَقٍ" },
  { n: 97, name: "سُورَةُ الْقَدْرِ", en: "Al-Qadr", type: "Meccan", ayahs: 5, text: "إِنَّا أَنْزَلْنَاهُ فِي لَيْلَةِ الْقَدْرِ ۝ وَمَا أَدْرَاكَ مَا لَيْلَةُ الْقَدْرِ" },
  { n: 98, name: "سُورَةُ الْبَيِّنَةِ", en: "Al-Bayyinah", type: "Medinan", ayahs: 8, text: "لَمْ يَكُنِ الَّذِينَ كَفَرُوا مِنْ أَهْلِ الْكِتَابِ وَالْمُشْرِكِينَ مُنْفَكِّينَ حَتَّىٰ تَأْتِيَهُمُ الْبَيِّنَةُ" },
  { n: 99, name: "سُورَةُ الزَّلْزَلَةِ", en: "Az-Zalzalah", type: "Medinan", ayahs: 8, text: "إِذَا زُلْزِلَتِ الْأَرْضُ زِلْزَالَهَا ۝ وَأَخْرَجَتِ الْأَرْضُ أَثْقَالَهَا" },
  { n: 100, name: "سُورَةُ الْعَادِيَاتِ", en: "Al-Adiyat", type: "Meccan", ayahs: 11, text: "وَالْعَادِيَاتِ ضَبْحًا ۝ فَالْمُورِيَاتِ قَدْحًا" },
  { n: 101, name: "سُورَةُ الْقَارِعَةِ", en: "Al-Qari'ah", type: "Meccan", ayahs: 11, text: "الْقَارِعَةُ ۝ مَا الْقَارِعَةُ ۝ وَمَا أَدْرَاكَ مَا الْقَارِعَةُ" },
  { n: 102, name: "سُورَةُ التَّكَاثُرِ", en: "At-Takathur", type: "Meccan", ayahs: 8, text: "أَلْهَاكُمُ التَّكَاثُرُ ۝ حَتَّىٰ زُرْتُمُ الْمَقَابِرَ" },
  { n: 103, name: "سُورَةُ الْعَصْرِ", en: "Al-Asr", type: "Meccan", ayahs: 3, text: "وَالْعَصْرِ ۝ إِنَّ الْإِنْسَانَ لَفِي خُسْرٍ ۝ إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ" },
  { n: 104, name: "سُورَةُ الْهُمَزَةِ", en: "Al-Humazah", type: "Meccan", ayahs: 9, text: "وَيْلٌ لِكُلِّ هُمَزَةٍ لُمَزَةٍ ۝ الَّذِي جَمَعَ مَالًا وَعَدَّدَهُ" },
  { n: 105, name: "سُورَةُ الْفِيلِ", en: "Al-Fil", type: "Meccan", ayahs: 5, text: "أَلَمْ تَرَ كَيْفَ فَعَلَ رَبُّكَ بِأَصْحَابِ الْفِيلِ" },
  { n: 106, name: "سُورَةُ قُرَيْشٍ", en: "Quraysh", type: "Meccan", ayahs: 4, text: "لِإِيلَافِ قُرَيْشٍ ۝ إِيلَافِهِمْ رِحْلَةَ الشِّتَاءِ وَالصَّيْفِ ۝ فَلْيَعْبُدُوا رَبَّ هَٰذَا الْبَيْتِ ۝ الَّذِي أَطْعَمَهُمْ مِنْ جُوعٍ وَآمَنَهُمْ مِنْ خَوْفٍ" },
  { n: 107, name: "سُورَةُ الْمَاعُونِ", en: "Al-Ma'un", type: "Meccan", ayahs: 7, text: "أَرَأَيْتَ الَّذِي يُكَذِّبُ بِالدِّينِ ۝ فَذَٰلِكَ الَّذِي يَدُعُّ الْيَتِيمَ" },
  { n: 108, name: "سُورَةُ الْكَوْثَرِ", en: "Al-Kawthar", type: "Meccan", ayahs: 3, text: "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ ۝ فَصَلِّ لِرَبِّكَ وَانْحَرْ ۝ إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ" },
  { n: 109, name: "سُورَةُ الْكَافِرُونَ", en: "Al-Kafirun", type: "Meccan", ayahs: 6, text: "قُلْ يَا أَيُّهَا الْكَافِرُونَ ۝ لَا أَعْبُدُ مَا تَعْبُدُونَ" },
  { n: 110, name: "سُورَةُ النَّصْرِ", en: "An-Nasr", type: "Medinan", ayahs: 3, text: "إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ ۝ وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْوَاجًا ۝ فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ ۚ إِنَّهُ كَانَ تَوَّابًا" },
  { n: 111, name: "سُورَةُ الْمَسَدِ", en: "Al-Masad", type: "Meccan", ayahs: 5, text: "تَبَّتْ يَدَا أَبِي لَهَبٍ وَتَبَّ ۝ مَا أَغْنَىٰ عَنْهُ مَالُهُ وَمَا كَسَبَ" },
  { n: 112, name: "سُورَةُ الْإِخْلَاصِ", en: "Al-Ikhlas", type: "Meccan", ayahs: 4, text: "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ" },
  { n: 113, name: "سُورَةُ الْفَلَقِ", en: "Al-Falaq", type: "Meccan", ayahs: 5, text: "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِنْ شَرِّ مَا خَلَقَ ۝ وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ" },
  { n: 114, name: "سُورَةُ النَّاسِ", en: "An-Nas", type: "Meccan", ayahs: 6, text: "قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ" }
];

export const sampleSurahs: Surah[] = all114SurahsMeta.map((s) => ({
  number: s.n,
  name: s.name,
  englishName: s.en,
  englishNameTranslation: s.en,
  revelationType: s.type,
  numberOfAyahs: s.ayahs,
  ayahs: s.text.split('۝').map((t, idx) => ({
    number: idx + 1,
    text: t.trim(),
    juz: Math.min(30, Math.max(1, Math.ceil((s.n / 114) * 30))),
    page: s.n,
    tafsir: {
      jalalayn: `تفسير الجلالين للآية (${idx + 1}) من ${s.name}: بيان لمعاني الآية ومقاصدها الشرعية بأسلوب ميسر.`,
      saadi: `التفسير الميسر للآية (${idx + 1}) من ${s.name}: تذكير بهداية القرآن الكريم وحكمه البالغة.`
    }
  }))
}));

export const recitersList: Reciter[] = [
  {
    id: 'mishary',
    name: 'الشيخ مشاري راشد العفاسي',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server8.mp3quran.net/afs/',
    ayahServerUrl: 'https://everyayah.com/data/Alafasy_128kbps/'
  },
  {
    id: 'sudais',
    name: 'الشيخ عبد الرحمن السديس',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server11.mp3quran.net/sds/',
    ayahServerUrl: 'https://everyayah.com/data/Abdurrahmaan_As-Sudais_192kbps/'
  },
  {
    id: 'shuraim',
    name: 'الشيخ سعود الشريم',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/saud-shuraim/r1/',
    ayahServerUrl: 'https://everyayah.com/data/Saood_ash-Shuraym_128kbps/'
  },
  {
    id: 'maher',
    name: 'الشيخ ماهر المعيقلي',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server12.mp3quran.net/maher/',
    ayahServerUrl: 'https://everyayah.com/data/MaherAlMuaiqly128kbps/'
  },
  {
    id: 'dosari',
    name: 'الشيخ ياسر الدوسري',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/yasser-dosari/r1/',
    ayahServerUrl: 'https://everyayah.com/data/Yasser_Ad-Dussary_128kbps/'
  },
  {
    id: 'qatami',
    name: 'الشيخ ناصر القطامي',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/nasser-qatami/r1/',
    ayahServerUrl: 'https://everyayah.com/data/Nasser_Alqatami_128kbps/'
  },
  {
    id: 'saad',
    name: 'الشيخ سعد الغامدي',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server7.mp3quran.net/s_gmd/',
    ayahServerUrl: 'https://everyayah.com/data/Ghamadi_40kbps/'
  },
  {
    id: 'ajamy',
    name: 'الشيخ أحمد بن علي العجمي',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/ahmad-ajmi/r1/',
    ayahServerUrl: 'https://everyayah.com/data/ahmed_ibn_ali_al_ajamy_128kbps/'
  },
  {
    id: 'abdulbasit',
    name: 'الشيخ عبد الباسط عبد الصمد (مرتل)',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server7.mp3quran.net/basit/',
    ayahServerUrl: 'https://everyayah.com/data/Abdul_Basit_Murattal_192kbps/'
  },
  {
    id: 'abdulbasit_mujawwad',
    name: 'الشيخ عبد الباسط عبد الصمد (مجود)',
    style: 'حفص عن عاصم - مجود',
    serverUrl: 'https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/',
    ayahServerUrl: 'https://everyayah.com/data/Abdul_Basit_Mujawwad_128kbps/'
  },
  {
    id: 'minshawi',
    name: 'الشيخ محمد صديق المنشاوي (مرتل)',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server10.mp3quran.net/minsh/',
    ayahServerUrl: 'https://everyayah.com/data/Minshawy_Murattal_128kbps/'
  },
  {
    id: 'minshawi_mujawwad',
    name: 'الشيخ محمد صديق المنشاوي (مجود)',
    style: 'حفص عن عاصم - مجود',
    serverUrl: 'https://server10.mp3quran.net/minsh/Almusshaf-Al-Mojawwad/',
    ayahServerUrl: 'https://everyayah.com/data/Minshawy_Mujawwad_192kbps/'
  },
  {
    id: 'husary',
    name: 'الشيخ محمود خليل الحصري (مرتل)',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server13.mp3quran.net/husr/',
    ayahServerUrl: 'https://everyayah.com/data/Husary_128kbps/'
  },
  {
    id: 'husary_mujawwad',
    name: 'الشيخ محمود خليل الحصري (مجود)',
    style: 'حفص عن عاصم - مجود',
    serverUrl: 'https://server13.mp3quran.net/husr/Almusshaf-Al-Mojawwad/',
    ayahServerUrl: 'https://everyayah.com/data/Husary_Mujawwad_64kbps/'
  },
  {
    id: 'banna',
    name: 'الشيخ محمود علي البنا (مجود)',
    style: 'حفص عن عاصم - مجود',
    serverUrl: 'https://cdn.mp3quran.net/audio/mahmoud-banna/r2/',
    ayahServerUrl: 'https://everyayah.com/data/mahmoud_ali_al_banna_32kbps/'
  },
  {
    id: 'tablawi',
    name: 'الشيخ محمد محمود الطبلاوي',
    style: 'حفص عن عاصم - مجود',
    serverUrl: 'https://cdn.mp3quran.net/audio/muhammad-tablawi/r2/',
    ayahServerUrl: 'https://everyayah.com/data/Mohammad_al_Tablaway_128kbps/'
  },
  {
    id: 'hudhaifi',
    name: 'الشيخ علي بن عبد الرحمن الحذيفي',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server9.mp3quran.net/hthfi/',
    ayahServerUrl: 'https://everyayah.com/data/Hudhaify_128kbps/'
  },
  {
    id: 'ayyub',
    name: 'الشيخ محمد أيوب',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/muhammad-ayyub/r2/',
    ayahServerUrl: 'https://everyayah.com/data/Muhammad_Ayyoub_128kbps/'
  },
  {
    id: 'juhani',
    name: 'الشيخ عبد الله عواد الجهني',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/abdullah-juhani/r1/',
    ayahServerUrl: 'https://everyayah.com/data/Abdullaah_3awwaad_Al-Juhaynee_128kbps/'
  },
  {
    id: 'budair',
    name: 'الشيخ صلاح البدير',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server6.mp3quran.net/s_bud/',
    ayahServerUrl: 'https://everyayah.com/data/Salah_Al_Budair_128kbps/'
  },
  {
    id: 'shatri',
    name: 'الشيخ أبو بكر الشاطري',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/abubakr-shatri/r1/',
    ayahServerUrl: 'https://everyayah.com/data/Abu_Bakr_Ash-Shaatree_128kbps/'
  },
  {
    id: 'fares',
    name: 'الشيخ فارس عباد',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/fares-abbad/r1/',
    ayahServerUrl: 'https://everyayah.com/data/Fares_Abbad_64kbps/'
  },
  {
    id: 'rifai',
    name: 'الشيخ هاني الرفاعي',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/hani-rifai/r1/',
    ayahServerUrl: 'https://everyayah.com/data/Hani_Rifai_192kbps/'
  },
  {
    id: 'basfar',
    name: 'الشيخ عبد الله بصفر',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://cdn.mp3quran.net/audio/abdullah-basfar/r1/',
    ayahServerUrl: 'https://everyayah.com/data/Abdullah_Basfar_192kbps/'
  },
  {
    id: 'jibreel',
    name: 'الشيخ محمد جبريل',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server8.mp3quran.net/jbrl/',
    ayahServerUrl: 'https://everyayah.com/data/Muhammad_Jibreel_128kbps/'
  },
  {
    id: 'akhdar',
    name: 'الشيخ إبراهيم الأخضر',
    style: 'حفص عن عاصم - مرتل',
    serverUrl: 'https://server6.mp3quran.net/akdr/',
    ayahServerUrl: 'https://everyayah.com/data/Ibrahim_Akhdar_32kbps/'
  }
];

export const radioStationsList: RadioStation[] = [
  {
    id: 'cairo_radio',
    name: 'إذاعة القرآن الكريم من القاهرة',
    url: 'https://radio.xecod.com/station/quran-cairo',
    backupUrls: [
      'https://stream.radiojar.com/0tpy1h0kxtzuv',
      'https://win.holol.com/live/quran/playlist.m3u8',
      'https://backup.qurango.net/radio/tarateel',
      'https://qurango.net/radio/tarateel',
    ],
    country: 'مصر',
    streamType: 'Icecast',
  },
  {
    id: 'saudi_radio',
    name: 'إذاعة القرآن الكريم من المملكة العربية السعودية',
    url: 'https://stream.radiojar.com/0tpy1h0kxtzuv',
    backupUrls: [
      'https://win.holol.com/live/quran/playlist.m3u8',
      'https://backup.qurango.net/radio/abdulrahman_alsudaes',
      'https://radio.mp3islam.com/listen/sudais/radio.mp3',
      'https://qurango.net/radio/abdulrahman_alsudaes',
    ],
    country: 'السعودية',
    streamType: 'Icecast',
  },
  {
    id: 'makkah_hls_live',
    name: 'إذاعة الحرم المكي المباشرة (بث HLS عالي الجودة)',
    url: 'https://win.holol.com/live/quran/playlist.m3u8',
    backupUrls: [
      'https://backup.qurango.net/radio/abdulrahman_alsudaes',
      'https://backup.qurango.net/radio/maher',
      'https://radio.mp3islam.com/listen/maher/radio.mp3',
      'https://qurango.net/radio/maher',
    ],
    country: 'مكة المكرمة',
    streamType: 'HLS',
  },
  {
    id: 'mishary_radio',
    name: 'إذاعة الشيخ مشاري راشد العفاسي',
    url: 'https://backup.qurango.net/radio/mishary_alafasi',
    backupUrls: [
      'https://qurango.net/radio/mishary_alafasi',
      'https://win.holol.com/live/quran/playlist.m3u8',
      'https://backup.qurango.net/radio/tarateel',
    ],
    country: 'الكويت',
    streamType: 'Icecast',
  },
  {
    id: 'abdulbasit_radio',
    name: 'إذاعة الشيخ عبد الباسط عبد الصمد',
    url: 'https://backup.qurango.net/radio/abdulbasit_abdulsamad',
    backupUrls: [
      'https://radio.mp3islam.com/listen/abdulbasit/radio.mp3',
      'https://qurango.net/radio/abdulbasit_abdulsamad',
      'https://backup.qurango.net/radio/tarateel',
    ],
    country: 'مصر',
    streamType: 'Icecast',
  },
  {
    id: 'husary_radio',
    name: 'إذاعة الشيخ محمود خليل الحصري',
    url: 'https://backup.qurango.net/radio/mahmoud_khalil_alhussary',
    backupUrls: [
      'https://qurango.net/radio/mahmoud_khalil_alhussary',
      'https://backup.qurango.net/radio/tarateel',
      'https://win.holol.com/live/quran/playlist.m3u8',
    ],
    country: 'مصر',
    streamType: 'Icecast',
  },
  {
    id: 'minshawi_radio',
    name: 'إذاعة الشيخ محمد صديق المنشاوي',
    url: 'https://backup.qurango.net/radio/mohammed_siddiq_alminshawi',
    backupUrls: [
      'https://qurango.net/radio/mohammed_siddiq_alminshawi',
      'https://backup.qurango.net/radio/tarateel',
    ],
    country: 'مصر',
    streamType: 'Icecast',
  },
  {
    id: 'dosari_radio',
    name: 'إذاعة الشيخ ياسر الدوسري',
    url: 'https://backup.qurango.net/radio/yasser_aldosari',
    backupUrls: [
      'https://qurango.net/radio/yasser_aldosari',
      'https://win.holol.com/live/quran/playlist.m3u8',
      'https://backup.qurango.net/radio/tarateel',
    ],
    country: 'السعودية',
    streamType: 'Icecast',
  },
  {
    id: 'qatami_radio',
    name: 'إذاعة الشيخ ناصر القطامي',
    url: 'https://backup.qurango.net/radio/nasser_alqatami',
    backupUrls: [
      'https://qurango.net/radio/nasser_alqatami',
      'https://backup.qurango.net/radio/tarateel',
    ],
    country: 'السعودية',
    streamType: 'Icecast',
  },
  {
    id: 'mp3quran_main',
    name: 'إذاعة تلاوات خاشعة على مدار الساعة',
    url: 'https://backup.qurango.net/radio/tarateel',
    backupUrls: [
      'https://qurango.net/radio/tarateel',
      'https://win.holol.com/live/quran/playlist.m3u8',
      'https://backup.qurango.net/radio/salma',
      'https://qurango.net/radio/salma',
    ],
    country: 'بث عالمي',
    streamType: 'Icecast',
  },
];

export const adhkarList: Dhkar[] = [
  {
    id: '1',
    category: 'أذكار الصباح',
    title: 'آية الكرسي',
    text: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ...',
    count: 1,
    reference: 'رواه البخاري'
  }
];
