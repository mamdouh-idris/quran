export interface Ayah {
  number: number;
  text: string;
  translation?: string;
  tafsir?: {
    jalalayn?: string;
    saadi?: string;
    ibnkathir?: string;
  };
  juz: number;
  page: number;
}

export interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  revelationType: 'Meccan' | 'Medinan';
  numberOfAyahs: number;
  ayahs: Ayah[];
}

export interface Reciter {
  id: string;
  name: string;
  style: string; // Hafs, Warsh, etc.
  serverUrl: string;
  ayahServerUrl?: string;
  imageUrl?: string;
}

export interface RadioStation {
  id: string;
  name: string;
  url: string;
  backupUrls?: string[];
  country: string;
  streamType?: 'HLS' | 'Icecast';
}

export interface Dhkar {
  id: string;
  category: string;
  title: string;
  text: string;
  count: number;
  reference: string;
}

export interface PrayerTime {
  name: string;
  arabicName: string;
  time: string;
  iconName: string;
}

export type QuranFontFamily =
  | 'Amiri'
  | 'Amiri Quran'
  | 'Scheherazade New'
  | 'Noto Naskh Arabic'
  | 'Lateef'
  | 'Markazi Text'
  | 'Aref Ruqaa'
  | 'Reem Kufi'
  | 'Cairo'
  | 'Tajawal'
  | 'IBM Plex Sans Arabic'
  | 'Readex Pro'
  | 'Almarai';

export type AppTheme =
  | 'dark'
  | 'light'
  | 'sepia'
  | 'emerald'
  | 'gold'
  | 'navy'
  | 'plum'
  | 'teal';

export type AppAccentColor =
  | 'emerald'
  | 'amber'
  | 'sky'
  | 'teal'
  | 'violet'
  | 'rose'
  | 'indigo'
  | 'cyan'
  | 'green'
  | 'orange'
  | 'fuchsia'
  | 'red';

export type AppLanguage = 'ar' | 'en' | 'fr' | 'ur';

export interface AppSettings {
  fontSize: number;
  fontFamily: QuranFontFamily;
  theme: AppTheme;
  accentColor: AppAccentColor;
  language: AppLanguage;
  readingMode: boolean; // Comfortable reading mode for dim lighting
  navigationMode: 'swipe' | 'buttons'; // Page turning by swipe vs buttons
  pageFlipAnimation: boolean; // 3D page flip animation effect
  reciterId: string;
  muezzinId: string;
  tafsirType: 'jalalayn' | 'saadi' | 'ibnkathir';
  wifiOnlyDownload: boolean;
  shortAdhan: boolean; // 2 takbeers only
  flipMuteEnabled: boolean;
  notificationsEnabled: boolean;
  smartPauseEnabled: boolean; // Auto-pause on incoming calls or system alerts
}

export interface TasmieMistake {
  ayahNumber: number;
  wordIndex: number;
  expectedWord: string;
  spokenWord: string;
  correction: string;
}

export interface TasmieResult {
  surahNumber: number;
  ayahStart: number;
  ayahEnd: number;
  accuracy: number;
  mistakes: TasmieMistake[];
  summary: string;
  durationSeconds: number;
}

export interface IstighfarReminderSlot {
  id: string;
  time: string; // "HH:MM" 24-hour format
  dhikr: string;
  enabled: boolean;
}

export interface IstighfarScheduleConfig {
  enabled: boolean;
  intervalEnabled: boolean;
  intervalMinutes: number;
  intervalDhikr: string;
  scheduledSlots: IstighfarReminderSlot[];
}
