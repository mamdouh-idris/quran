import React, { createContext, useContext, useState, useRef, useEffect, useCallback } from 'react';

export type AudioSourceId = 'mushaf' | 'tafsir' | 'radio' | 'adhan';

export interface AudioController {
  pause: () => void;
  resume: () => void;
  isPlaying: () => boolean;
}

export interface InterruptionEvent {
  type: 'call' | 'notification';
  title: string;
  subtitle: string;
}

interface SmartPauseContextValue {
  smartPauseEnabled: boolean;
  activeInterruption: InterruptionEvent | null;
  pausedBySmartPause: AudioSourceId | null;
  registerAudioController: (id: AudioSourceId, controller: AudioController) => () => void;
  notifyAudioStarted: (id: AudioSourceId) => void;
  notifyAudioStopped: (id: AudioSourceId) => void;
  triggerInterruption: (type: 'call' | 'notification', customTitle?: string) => void;
  endInterruption: () => void;
}

const SmartPauseContext = createContext<SmartPauseContextValue | null>(null);

interface SmartPauseProviderProps {
  smartPauseEnabled: boolean;
  children: React.ReactNode;
}

export const SmartPauseProvider: React.FC<SmartPauseProviderProps> = ({
  smartPauseEnabled,
  children,
}) => {
  const [activeInterruption, setActiveInterruption] = useState<InterruptionEvent | null>(null);
  const [pausedBySmartPause, setPausedBySmartPause] = useState<AudioSourceId | null>(null);

  const smartPauseEnabledRef = useRef(smartPauseEnabled);
  smartPauseEnabledRef.current = smartPauseEnabled;

  const controllersRef = useRef<Partial<Record<AudioSourceId, AudioController>>>({});
  const pausedSourceRef = useRef<AudioSourceId | null>(null);
  const autoEndTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const playSubtleAlertTone = useCallback((type: 'call' | 'notification') => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      if (type === 'call') {
        osc.frequency.setValueAtTime(587.33, ctx.currentTime);
        osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.15);
      } else {
        osc.frequency.setValueAtTime(880, ctx.currentTime);
      }
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
      setTimeout(() => {
        ctx.close().catch(() => {});
      }, 500);
    } catch {
      // Ignore if AudioContext is blocked
    }
  }, []);

  const endInterruption = useCallback(() => {
    if (autoEndTimerRef.current) {
      clearTimeout(autoEndTimerRef.current);
      autoEndTimerRef.current = null;
    }

    setActiveInterruption(null);

    const sourceToResume = pausedSourceRef.current;
    pausedSourceRef.current = null;
    setPausedBySmartPause(null);

    if (sourceToResume && smartPauseEnabledRef.current) {
      const controller = controllersRef.current[sourceToResume];
      if (controller) {
        // Small delay so the OS/alert audio clears cleanly before resuming
        setTimeout(() => {
          controller.resume();
        }, 250);
      }
    }
  }, []);

  const triggerInterruption = useCallback((type: 'call' | 'notification', customTitle?: string) => {
    if (autoEndTimerRef.current) {
      clearTimeout(autoEndTimerRef.current);
      autoEndTimerRef.current = null;
    }

    const eventDetails: InterruptionEvent =
      type === 'call'
        ? {
            type: 'call',
            title: customTitle || 'مكالمة هاتفية واردة',
            subtitle: 'مكالمة صوتية • ٠٥٠ ١٢٣ ٤٥٦٧',
          }
        : {
            type: 'notification',
            title: customTitle || 'تنبيه نظام وارد',
            subtitle: 'إشعار ذو أولوية عالية من النظام',
          };

    setActiveInterruption(eventDetails);

    if (smartPauseEnabledRef.current) {
      const sources: AudioSourceId[] = ['mushaf', 'tafsir', 'radio', 'adhan'];
      for (const sourceId of sources) {
        const ctrl = controllersRef.current[sourceId];
        if (ctrl && ctrl.isPlaying()) {
          pausedSourceRef.current = sourceId;
          setPausedBySmartPause(sourceId);
          ctrl.pause();
          break;
        }
      }
    }

    playSubtleAlertTone(type);

    if (type === 'notification') {
      autoEndTimerRef.current = setTimeout(() => {
        endInterruption();
      }, 3500);
    }
  }, [endInterruption, playSubtleAlertTone]);

  const registerAudioController = useCallback((id: AudioSourceId, controller: AudioController) => {
    controllersRef.current[id] = controller;
    return () => {
      delete controllersRef.current[id];
    };
  }, []);

  const notifyAudioStarted = useCallback((id: AudioSourceId) => {
    // Prevent overlapping sounds between in-app audio players
    const sources: AudioSourceId[] = ['mushaf', 'tafsir', 'radio', 'adhan'];
    for (const sourceId of sources) {
      if (sourceId !== id) {
        const ctrl = controllersRef.current[sourceId];
        if (ctrl && ctrl.isPlaying()) {
          ctrl.pause();
        }
      }
    }
    if (pausedSourceRef.current === id) {
      pausedSourceRef.current = null;
      setPausedBySmartPause(null);
    }
  }, []);

  const notifyAudioStopped = useCallback((id: AudioSourceId) => {
    if (pausedSourceRef.current === id && !activeInterruption) {
      pausedSourceRef.current = null;
      setPausedBySmartPause(null);
    }
  }, [activeInterruption]);

  // Listen to native OS / Browser Audio Focus & MediaSession events + custom bridge events
  useEffect(() => {
    const handleCallStart = () => triggerInterruption('call');
    const handleCallEnd = () => endInterruption();
    const handleAlertStart = () => triggerInterruption('notification');
    const handleAlertEnd = () => endInterruption();

    window.addEventListener('smartpause:call-start', handleCallStart);
    window.addEventListener('smartpause:call-end', handleCallEnd);
    window.addEventListener('smartpause:alert-start', handleAlertStart);
    window.addEventListener('smartpause:alert-end', handleAlertEnd);

    // MediaSession integration for OS-level pause/play (e.g. phone call or headset)
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.setActionHandler('pause', () => {
          if (!smartPauseEnabledRef.current) return;
          const sources: AudioSourceId[] = ['mushaf', 'tafsir', 'radio', 'adhan'];
          for (const sourceId of sources) {
            const ctrl = controllersRef.current[sourceId];
            if (ctrl && ctrl.isPlaying()) {
              pausedSourceRef.current = sourceId;
              setPausedBySmartPause(sourceId);
              ctrl.pause();
              break;
            }
          }
        });
        navigator.mediaSession.setActionHandler('play', () => {
          if (!smartPauseEnabledRef.current) return;
          const sourceToResume = pausedSourceRef.current;
          if (sourceToResume) {
            pausedSourceRef.current = null;
            setPausedBySmartPause(null);
            controllersRef.current[sourceToResume]?.resume();
          }
        });
      } catch {
        // Some browsers restrict certain MediaSession handlers
      }
    }

    // Monitor Web Audio API state for OS audio interruptions (e.g., iOS/Android calls)
    let probeCtx: AudioContext | null = null;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        probeCtx = new AudioCtx();
        probeCtx.onstatechange = () => {
          if (!smartPauseEnabledRef.current || !probeCtx) return;
          const state = probeCtx.state as string;
          if (state === 'interrupted') {
            triggerInterruption('call', 'مقاطعة صوتية من النظام');
          } else if (state === 'running' && pausedSourceRef.current) {
            endInterruption();
          }
        };
      }
    } catch {
      // Ignore if AudioContext cannot be created before user gesture
    }

    return () => {
      window.removeEventListener('smartpause:call-start', handleCallStart);
      window.removeEventListener('smartpause:call-end', handleCallEnd);
      window.removeEventListener('smartpause:alert-start', handleAlertStart);
      window.removeEventListener('smartpause:alert-end', handleAlertEnd);
      if (autoEndTimerRef.current) clearTimeout(autoEndTimerRef.current);
      if (probeCtx) {
        probeCtx.close().catch(() => {});
      }
    };
  }, [triggerInterruption, endInterruption]);

  return (
    <SmartPauseContext.Provider
      value={{
        smartPauseEnabled,
        activeInterruption,
        pausedBySmartPause,
        registerAudioController,
        notifyAudioStarted,
        notifyAudioStopped,
        triggerInterruption,
        endInterruption,
      }}
    >
      {children}
    </SmartPauseContext.Provider>
  );
};

export const useSmartPause = (): SmartPauseContextValue => {
  const ctx = useContext(SmartPauseContext);
  if (!ctx) {
    throw new Error('useSmartPause must be used within a SmartPauseProvider');
  }
  return ctx;
};
